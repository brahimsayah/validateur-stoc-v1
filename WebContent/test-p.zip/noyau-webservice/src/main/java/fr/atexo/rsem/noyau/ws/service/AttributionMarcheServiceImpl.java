package fr.atexo.rsem.noyau.ws.service;

import fr.atexo.rsem.noyau.ws.beans.*;
import fr.paris.epm.noyau.commun.Constantes;
import fr.paris.epm.noyau.commun.exception.ApplicationNoyauException;
import fr.paris.epm.noyau.commun.exception.NonTrouveNoyauException;
import fr.paris.epm.noyau.commun.exception.TechnicalNoyauException;
import fr.paris.epm.noyau.metier.*;
import fr.paris.epm.noyau.metier.objetvaleur.EtapesDatesCal;
import fr.paris.epm.noyau.persistance.*;
import fr.paris.epm.noyau.persistance.referentiel.*;
import fr.paris.epm.noyau.service.ReferentielsServiceLocal;
import org.dozer.DozerBeanMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.*;

/**
 * Service pour transformer l'objet EpmTConsultation en ConsultationBean (objet externalisé)
 * @author RDA
 * @version $Revision$, $Date$, $Author$
 */
public class AttributionMarcheServiceImpl implements AttributionMarcheService {

    private static final Logger LOG = LoggerFactory.getLogger(AttributionMarcheServiceImpl.class);

    /**
     * Injection spring.
     */
    private ConsultationGIM consultationGIM;
    private AvenantGIM avenantGIM;
    private ContratGIM contratGIM;
    private ReferentielsServiceLocal referentielsServiceLocal;
    private DozerBeanMapper conversionService;

    /**
     * Conversion des objets EpmT vers des objets @{ConsultationBean} et
     * @{ContratBean qui serviront de réponse aux appels du webservice contrat
     * @return consultations : une liste de consultations attribués
     */
    public List<ConsultationBean> conversionEpmTConsultationVersConsultationBean(Map<String, List<EpmTContrat>> contratsParConsultation) {
        List<ConsultationBean> consultationsBean = new ArrayList<ConsultationBean>();

        for (String numeroConsultation : contratsParConsultation.keySet()) {
            ConsultationBean consultationBean = new ConsultationBean();

            ConsultationCritere consultationCritere = new ConsultationCritere();
            consultationCritere.setNumeroConsultationLike(numeroConsultation);
            List<EpmTConsultation> consultations = (List<EpmTConsultation>) consultationGIM.chercherConsultations(consultationCritere);

            if (consultations != null) {
                EpmTConsultation consultation = consultations.get(0);
                String numeroContratInitiale =null;
                if (consultation.getIdContratInitial()!=null && consultation.getIdContratInitial()>0){
                    EpmTContratCritere contratCritere = new EpmTContratCritere();
                    contratCritere.setIdContrat(consultation.getIdContratInitial());
                    List<EpmTContrat> contratsInitiaux = contratGIM.chercherParCritere(contratCritere);
                    if (contratsInitiaux!= null && contratsInitiaux.get(0)!=null){
                        numeroContratInitiale = contratsInitiaux.get(0).getNumeroContrat();
                    }
                }
                List<EpmTContrat> contrats = contratsParConsultation.get(numeroConsultation);
                if (contrats != null && !contrats.isEmpty()) {
                    EpmTContrat contrat = contrats.get(0);
                    consultationBean = creerConsultationBean(consultation, contrat, numeroContratInitiale);

                    if (consultationBean != null) {
                        List<ContratBean> contratsBean = creerContratsBean(consultation, contrats);
                        consultationBean.setContrats(contratsBean);
                    }

                } else {
                    throw new TechnicalNoyauException("La consultation (" + numeroConsultation + ") ne contient pas de contrat.");
                }

            } else {
                throw new TechnicalNoyauException("La consultation (" + numeroConsultation + ") n'a pas été trouvé en base.");
            }

            consultationsBean.add(consultationBean);
        }

        return consultationsBean;
    }

    /**
     * Conversion des objets EpmTAvenant vers des objets {@link AvenantBean} qui servira de réponse aux appels du webservice contrat
     * @return avenants : une liste d'avenants attribués
     */
    public List<AvenantBean> conversionEpmTAvenantVersConsultationBean(Map<Integer, List<EpmTContrat>> contratsParAvenant) {
        List<AvenantBean> avenants = new ArrayList<AvenantBean>();

        for (Integer idAvenant : contratsParAvenant.keySet()) {
            AvenantCritere critere = new AvenantCritere();
            critere.setIdAvenant(idAvenant);
            List<EpmTAvenant> epmTAvenants = consultationGIM.chercherParCritere(critere);
            if (epmTAvenants != null && !epmTAvenants.isEmpty()) {
                EpmTAvenant epmTAvenant = epmTAvenants.get(0);

                AvenantBean avenant = new AvenantBean();
                avenant.setNumeroInitialContrat(epmTAvenant.getReferenceMarche());
                avenant.setIntitule(epmTAvenant.getIntituleConsultation());
                avenant.setNomContractantPublicMarche(epmTAvenant.getEpmTRefPouvoirAdjudicateur().getLibelle());
                avenant.setCodeContractantPublicMarche(epmTAvenant.getEpmTRefPouvoirAdjudicateur().getCodeContrat());

                if (epmTAvenant.getIdOrganisme() != null) {
                    avenant.setCodeOrganisme(String.valueOf(epmTAvenant.getIdOrganisme()));
                }

                ContratSimpleBean contratBean = new ContratSimpleBean();
                contratBean.setNumeroContrat(epmTAvenant.getReferenceConcatenee());
                contratBean.setTypeContrat(epmTAvenant.getTypeContrat().getLibelle());
                contratBean.setIntituleLot(epmTAvenant.getIntituleLot());
                contratBean.setObjetContrat(epmTAvenant.getObjet());
                contratBean.setDateNotificationMarche(recupererDateNotificationMarche(epmTAvenant));

                String titulaire = epmTAvenant.getTitulaireInitial();
                AttributaireBean attributaire = new AttributaireBean();
                attributaire.setRaisonSocial(titulaire);
                List<AttributaireBean> attributaires = new ArrayList<AttributaireBean>();
                attributaires.add(attributaire);
                contratBean.setAttributaires(attributaires);

                ConsolidePrixBean consolidePrixAvenant = new ConsolidePrixBean();
                consolidePrixAvenant.setConsolidePfMn(epmTAvenant.getPfMn());
                consolidePrixAvenant.setConsolideBcHTMax(epmTAvenant.getBcMax());
                consolidePrixAvenant.setConsolideBcHTMin(epmTAvenant.getBcMin());
                contratBean.setConsolidePrix(consolidePrixAvenant);

                avenant.setContrat(contratBean);
                avenants.add(avenant);

            }
        }

        return avenants;
    }

    /**
     * @param epmTAvenants
     * @return
     * @throws TechnicalNoyauException
     */
    @Override
    /**
     *  {@link AttributionMarcheService.conversionEpmTAvenantVersAvenantBean}
     */
    public List<AvenantBean> conversionEpmTAvenantVersAvenantBean(List<EpmTAvenant> epmTAvenants) {
        List<AvenantBean> avenants = new ArrayList<AvenantBean>();

        for (EpmTAvenant epmTAvenant:epmTAvenants){

            AvenantBean avenant = new AvenantBean();
            avenant.setNumeroInitialContrat(epmTAvenant.getReferenceMarche());
            avenant.setIntitule(epmTAvenant.getIntituleConsultation());
            avenant.setNomContractantPublicMarche(epmTAvenant.getEpmTRefPouvoirAdjudicateur().getLibelle());
            avenant.setCodeContractantPublicMarche(epmTAvenant.getEpmTRefPouvoirAdjudicateur().getCodeContrat());

            if (epmTAvenant.getIdOrganisme() != null) {
                avenant.setCodeOrganisme(String.valueOf(epmTAvenant.getIdOrganisme()));
            }

            ContratSimpleBean contratBean = new ContratSimpleBean();
            contratBean.setNumeroContrat(epmTAvenant.getReferenceConcatenee());
            contratBean.setTypeContrat(epmTAvenant.getTypeContrat().getLibelle());
            contratBean.setIntituleLot(epmTAvenant.getIntituleLot());
            contratBean.setObjetContrat(epmTAvenant.getObjet());
            contratBean.setDateNotificationMarche(recupererDateNotificationMarche(epmTAvenant));

            String titulaire = epmTAvenant.getTitulaireInitial();
            AttributaireBean attributaire = new AttributaireBean();
            attributaire.setRaisonSocial(titulaire);
            List<AttributaireBean> attributaires = new ArrayList<AttributaireBean>();
            attributaires.add(attributaire);
            contratBean.setAttributaires(attributaires);

            ConsolidePrixBean consolidePrixAvenant = new ConsolidePrixBean();
            consolidePrixAvenant.setConsolidePfMn(epmTAvenant.getPfMn());
            consolidePrixAvenant.setConsolideBcHTMax(epmTAvenant.getBcMax());
            consolidePrixAvenant.setConsolideBcHTMin(epmTAvenant.getBcMin());
            contratBean.setConsolidePrix(consolidePrixAvenant);

            avenant.setContrat(contratBean);
            avenants.add(avenant);
        }
        return avenants;
    }

    /**
     * Créer l'objet {@link ConsultationBean} Attribué pour l'utiliser dans la webméthode qui récupere les contrats
     * @param {@link EpmTConsultation consultationBase} : consultation recupérée en base de données
     * @param {@link EpmTContrat contratBase} :contratBase pour recuperer les informations communes à tous les contrats de la consultation
     * @param {@link String numeroContratInitiale} : le numero du contrat initial si la consultation est un marché subséquent d'un accord cadre
     * @return {@link ConsultationBean consultation} attribué
     */
    private ConsultationBean creerConsultationBean(EpmTConsultation consultationBase, EpmTContrat contratBase,String numeroContratInitiale) {
        ConsultationBean consultation = new ConsultationBean();

        consultation.setNumeroConsultation(consultationBase.getNumeroConsultation());
        consultation.setIntitule(consultationBase.getIntituleConsultation());
        consultation.setObjet(consultationBase.getObjet());

        // dates
        consultation.setDateLancement(recupererDateLancement(consultationBase));
        consultation.setDatePublicite(recupererDatePublicite(consultationBase));

        // données du referentiel
        consultation.setNomResponsableMarche(consultationBase.getEpmTUtilisateur().getNom() + " " + consultationBase.getEpmTUtilisateur().getPrenom());

        if (consultationBase.getEpmTUtilisateur() != null && consultationBase.getEpmTUtilisateur().getIdOrganisme() != null) {
            consultation.setCodeOrganisme(String.valueOf(consultationBase.getEpmTUtilisateur().getIdOrganisme()));
        }

        EpmTRefDirectionService dirServiceBeneficiaire = recupererDirectionServiceBeneficiaire(consultationBase.getDirServiceVision());
        consultation.setNomDirectionServiceMarche(dirServiceBeneficiaire.getNom());
        consultation.setCodeDirectionServiceMarche(dirServiceBeneficiaire.getCode());
        consultation.setProcedure(consultationBase.getEpmTRefProcedure().getAcronyme());
        consultation.setNaturePrestation(creerNaturePrestation(consultationBase));

        if (consultationBase.getDureeMarche() != null) {
            int valeurDureeMarche = consultationBase.getDureeMarche();
            if (consultationBase.getEpmTRefChoixMoisJour() != null && valeurDureeMarche != 0) {
                consultation.setValeurDureeDuMarche(valeurDureeMarche);
                consultation.setUniteDureeDuMarche(consultationBase.getEpmTRefChoixMoisJour().getCodeExterne());
            }
        }

        // NombreTotalDepot && NombreDepotElectronique
        consultation = recupererNombreDepots(consultationBase, consultation);

        // TODO à vérifier
        consultation.setMarcheCloture(false);

        boolean phaseSuccessive = false;
        if (Constantes.OUI.equals(consultationBase.getEnPhasesSuccessives())) {
            phaseSuccessive = true;
        }
        consultation.setMarchePhaseSuccessive(phaseSuccessive);

        // ClausesEnvironnementales
        boolean clausesEnvironnementales = false;
        if (Constantes.OUI.equals(consultationBase.getClausesEnvironnementales())) {
            clausesEnvironnementales = true;
        }
        consultation.setMarcheAClauseEnvironnementale(clausesEnvironnementales);

        // Clausesociale
        boolean clausesSociale = false;
        if (Constantes.OUI.equals(consultationBase.getClausesSociales())) {
            clausesSociale = true;
        }
        consultation.setMarcheAClauseSociale(clausesSociale);

        if (consultationBase.getIdConsultationInitiale() != null && consultationBase.getIdConsultationInitiale() != 0) {
            consultation.setNumeroConsultationInitial(recupererNumeroConsultationInitiale(consultationBase.getIdConsultationInitiale()));
        }

        // Infos communes à tous les contrats de la consultation
        consultation.setNomServiceGestionnaireDuMarche(contratBase.getDirectionServiceResponsable().getNom());
        consultation.setCodeServiceGestionnaireDuMarche(contratBase.getDirectionServiceResponsable().getCode());
        consultation.setNomContractantPublicMarche(contratBase.getPouvoirAdjudicateur().getNom());
        consultation.setCodeContractantPublicMarche(contratBase.getPouvoirAdjudicateur().getCodeContrat());
        // numero contrat initiale en cas d'un marché subséquent
        if (numeroContratInitiale!=null){
            consultation.setNumeroContratInitial(numeroContratInitiale);
        }
        return consultation;
    }

    private EpmTRefDirectionService recupererDirectionServiceBeneficiaire(int dirServiceVision) {
        try {
            Collection<EpmTRefDirectionService> direcServiceBenifs = referentielsServiceLocal.getAllReferentiels().getRefDirectionServiceLecture();
            for (EpmTRefDirectionService dirServiceBenif : direcServiceBenifs) {
                if (dirServiceBenif.getId() == dirServiceVision) {
                    return dirServiceBenif;
                }
            }
        } catch (NonTrouveNoyauException e) {
            LOG.error("Erreur :" + e.getMessage());

        } catch (TechnicalNoyauException e) {
            LOG.error("Erreur :" + e.getMessage());
        }

        return null;
    }

    /**
     * Récupère la date de lancement a partir du calendrier, pour enrechir l'objet @{ConsultationBean}
     * @param consultationBase
     * @return
     */
    private Date recupererDateLancement(EpmTConsultation consultationBase) {
        try {
            EtapesDatesCal etapesDateCal = consultationGIM.chargerDatesDuCalendrier(consultationBase.getId(), 0);
            return etapesDateCal.getLancement().getDate();
        } catch (TechnicalNoyauException e) {
            LOG.error("Erreur :" + e.getMessage());
        }
        return null;
    }

    /**
     * Récupère la date de publicite a partir de l'objet @{EpmTPub} pour enrechir l'objet @{ConsultationBean}
     * @param consultationBase
     * @return
     */
    private Date recupererDatePublicite(EpmTConsultation consultationBase) {
        PubliciteCritere criterePub = new PubliciteCritere();
        criterePub.setIdConsultation(consultationBase.getId());
        criterePub.setDerniereCreee(true);
        criterePub.setEnvoye(true);
        criterePub.setTypeAvis(EpmTPub.TYPE_SUPPORT_PUBLICITE);
        try {
            List<EpmTPub> resultatsPub = consultationGIM.chercherParCritere(criterePub);
            for (Iterator<?> iterator = resultatsPub.iterator(); iterator.hasNext();) {
                EpmTPub epmTPub = (EpmTPub) iterator.next();
                if (epmTPub.getDatePub() != null) {
                    return epmTPub.getDatePub();
                }
            }
        } catch (TechnicalNoyauException e) {
            LOG.error("Erreur :" + e.getMessage());
        }
        return null;
    }

    /**
     * Créée l'objet @{NaturePrestationBean} a partir de @{EpmTRefNature} afin d'enrechir l'objet @{ConsultationBean}
     * @param consultationBase
     * @return
     */
    private NaturePrestationBean creerNaturePrestation(EpmTConsultation consultationBase) {
        EpmTRefNature nature = consultationBase.getEpmTRefNature();
        NaturePrestationBean resultatNature = null;
        if (EpmTRefNature.ACRONYME_TRAVAUX.equals(nature.getAcronyme())) {
            resultatNature = NaturePrestationBean.TRAVAIL;
        }

        if (EpmTRefNature.ACRONYME_FOURNITURE.equals(nature.getAcronyme())) {
            resultatNature = NaturePrestationBean.FOURNITURE;
        }

        if (EpmTRefNature.ACRONYME_SERVICE.equals(nature.getAcronyme())) {
            resultatNature = NaturePrestationBean.SERVICE;
        }
        return resultatNature;
    }

    /**
     * Récupérer le nombre total de dépots ainsi que le nombre de dépots exclusivement electroniques. Cela permettra d'enrechir l'objet
     * @{ConsultationBean
     * @param consultationBase
     * @param consultation
     * @return
     */
    private ConsultationBean recupererNombreDepots(EpmTConsultation consultationBase, ConsultationBean consultation) {
        ConsultationBean consultationRes = consultation;
        try {
            DepotCritere critereDepot = new DepotCritere();
            critereDepot.setIdConsultation(consultationBase.getId());
            critereDepot.setChercherNombreResultatTotal(true);
            critereDepot.setFormatElectronique(false);
            List<?> resultatRecherche = consultationGIM.chercherParCritere(critereDepot);
            String nombreResultatDepot = "0";
            Object objetResultat = resultatRecherche.get(0);
            if (objetResultat instanceof Long) {
                nombreResultatDepot = objetResultat.toString();
            }
            consultationRes.setNombreTotalDepot(nombreResultatDepot);

            critereDepot.setFormatElectronique(true);
            resultatRecherche = consultationGIM.chercherParCritere(critereDepot);
            nombreResultatDepot = "0";
            objetResultat = resultatRecherche.get(0);
            if (objetResultat instanceof Long) {
                nombreResultatDepot = objetResultat.toString();
            }
            consultationRes.setNombreDepotElectronique(nombreResultatDepot);

        } catch (TechnicalNoyauException e) {
            LOG.error("Erreur :" + e.getMessage());
        }

        return consultationRes;
    }

    /**
     * Créée l'objet @{ContratBean} a partir des données de l'objet
     * @{EpmTAttribution . Cet objet represente chaque marché attribué. Lors d'une consultation alloti, un contrat est crée par lot. Cet objet permettra donc d'enrechir l'objet
     * @{ConsultationBean .
     * @param consultationBase
     * @return
     * @throws TechnicalNoyauException
     */
    public List<ContratBean> creerContratsBean(EpmTConsultation consultationBase, final List<EpmTContrat> contratsParConsultation) {
        List<ContratBean> contrats = new ArrayList<ContratBean>();

        for (EpmTContrat epmTContrat : contratsParConsultation) {
            ContratBean contrat = new ContratBean();
            StringBuffer objetContrat = new StringBuffer(consultationBase.getIntituleConsultation());
            if(epmTContrat.getIntituleLot() != null ) {
                objetContrat.append(" - ").append(epmTContrat.getIntituleLot());
            }
            contrat.setObjetContrat(objetContrat.toString());
            contrat.setDateNotificationMarche(recupererDateNotificationMarche(consultationBase));
            contrat.setIntituleLot(epmTContrat.getIntituleLot());
            contrat.setNumeroLot(epmTContrat.getNumeroLot());
            contrat.setNombreReconductions(epmTContrat.getNombreReconduction());
            contrat.setModalitesReconduction(epmTContrat.getModaliteReconduction());
            contrat.setVariantesTechniques(epmTContrat.getOptions());
            ConsolidePrixBean consolidePrixBean = creerConsolidePrix(epmTContrat.getFormePrix());
            contrat.setConsolidePrix(consolidePrixBean);
            contrat.setNumeroContrat(epmTContrat.getNumeroContrat());
            contrat.setTypeContrat(epmTContrat.getTypeContrat().getCodeExterne());

            // controle legalité
            EpmTEnregistrementControleLegalite controleLegalite = epmTContrat.getEnregistrementControleLegalite();
            if (controleLegalite != null) {
                contrat.setDateDemandeLegalite(controleLegalite.getDateEnrControleLegal());
            }
            contrat.setDateSignature(epmTContrat.getDateSignature());
            contrat.setAttributaires(creerAttributaires(epmTContrat.getAttributaires()));

            EpmTBudFormePrix fdp = null;
            List<EpmTBudFormePrix> listeFdp = new ArrayList<EpmTBudFormePrix>();
            Set<EpmTBudTranche> epmTBudTranches = new HashSet<EpmTBudTranche>();
            Set<EpmTLotTechnique> epmTLotsTechniques = new HashSet<EpmTLotTechnique>();
            if (consultationBase.getAllotissement().equals(Constantes.NON)) {
                epmTBudTranches = consultationBase.getEpmTBudLotOuConsultation().getEpmTBudTranches();
                epmTLotsTechniques = consultationBase.getEpmTBudLotOuConsultation().getEpmTLotTechniques();
                fdp = consultationBase.getEpmTBudLotOuConsultation().getEpmTBudFormePrix();
            } else {
                EpmTBudLotOuConsultation lotConsultation = recupererLotConsultationDuContrat(consultationBase, epmTContrat);

                epmTBudTranches = lotConsultation.getEpmTBudTranches();
                epmTLotsTechniques = lotConsultation.getEpmTLotTechniques();
                fdp = lotConsultation.getEpmTBudFormePrix();
            }
            contrat.setLotsTechniques(creerLotsTechniques(epmTLotsTechniques));
            contrat.setEstimationPrix(creerEstimationPrix(fdp));
            listeFdp.add(fdp);

            // marché à tranches
            if (epmTContrat.getTranches() != null && !epmTContrat.getTranches().isEmpty()) {
                List<TrancheBean> tranches = new ArrayList<TrancheBean>();
                for (EpmTBudTranche epmTBudTranche : epmTBudTranches) {
                    TrancheBean tranche = new TrancheBean();

                    // trancheFixe
                    Boolean trancheFixe = false;
                    if (EpmTRefNatureTranche.TRANCHE_FIXE == epmTBudTranche.getEpmTRefNatureTranche().getId()) {
                        trancheFixe = true;
                    }
                    tranche.setTrancheFixe(trancheFixe);

                    tranche.setCodeTranche(epmTBudTranche.getCodeTranche());
                    tranche.setNatureTranche(epmTBudTranche.getEpmTRefNatureTranche().getLibelle());
                    tranche.setIntituleTranche(epmTBudTranche.getIntituleTranche());

                    // Estimation Prix : ici on fait un override de l'estimation
                    // de prix du contrat, car dans un marché à tranche, la fdp
                    // est définie dans la tranche
                    EpmTBudFormePrix fdpTrancheEstime = epmTBudTranche.getEpmTBudFormePrix();
                    listeFdp.clear();
                    listeFdp.add(fdpTrancheEstime);

                    EstimationPrixBean estimationPrixTranche = creerEstimationPrix(fdpTrancheEstime);
                    tranche.setEstimationPrix(estimationPrixTranche);
                    contrat.setEstimationPrix(estimationPrixTranche);

                    // Consolide prix
                    for (EpmTBudTranche epmTBudTrancheContrat : epmTContrat.getTranches()) {
                        boolean trancheMemeNature = epmTBudTranche.getEpmTRefNatureTranche().getId() == epmTBudTrancheContrat.getEpmTRefNatureTranche().getId();
                        boolean trancheMemeCode = epmTBudTranche.getCodeTranche().equals(epmTBudTrancheContrat.getCodeTranche());
                        boolean trancheMemeIntitule = epmTBudTranche.getIntituleTranche().equals(epmTBudTrancheContrat.getIntituleTranche());
                        if (trancheMemeNature && trancheMemeCode && trancheMemeIntitule) {
                            ConsolidePrixBean nouveauConsolidePrix = creerConsolidePrix(epmTBudTrancheContrat.getEpmTBudFormePrix());
                            tranche.setConsolidePrix(nouveauConsolidePrix);
                            // override cas marché à tranches : somme des
                            // montants de chaque tranche
                            contrat.setConsolidePrix(sommeConsolidePrix(contrat.getConsolidePrix(), nouveauConsolidePrix));
                            break;
                        }
                    }
                    tranches.add(tranche);
                }
                contrat.setTranches(tranches);
            }

            contrat.setMarcheABonDeCommande(isBonDeCommande(listeFdp));

            EpmTMiseADispositionCritere critereMiseADisposition = new EpmTMiseADispositionCritere();
            critereMiseADisposition.setIdContrat(epmTContrat.getId());
            critereMiseADisposition.setExecution(true);
            try {
                EpmTMiseADisposition miseADispo = (EpmTMiseADisposition) consultationGIM.chercherUniqueParCritere(critereMiseADisposition);
                if(miseADispo != null) {
                    contrat.setIdMiseADispositionExecution(miseADispo.getId());
                }
            } catch (ApplicationNoyauException e) {
                LOG.error("Une erreur est survenue lors de la récupération de la mise à idposition avec le critere {} pour le contrat dont l'id est '{}'", new Object[] { critereMiseADisposition,
                        epmTContrat.getId() }, e.fillInStackTrace());
            }
            contrats.add(contrat);
        }

        return contrats;
    }

    private ConsolidePrixBean sommeConsolidePrix(ConsolidePrixBean consolidePrixCourant, ConsolidePrixBean nouveauConsolidePrix) {
        ConsolidePrixBean consolidePrixTotal = new ConsolidePrixBean();
        consolidePrixTotal.setConsolideBcHTMax(consolidePrixCourant.getConsolideBcHTMax() + nouveauConsolidePrix.getConsolideBcHTMax());
        consolidePrixTotal.setConsolideBcHTMin(consolidePrixCourant.getConsolideBcHTMin() + nouveauConsolidePrix.getConsolideBcHTMin());
        consolidePrixTotal.setConsolideBcTTCMax(consolidePrixCourant.getConsolideBcTTCMax() + nouveauConsolidePrix.getConsolideBcTTCMax());
        consolidePrixTotal.setConsolideBcTTCMin(consolidePrixCourant.getConsolideBcTTCMin() + nouveauConsolidePrix.getConsolideBcTTCMin());
        consolidePrixTotal.setConsolideHTForfaitaire(consolidePrixCourant.getConsolideHTForfaitaire() + nouveauConsolidePrix.getConsolideHTForfaitaire());
        consolidePrixTotal.setConsolideHTUnitaire(consolidePrixCourant.getConsolideHTUnitaire() + nouveauConsolidePrix.getConsolideHTUnitaire());
        consolidePrixTotal.setConsolidePfMn(consolidePrixCourant.getConsolidePfMn() + nouveauConsolidePrix.getConsolidePfMn());
        consolidePrixTotal.setConsolideTTCForfaitaire(consolidePrixCourant.getConsolideTTCForfaitaire() + nouveauConsolidePrix.getConsolideTTCForfaitaire());
        consolidePrixTotal.setConsolideTTCUnitaire(consolidePrixCourant.getConsolideTTCUnitaire() + nouveauConsolidePrix.getConsolideTTCUnitaire());
        return consolidePrixTotal;
    }

    /**
     * @param consultationBase
     * @param epmTContrat
     * @return
     * @throws TechnicalNoyauException
     */
    private EpmTBudLotOuConsultation recupererLotConsultationDuContrat(EpmTConsultation consultationBase, EpmTContrat epmTContrat) {
        if (epmTContrat.getNumeroLot() != null && !epmTContrat.getNumeroLot().isEmpty()) {
            for (EpmTBudLot lot : consultationBase.getEpmTBudLots()) {
                Integer numeroLotConsultation = Integer.parseInt(lot.getNumeroLot());
                if (numeroLotConsultation == Integer.parseInt(epmTContrat.getNumeroLot())) {
                    return lot.getEpmTBudLotOuConsultation();
                }
            }
        }

        throw new TechnicalNoyauException("Incoherence entre la consultation (" + consultationBase.getNumeroConsultation() + ") et le contrat (" + epmTContrat.getNumeroContrat()
                + ") : soit le type d'allotissement n'est pas conforme soit le numero de lot est manquant dans la consultation.");
    }

    /**
     * Récupere le numero de consultation initial en cas d'un marché suite à accord cadre
     * @param idConsultationInitiale : l'uidentifiant en base de la consultation initiale
     * @return
     */
    private String recupererNumeroConsultationInitiale(Integer idConsultationInitiale) {
        try {
            EpmTConsultation consultationInitiale = consultationGIM.chargerConsultation(idConsultationInitiale);
            return consultationInitiale.getNumeroConsultation();
        } catch (NonTrouveNoyauException e) {
            LOG.error("Erreur :" + e.getMessage());
        } catch (TechnicalNoyauException e) {
            LOG.error("Erreur :" + e.getMessage());
        }
        return null;
    }

    /**
     * Récupère la date de notification du marché dans l'étape du calendrier pour enrechir l'objet @{ContratBean}
     * @param consultationBase : consultation de traitement
     * @return
     */
    private Date recupererDateNotificationMarche(EpmTConsultation consultationBase) {
        try {
            EtapesDatesCal etapes = consultationGIM.chargerDatesDuCalendrier(consultationBase.getId(), 0);
            if (etapes != null && etapes.getNotificationAttribution() != null && etapes.getNotificationAttribution().getDate() != null) {
                return etapes.getNotificationAttribution().getDate();
            }
        } catch (TechnicalNoyauException e) {
            LOG.error("Erreur :" + e.getMessage());
        }
        return null;
    }

    /**
     * Récupère la date de notification du marché dans l'étape du calendrier pour enrechir l'objet @{ContratBean}
     * @return
     */
    private Date recupererDateNotificationMarche(EpmTAvenant avenantBase) {
        try {
            EtapesDatesCal etapes = avenantGIM.chargerDatesDuCalendrierAvenant(avenantBase.getId());
            if (etapes != null && etapes.getNotificationAttribution() != null && etapes.getNotificationAttribution().getDate() != null) {
                return etapes.getNotificationAttribution().getDate();
            }
        } catch (TechnicalNoyauException e) {
            LOG.error("Erreur :" + e.getMessage());
        }
        return null;
    }

    /**
     * Créée l'objet @{LotTechniqueBean} a partir de l'objet
     * @{EpmTLotTechnique , qui permettra d'enrechir l'objet @{ContratBean}
     * @return
     */
    private List<LotTechniqueBean> creerLotsTechniques(Set<EpmTLotTechnique> epmTLotsTechniques) {
        List<LotTechniqueBean> lotsTechniques = new ArrayList<LotTechniqueBean>();
        for (EpmTLotTechnique epmTLotTechnique : epmTLotsTechniques) {
            LotTechniqueBean lotTechnique = new LotTechniqueBean();
            lotTechnique.setIdentifiantLot(epmTLotTechnique.getNumeroLot());
            lotTechnique.setIntituleLot(epmTLotTechnique.getIntituleLot());
            lotTechnique.setLotPrincipal(epmTLotTechnique.getPrincipal().equals(Constantes.OUI));
            lotsTechniques.add(lotTechnique);
        }
        return lotsTechniques;
    }

    /**
     * Créée l'objet @{EstimationPrixBean} a partir des données de la
     * @{EpmTBudFormePrix . Cette forme de prix permettra d'enrechir l'objet
     * @{ContratBean
     * @param epmTBudFormePrix
     * @return
     */
    private EstimationPrixBean creerEstimationPrix(EpmTBudFormePrix epmTBudFormePrix) {
        EstimationPrixBean estimationPrix = new EstimationPrixBean();

        if (epmTBudFormePrix != null) {
            if (epmTBudFormePrix instanceof EpmTBudFormePrixPm) {
                EpmTBudFormePrixPm pm = (EpmTBudFormePrixPm) epmTBudFormePrix;
                if (pm.getPfEstimationTtc() != null) {
                    estimationPrix.setEstimationTTCForfataire(pm.getPfEstimationTtc());
                }

                if (pm.getPfEstimationHt() != null) {
                    estimationPrix.setEstimationHTForfataire(pm.getPfEstimationHt());
                }

                if (pm.getPuEstimationTtc() != null) {
                    estimationPrix.setEstimationTTCUnitaire(pm.getPuEstimationTtc());
                }

                if (pm.getPuEstimationHt() != null) {
                    estimationPrix.setEstimationHTUnitaire(pm.getPuEstimationHt());
                }

                estimationPrix.setTypePrix(recupererTypeFormePrix(pm.getPuEpmTRefTypePrix()));
                estimationPrix.setVariationPrixUnitaire(recupererVariationFormePrix(pm.getPuEpmTRefVariations()));
                estimationPrix.setVariationPrixForfaitaire(recupererVariationFormePrix(pm.getPfEpmTRefVariations()));

                Calendar calendarPm = pm.getPfDateValeur();
                if (calendarPm != null) {
                    estimationPrix.setDatePrix(calendarPm.getTime());
                }

                estimationPrix.setFormePrix(FormePrixBean.MIXTE);

            } else if (epmTBudFormePrix instanceof EpmTBudFormePrixPu) {
                EpmTBudFormePrixPu pu = (EpmTBudFormePrixPu) epmTBudFormePrix;

                if (pu.getPuEstimationTtc() != null) {
                    estimationPrix.setEstimationTTCUnitaire(pu.getPuEstimationTtc());
                }

                if (pu.getPuEstimationHt() != null) {
                    estimationPrix.setEstimationHTUnitaire(pu.getPuEstimationHt());
                }

                estimationPrix.setTypePrix(recupererTypeFormePrix(pu.getEpmTRefTypePrix()));
                estimationPrix.setVariationPrixUnitaire(recupererVariationFormePrix(pu.getPuEpmTRefVariations()));

                Calendar calendarPu = pu.getPuDateValeur();
                if (calendarPu != null) {
                    estimationPrix.setDatePrix(calendarPu.getTime());
                }

                estimationPrix.setFormePrix(FormePrixBean.UNITAIRE);

            } else if (epmTBudFormePrix instanceof EpmTBudFormePrixPf) {
                EpmTBudFormePrixPf pf = (EpmTBudFormePrixPf) epmTBudFormePrix;
                if (pf.getPfEstimationHt() != null) {
                    estimationPrix.setEstimationHTForfataire(pf.getPfEstimationHt());
                }

                if (pf.getPfEstimationTtc() != null) {
                    estimationPrix.setEstimationTTCForfataire(pf.getPfEstimationTtc());
                }
                estimationPrix.setVariationPrixForfaitaire(recupererVariationFormePrix(pf.getPfEpmTRefVariations()));

                Calendar calendarPf = pf.getPfDateValeur();
                if (calendarPf != null) {
                    estimationPrix.setDatePrix(calendarPf.getTime());
                }

                estimationPrix.setFormePrix(FormePrixBean.FORFAITAIRE);
            }

        }

        return estimationPrix;
    }

    /**
     * Créée le bean @{ConsolidePrixBean} a partir des montants de l'écran d'attribution du contrat. Cette forme de prix permettra d'enrechir l'objet @{ContratBean}
     * @return
     */
    private ConsolidePrixBean creerConsolidePrix(EpmTBudFormePrix fdp  ) {
        ConsolidePrixBean consolidePrix = new ConsolidePrixBean();
        if (fdp != null) {
            EstimationPrixBean prixEstime = creerEstimationPrix(fdp);
            consolidePrix.setConsolideHTForfaitaire(prixEstime.getEstimationHTForfataire());
            consolidePrix.setConsolideTTCForfaitaire(prixEstime.getEstimationTTCForfataire());
            consolidePrix.setConsolideHTUnitaire(prixEstime.getEstimationHTUnitaire());
            consolidePrix.setConsolideTTCUnitaire(prixEstime.getEstimationTTCUnitaire());
            if (fdp instanceof EpmTBudFormePrixPm){
                EpmTBudFormePrixPm fdpm = (EpmTBudFormePrixPm)fdp;
                consolidePrix.setConsolideBcHTMin(fdpm.getPuMinHt());
                consolidePrix.setConsolideBcHTMax(fdpm.getPuMaxHt());
                consolidePrix.setConsolideBcTTCMin(fdpm.getPuMinTtc());
                consolidePrix.setConsolideBcTTCMax(fdpm.getPuMaxTtc());
            } else if (fdp instanceof EpmTBudFormePrixPu) {
                EpmTBudFormePrixPu fdpu = (EpmTBudFormePrixPu)fdp;
                consolidePrix.setConsolideBcHTMin(fdpu.getPuMinHt());
                consolidePrix.setConsolideBcHTMax(fdpu.getPuMaxHt());
                consolidePrix.setConsolideBcTTCMin(fdpu.getPuMinTtc());
                consolidePrix.setConsolideBcTTCMax(fdpu.getPuMaxTtc()!=null?fdpu.getPuMaxTtc().doubleValue():0);
            }
        }
        return consolidePrix;
    }

    /**
     * Vérifie si la forme de prix @{EpmTBudFormePrix} est à bon de commande
     * @param liste
     * @return
     */
    private Boolean isBonDeCommande(List<EpmTBudFormePrix> liste) {
        Boolean marcheABonDeCommande = false;
        for (EpmTBudFormePrix epmTBudFormePrix : liste) {
            if (epmTBudFormePrix != null) {
                if (epmTBudFormePrix instanceof EpmTBudFormePrixPm) {
                    EpmTBudFormePrixPm pm = (EpmTBudFormePrixPm) epmTBudFormePrix;
                    if (pm.getPuEpmTRefBonQuantite() != null && EpmTRefBonQuantite.ID_BON_COMMANDE == pm.getPuEpmTRefBonQuantite().getId()) {
                        marcheABonDeCommande = true;
                    }
                } else if (epmTBudFormePrix instanceof EpmTBudFormePrixPu) {
                    EpmTBudFormePrixPu pu = (EpmTBudFormePrixPu) epmTBudFormePrix;
                    if (pu.getEpmTRefBonQuantite() != null && EpmTRefBonQuantite.ID_BON_COMMANDE == pu.getEpmTRefBonQuantite().getId()) {
                        marcheABonDeCommande = true;
                    }
                }
            }
        }
        return marcheABonDeCommande;

    }

    /**
     * Récupère les variations de la forme de prix @{EpmTRefVariation} pour enrechir l'objet @{EstimationPrixBean}
     * @param epmTVariations
     * @return
     */
    private List<String> recupererVariationFormePrix(Set<EpmTRefVariation> epmTVariations) {
        List<String> resultat = null;
        if (epmTVariations != null && epmTVariations.size() > 0) {
            resultat = new ArrayList<String>(epmTVariations.size());
            for (EpmTRefVariation variation : epmTVariations) {
                resultat.add(variation.getCodeExterne());
            }
        }
        return resultat;
    }

    /**
     * Récupère les types de prix @{EpmTRefTypePrix} pour enrechir l'objet
     * @{EstimationPrixBean
     * @param epmTTypePrixPu
     * @return
     */
    private List<String> recupererTypeFormePrix(Set<EpmTRefTypePrix> epmTTypePrixPu) {
        List<String> resultat = null;
        if (epmTTypePrixPu != null && epmTTypePrixPu.size() > 0) {
            resultat = new ArrayList<String>(epmTTypePrixPu.size());
            for (EpmTRefTypePrix refTypePrix : epmTTypePrixPu) {
                resultat.add(refTypePrix.getCodeExterne());
            }
        }

        return resultat;
    }

    /**
     * Créée la liste d'attributaires du marché @{AttributaireBean} qui permettra d'enrechir l'objet @{ContratBean}
     * @return
     */
    private List<AttributaireBean> creerAttributaires(Set<EpmTAttributaire> epmTAttributaires) {
        List<AttributaireBean> attributairesBean = new ArrayList<AttributaireBean>();
        for (EpmTAttributaire epmTAttributaire : epmTAttributaires) {
            AttributaireBean attributaire = conversionService.map(epmTAttributaire, AttributaireBean.class);

            List<ContractantBean> contractants = new ArrayList<ContractantBean>();
            for (EpmTContractant epmTContractant : epmTAttributaire.getContractants()) {
                ContractantBean contractant = conversionService.map(epmTContractant, ContractantBean.class);
                contractants.add(contractant);
            }
            attributaire.setContractants(contractants);

            Date dateDeNotification = null;
            if(epmTAttributaire.getMoyenNotification() != null){
                attributaire.setMoyenNotification(epmTAttributaire.getMoyenNotification().getCodeExterne());

                if (epmTAttributaire.getMoyenNotification().getId() == EpmTRefMoyenNotification.REMISE_EN_MAIN_PROPRE)
                {
                    dateDeNotification = epmTAttributaire.getDateEnvoiRemise();
                }

                if (epmTAttributaire.getMoyenNotification().getId() == EpmTRefMoyenNotification.COURRIER_AR)
                {
                    dateDeNotification = epmTAttributaire.getDateAR();
                }
            }
            attributaire.setDateNotification(dateDeNotification);

            if (epmTAttributaire.getTypeAttributaire() != null) {
                attributaire.setTypeAttributaire(epmTAttributaire.getTypeAttributaire().getCodeExterne());
            }
            attributairesBean.add(attributaire);
        }
        return attributairesBean;
    }




    public final void setConsultationGIM(ConsultationGIM valeur) {
        this.consultationGIM = valeur;
    }

    /**
     * @param referentielsServiceLocal the referentielsService to set
     */
    public final void setReferentielsServiceLocal(ReferentielsServiceLocal referentielsServiceLocal) {
        this.referentielsServiceLocal = referentielsServiceLocal;
    }

    public final void setAvenantGIM(AvenantGIM valeur) {
        this.avenantGIM = valeur;
    }

    public final void setContratGIM(ContratGIM valeur) {
        this.contratGIM = valeur;
    }

    public void setConversionService(DozerBeanMapper valeur) {
        this.conversionService = valeur;
    }

}
