package fr.atexo.rsem.noyau.ws.beans.miseADisposition;

import java.util.List;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElementWrapper;
import javax.xml.bind.annotation.XmlRootElement;
@XmlRootElement(name = "resultat")
public class ListMiseAdispositionBean {

private List<MiseAdispositionBean> miseAdispositionList;

/**
 * @return the documentsList
 */
@XmlElementWrapper(name = "listMiseAdispostion")
@XmlElement(name = "miseAdisposition")
public final List<MiseAdispositionBean> getMiseAdispositionList() {
    return miseAdispositionList;
}
/**
 * @param documentsList the documentsList to set
 */
public final void setMiseAdispositionList(List<MiseAdispositionBean> value) {
    this.miseAdispositionList = value;
}


}
