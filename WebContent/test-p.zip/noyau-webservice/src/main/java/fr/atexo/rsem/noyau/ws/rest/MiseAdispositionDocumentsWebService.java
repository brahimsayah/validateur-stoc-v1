package fr.atexo.rsem.noyau.ws.rest;

import com.sun.jersey.spi.resource.Singleton;
import fr.atexo.rsem.noyau.ws.beans.ErreurBean;
import fr.atexo.rsem.noyau.ws.beans.miseADisposition.*;
import fr.atexo.rsem.noyau.ws.rest.constantes.ConstantesRestWebService;
import fr.atexo.rsem.noyau.ws.rest.constantes.StatutRecuperationEnum;
import fr.paris.epm.noyau.commun.exception.ApplicationNoyauException;
import fr.paris.epm.noyau.commun.exception.NonTrouveNoyauException;
import fr.paris.epm.noyau.commun.exception.TechnicalNoyauException;
import fr.paris.epm.noyau.metier.*;
import fr.paris.epm.noyau.persistance.*;
import fr.paris.epm.noyau.persistance.referentiel.*;
import fr.paris.epm.noyau.service.ReferentielsServiceLocal;
import org.apache.commons.io.IOUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.servlet.http.HttpServletResponse;
import javax.ws.rs.*;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBElement;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import javax.xml.namespace.QName;
import java.io.*;
import java.net.URI;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.*;

/**
 * Web service REST de la mise à disposition des web services marchés
 * @author KHALED BENARI
 * @version $Revision$, $Date$, $Author$
 */
@Path("/miseAdisposition")
@Singleton
public class MiseAdispositionDocumentsWebService {

    private static final Logger LOG = LoggerFactory.getLogger(MiseAdispositionDocumentsWebService.class);

    private static ServiceTechniqueGIM serviceTechniqueGIM;

    private static ReferentielsServiceLocal referentielsServiceLocal;

    private static GeneriqueDAO generiqueDAO;

    /**
     * Chemin vers le répertoire d'enregistrement des fichiers temporaires.
     */
    private static String repertoireTemporaire;

    /**
     * Retourne la liste de documents du numeroContrat sous format ZIP.
     * @author KBE
     * @param identifiant de la mise a disposition
     * @return un fichier zip avec les documents
     */

    @GET
    @Path("/archive/{identifiant}")
    @Produces(MediaType.APPLICATION_XML)
    public JAXBElement<? extends Object> miseAdisposition(@PathParam("identifiant") Integer identifiant,
                                                          @Context HttpServletResponse response,
                                                          @QueryParam(ConstantesRestWebService.XML_QNAME_TOKEN) String token) {
        AuthentificationRestWebService auth = new AuthentificationRestWebService();
        JAXBElement<ErreurBean> errorToken = auth.verificationToken(token);
        String message = errorToken.getValue().getMessage();
        if (message == null && message.isEmpty()) {
            // TODO TOKEN
            // AuthentificationRestWebService auth = new
            // AuthentificationRestWebService();
            // JAXBElement<? extends Object> resultat = auth.deconnexion(token);
            // if (!(resultat.getValue() instanceof ErreurBean)) {

            // tester si le ID de lamise à disposition est vide
            if (identifiant == null) {
                throw new WebApplicationException(Response.Status.NOT_FOUND);
            }

            // creer le critere de recherche
            try {
                EpmTMiseADispositionCritere miseADispositionCritere = new EpmTMiseADispositionCritere();
                miseADispositionCritere.setIdMiseAdisposition(identifiant);
                miseADispositionCritere.setExecution(null);
                // recuper la list des contrats avec le numero de consultation
                // fourni , cette liste peut etre vide ou contient un seul
                // element

                @SuppressWarnings("unchecked")
                List<EpmTMiseADisposition> miseADispositionList = (List<EpmTMiseADisposition>) serviceTechniqueGIM
                        .chercherParCritere(miseADispositionCritere);

                // check si la liste des contrats est vide
                if (miseADispositionList == null || miseADispositionList.size() == 0) {
                    throw new WebApplicationException(Response.Status.NOT_FOUND);
                }

                EpmTMiseADisposition miseADisposition = miseADispositionList.get(0);
                // check si la liste des contrats est null
                if (miseADisposition == null) {
                    LOG.error("la base retoune une mise à disposition null avec  le ID" + identifiant);
                    throw new WebApplicationException(Response.Status.INTERNAL_SERVER_ERROR);
                }

                Set<EpmTDocumentMiseADispositionPassation> epmTDocumentsSet = miseADisposition.getDocumentsMiseADisposition();
                if (epmTDocumentsSet == null || epmTDocumentsSet.size() == 0) {
                    LOG.error("la base ne retourne pas une liste de documents  pour la mise à disposition " + identifiant);
                    throw new WebApplicationException(Response.Status.INTERNAL_SERVER_ERROR);
                }

                ListDocumentsMiseAdispositionBean listDocumentForContratBean = new ListDocumentsMiseAdispositionBean();
                List<DocumentMiseAdispositionBean> documents = new ArrayList<DocumentMiseAdispositionBean>();
                List<EpmTAbstractDocument> listDocuments = new ArrayList<EpmTAbstractDocument>();

                EpmTUtilisateur utilisateur = miseADisposition.getUtilisateur();
                if (utilisateur != null) {

                    UtilisateurBean utilisateurBean = new UtilisateurBean();
                    utilisateurBean.setLogin(utilisateur.getIdentifiant());
                    utilisateurBean.setNom(utilisateur.getNom());
                    utilisateurBean.setPrenom(utilisateur.getPrenom());

                    listDocumentForContratBean.setUtilisateur(utilisateurBean);
                }

                Map<Integer, String> refCategorieDocumentContratMap = new HashMap<Integer, String>();
                Map<String, Integer> mapFichiers = new HashMap<String, Integer>();
                for (EpmTDocumentMiseADispositionPassation epmTDocumentMiseADispositionPassation : epmTDocumentsSet) {

                    // recupere la valeur de l'index pour ce fichier
                    StringBuffer fichierBuffer = new StringBuffer();
                    String nomFichierTmp = new String(epmTDocumentMiseADispositionPassation.getNomFichier());
                    nomFichierTmp = nomFichierTmp.replaceAll("\\\\|/|:|\\*|\\?|\\\"|<|>|\\|", "_");
                    fichierBuffer.append(nomFichierTmp);
                    Integer indexFichier = (Integer) mapFichiers.get(fichierBuffer.toString());
                    // renomme le fichier si deja existant
                    if (indexFichier != null) {
                        indexFichier = indexFichier.intValue() + 1;
                        mapFichiers.remove(fichierBuffer.toString());
                        mapFichiers.put(fichierBuffer.toString(), indexFichier);
                        int idx = fichierBuffer.toString().lastIndexOf(".");
                        String nomFich = fichierBuffer.toString().substring(0, idx);
                        String extention = fichierBuffer.toString().substring(idx,
                                fichierBuffer.toString().length());
                        fichierBuffer = new StringBuffer();
                        fichierBuffer.append(nomFich).append("_").append(indexFichier)
                                .append(extention);
                    } else {
                        mapFichiers.put(fichierBuffer.toString(), 0);
                    }

                    DocumentMiseAdispositionBean documentMiseAdispositionBean = new DocumentMiseAdispositionBean();
                    documentMiseAdispositionBean.setNomDeFichier(fichierBuffer.toString());

                    String typeDocumentPassation = null;
                    if (epmTDocumentMiseADispositionPassation.getTypeDocumentPassation() != null &&
                            !epmTDocumentMiseADispositionPassation.getTypeDocumentPassation().trim().isEmpty()) {
                        typeDocumentPassation = epmTDocumentMiseADispositionPassation.getTypeDocumentPassation();
                        documentMiseAdispositionBean.setType(typeDocumentPassation);
                    }

                    if (epmTDocumentMiseADispositionPassation.getIdCategorieDocument() != 0) {
                        String value;
                        int id = epmTDocumentMiseADispositionPassation.getIdCategorieDocument();
                        try {
                            value = recupereCodeExterneCategorieDocument(refCategorieDocumentContratMap, id);

                            documentMiseAdispositionBean.setCategorie(value);
                        } catch (Exception e) {
                            LOG.error("Erreur lors de la récuépration de la catégorie du document mis à disposition" + epmTDocumentMiseADispositionPassation.getId(), e.fillInStackTrace());
                            throw new TechnicalNoyauException(e);
                        }

                    } else {
                        // check if empty
                        // le type on l'a setté ? ! ok ?
                        if (epmTDocumentMiseADispositionPassation.getIdCategorieDocument() != 0) {
                            String codeExterneCategorie = recupereCodeExterneCategorieDocument(refCategorieDocumentContratMap, epmTDocumentMiseADispositionPassation.getIdCategorieDocument());
                            documentMiseAdispositionBean.setCategorie(codeExterneCategorie);
                        }
                    }

                    if (epmTDocumentMiseADispositionPassation.getIdDocumentContrat() != null) {
                        EpmTDocumentContratCritere critere = new EpmTDocumentContratCritere();
                        critere.setIdDocumentContrat(epmTDocumentMiseADispositionPassation.getIdDocumentContrat());
                        EpmTDocumentContrat epmTDocumentContrat = null;
                        try {
                            epmTDocumentContrat = (EpmTDocumentContrat) serviceTechniqueGIM.chercherUniqueParCritere(critere);
                            documentMiseAdispositionBean.setDate(epmTDocumentContrat.getDateDocumentContrat());
                            documentMiseAdispositionBean.setCommentaire(epmTDocumentContrat.getCommentaireDocumentContrat());
                            documentMiseAdispositionBean.setObjet(epmTDocumentContrat.getObjetDocumentContrat());
                            documentMiseAdispositionBean.setPreRemplis(epmTDocumentContrat.isDocumentsAdministrables());

                            if (epmTDocumentContrat.getEtape() != null) {
                                documentMiseAdispositionBean.setStatut(epmTDocumentContrat.getEtape().getLibelle());
                            }

                        } catch (ApplicationNoyauException e) {
                            LOG.error("Erreur lors de la récupération du document du contrat." + e.fillInStackTrace());
                        }
                    } else if (epmTDocumentMiseADispositionPassation.getIdDocumentConserve() != null) {
                        DocumentConserveCritere critere = new DocumentConserveCritere();
                        critere.setId(epmTDocumentMiseADispositionPassation.getIdDocumentConserve());
                        EpmTDocumentConserve epmTDocumentConserve = null;
                        try {
                            epmTDocumentConserve = (EpmTDocumentConserve) serviceTechniqueGIM.chercherUniqueParCritere(critere);
                            documentMiseAdispositionBean.setDate(epmTDocumentConserve.getDateInsertion());
                            documentMiseAdispositionBean.setCommentaire(epmTDocumentConserve.getCommentaire());
                            documentMiseAdispositionBean.setObjet(epmTDocumentConserve.getObjet());

                            if (epmTDocumentConserve.getEtape() != null) {
                                documentMiseAdispositionBean.setStatut(epmTDocumentConserve.getEtape().getLibelle());
                            }

                        } catch (ApplicationNoyauException e) {
                            LOG.error("Erreur lors de la récupération du document du contrat." + e.fillInStackTrace());
                        }
                    }
                    documents.add(documentMiseAdispositionBean);
                    listDocuments.add(epmTDocumentMiseADispositionPassation);
                }

                String uri = serviceTechniqueGIM.zipperFichiers(listDocuments, identifiant + "_Zip");
                listDocumentForContratBean.setDocumentsList(documents);

                // recuperation du code externe de l'application
                Integer applicationTiersId = miseADisposition.getIdApplicationTiers();
                // si la mise a disposition a une application tiers
                if (applicationTiersId != null && applicationTiersId > 0) {
                    EpmTRefApplicationTiers epmTRefApplicationTiers = generiqueDAO.find(EpmTRefApplicationTiers.class, applicationTiersId);
                    if (epmTRefApplicationTiers == null) {
                        LOG.error("application tiers retournées est null pour l'id " + applicationTiersId);
                        throw new WebApplicationException(Response.Status.INTERNAL_SERVER_ERROR);
                    }
                    listDocumentForContratBean.setApplicationtiers(epmTRefApplicationTiers.getCodeExterne());
                } else {
                    // si la mise a disposition n'a pas une application tiers on
                    // set une chaine vide
                    listDocumentForContratBean.setApplicationtiers("");
                }

                listDocumentForContratBean.setMiseAdispositionId(String.valueOf(miseADisposition.getId()));
                if (miseADisposition.getIdContrat() != null && miseADisposition.getIdContrat() > 0) {
                    EpmTContratCritere contratCritere = new EpmTContratCritere();
                    contratCritere.setIdContrat(miseADisposition.getIdContrat());
                    List<EpmTContrat> contrats = (List<EpmTContrat>) serviceTechniqueGIM.chercherParCritere(contratCritere);
                    if (contrats != null && contrats.size() > 0 && contrats.get(0) != null) {
                        EpmTContrat contrat = contrats.get(0);
                        ContratMiseAdispositionBean contratMiseAdispositionBean = new ContratMiseAdispositionBean();
                        contratMiseAdispositionBean.setNumero(contrat.getNumeroContrat());
                        contratMiseAdispositionBean.setNumeroLot(contrat.getNumeroLot());
                        contratMiseAdispositionBean.setIntituleLot(contrat.getIntituleLot());
                        // Marché à bon de commande
                        //if(contrat.getFormePrix()!=null)
                        //    contratMiseAdispositionBean.setMarcheABonDeCommande(contrat.is)
                        if (contrat.getTypeContrat() != null)
                            contratMiseAdispositionBean.setType(contrat.getTypeContrat().getLibelle());
                        if (contrats.get(0).getIntituleLot() != null) {
                            contratMiseAdispositionBean.setObjet(contrat.getIntituleLot());
                        } else {
                            contratMiseAdispositionBean.setObjet(contrat.getObjetContrat());
                        }
                        Set<EpmTAttributaire> attributaires = contrat.getAttributaires();
                        for (EpmTAttributaire attributaire : attributaires) {
                            contratMiseAdispositionBean.setTitulaire(attributaire.getRaisonSocial());
                            if (attributaire.getMoyenNotification() != null) {
                                if (attributaire.getMoyenNotification().getId() == EpmTRefMoyenNotification.COURRIER_AR && attributaire.getDateAR() != null) {
                                    contratMiseAdispositionBean.setDateNotification(attributaire.getDateAR());
                                } else {
                                    if (attributaire.getMoyenNotification().getId() == EpmTRefMoyenNotification.REMISE_EN_MAIN_PROPRE && attributaire.getDateEnvoiRemise() != null) {
                                        contratMiseAdispositionBean.setDateNotification(attributaire.getDateEnvoiRemise());
                                    }
                                }
                            }
                            break;
                        }

                        listDocumentForContratBean.setMiseADispositionContrat(contratMiseAdispositionBean);
                    }

                }
                if (miseADisposition.getIdConsultation() != null
                        && miseADisposition.getIdConsultation() > 0) {
                    ConsultationCritere consultationCritere = new ConsultationCritere();
                    consultationCritere.setId(miseADisposition.getIdConsultation());
                    List<EpmTConsultation> consultations = (List<EpmTConsultation>) serviceTechniqueGIM.chercherParCritere(consultationCritere);
                    if (consultations != null && consultations.size() > 0 && consultations.get(0) != null) {
                        EpmTConsultation consultation = consultations.get(0);
                        ConsultationMiseAdispositionBean consultationMiseAdispositionBean = new ConsultationMiseAdispositionBean();
                        consultationMiseAdispositionBean.setNumeroConsultation(consultation.getNumeroConsultation());
                        consultationMiseAdispositionBean.setIntitule(consultation.getIntituleConsultation());
                        consultationMiseAdispositionBean.setObjet(consultation.getObjet());
                        consultationMiseAdispositionBean.setDureeMarche(consultation.getDureeMarche());
                        consultationMiseAdispositionBean.setUniteDureeDuMarche("NA");
                        if (consultation.getEpmTRefChoixMoisJour() != null) {
                            switch (consultation.getEpmTRefChoixMoisJour().getId()) {
                                case EpmTRefChoixMoisJour.EN_ANNEE:
                                    consultationMiseAdispositionBean.setUniteDureeDuMarche("ANNEE");
                                case EpmTRefChoixMoisJour.EN_JOUR:
                                    consultationMiseAdispositionBean.setUniteDureeDuMarche("JOUR");
                                case EpmTRefChoixMoisJour.EN_MOIS:
                                    consultationMiseAdispositionBean.setUniteDureeDuMarche("MOIS");
                                default:
                                    break;
                            }
                        }
                        if (consultation.getEpmTRefPouvoirAdjudicateur() != null) {
                            consultationMiseAdispositionBean.setPouvoirAdjudicateur(consultation.getEpmTRefPouvoirAdjudicateur().getLibelle());
                            consultationMiseAdispositionBean.setGroupementCommande(consultation.getEpmTRefPouvoirAdjudicateur().isGroupement());
                        }
                        if (consultation.getEpmTRefStatut() != null) {
                            consultationMiseAdispositionBean.setMarcheCloture(EpmTRefStatut.CLOS == consultation.getEpmTRefStatut().getId());
                        }

                        if (consultation.getIdConsultationInitiale() != null && consultation.getIdConsultationInitiale() > 0) {
                            try {
                                EpmTConsultation consultationInitiale = generiqueDAO.find(EpmTConsultation.class, consultation.getIdConsultationInitiale());
                                consultationMiseAdispositionBean.setNumeroConsultationInitiale(consultationInitiale.getNumeroConsultation());
                            } catch (Exception ex) {
                                LOG.error("Impossible de charger l'accord cadre : " + consultation.getIdConsultationInitiale());
                            }

                        }
                        String naturePrestation = consultation.getEpmTRefNature().getCodeExterne();
                        consultationMiseAdispositionBean.setNaturePrestation(naturePrestation);
                        EpmTRefDirectionService directionBeneficiaire = recupererDirectionServiceBeneficiaire(consultation.getDirServiceVision());
                        consultationMiseAdispositionBean.setCodeDirectionBeneficaire(directionBeneficiaire.getCode());
                        consultationMiseAdispositionBean.setLibelleDirectionBeneficaire(directionBeneficiaire.getNom());
                        consultationMiseAdispositionBean.setCodeDirectionResponsable(consultation.getEpmTRefDirectionService().getCode());
                        consultationMiseAdispositionBean.setLibelleDirectionResponsable(consultation.getEpmTRefDirectionService().getNom());
                        consultationMiseAdispositionBean.setIntitule(consultation.getIntituleConsultation());
                        consultationMiseAdispositionBean.setCodeProcedure(consultation.getEpmTRefProcedure().getCodeExterne());
                        String reference = consultation.getNumeroConsultation();
                        consultationMiseAdispositionBean.setReference(reference);
                        String statut = consultation.getEpmTRefStatut().getLibelle();
                        consultationMiseAdispositionBean.setStatut(statut);
                        try {
                            /*Recuperation de la date de pub*/
                            PubliciteCritere publiciteCritere = new PubliciteCritere();
                            publiciteCritere.setIdConsultation(consultation.getId());
                            EpmTPub publicite = (EpmTPub) serviceTechniqueGIM.chercherParCritere(publiciteCritere).get(0);
                            consultationMiseAdispositionBean.setDatePublicite(publicite.getDatePub());

                        } catch (Exception ex) {
                            LOG.error("Impossible de recuperer l'objet PUBLICITE pour la consultation " + consultation);
                        }

                        listDocumentForContratBean.setMiseADispositionConsultation(consultationMiseAdispositionBean);
                    }
                }

                // creation du fichier xml

                final long entier = Calendar.getInstance().getTimeInMillis();
                final String fiscDestPath = MiseAdispositionDocumentsWebService.repertoireTemporaire + String.valueOf(entier) + "_ListDocuments.xml";
                final String fiscDestName = String.valueOf(entier) + "_ListDocuments.xml";
                final File ficDest = new File(fiscDestPath);

                // creer un fichier pour les metadonnées
                JAXBContext context = JAXBContext.newInstance(ListDocumentsMiseAdispositionBean.class);
                Marshaller marshaller = context.createMarshaller();
                marshaller.setProperty("jaxb.encoding", "UTF-8");
                marshaller.setProperty("jaxb.formatted.output", true);
                marshaller.marshal(listDocumentForContratBean, ficDest);
                // ajouter le Fichier XML au zip
                ajouterFichierAuZip(fiscDestPath, fiscDestName, uri);

                // -----
                InputStream input = new FileInputStream(new File(uri));
                response.setHeader("Content-Disposition", "attachement; filename=\"" + identifiant + ".zip\"");
                OutputStream output = response.getOutputStream();
                IOUtils.copy(input, output);
                output.close();
                input.close();
                // mettre à jour les données de la mise à disposition

            } catch (TechnicalNoyauException e) {
                LOG.error(" pour la mise a disposition contrat numero " + identifiant, e);
                throw new WebApplicationException(Response.Status.INTERNAL_SERVER_ERROR);
            } catch (FileNotFoundException e) {
                LOG.error(" pour la mise a disposition numero " + identifiant, e);
                e.printStackTrace();
                throw new WebApplicationException(Response.Status.INTERNAL_SERVER_ERROR);
            } catch (IOException e) {
                LOG.error(" pour la mise a disposition numero " + identifiant, e);
                throw new WebApplicationException(Response.Status.INTERNAL_SERVER_ERROR);
            } catch (JAXBException e) {
                LOG.error(" erreur lors de la creation du fichier xml  pour la mise a disposition "
                        + identifiant, e);
                throw new WebApplicationException(Response.Status.INTERNAL_SERVER_ERROR);
            } catch (NonTrouveNoyauException e) {
                LOG.error(" noyau non trouvé pour le contrat  " + identifiant, e);
                throw new WebApplicationException(Response.Status.INTERNAL_SERVER_ERROR);
            }

            // }
            // return resultat;
            return null;
        } else {
            return errorToken;
        }
    }

    /**
     * @param refCategorieDocumentContratMap
     * @param idCategorie
     * @return
     * @throws NonTrouveNoyauException
     * @throws TechnicalNoyauException
     * @throws WebApplicationException
     * @throws TechnicalNoyauException
     * @throws NonTrouveNoyauException
     */
    private String recupereCodeExterneCategorieDocument(Map<Integer, String> refCategorieDocumentContratMap, final int idCategorie) {

        String value = null;
        if (refCategorieDocumentContratMap.get(idCategorie) == null) {

            EpmTRefCategorieDocumentContrat epmTRefCategorieDocumentContrat = generiqueDAO.find(EpmTRefCategorieDocumentContrat.class, idCategorie);
            if (epmTRefCategorieDocumentContrat == null) {
                LOG.error("La catégorie du docment est nulle ");
                throw new WebApplicationException(Response.Status.INTERNAL_SERVER_ERROR);
            }
            value = epmTRefCategorieDocumentContrat.getCodeExterne();

            if (value == null) {
                value = "";
            } else {
                refCategorieDocumentContratMap.put(idCategorie, value);
            }
        } else {
            value = refCategorieDocumentContratMap.get(idCategorie);
        }
        return value;
    }

    /**
     * cette fonction permet d'ajouter un fichier avec le chemin uriFichierau
     * zip avec le chemin uriZip
     * @param uriFichier : chemin de fichier à ajouter
     * @param uriZip : chemin du fichier zip
     * @throws IOException
     */
    private final void ajouterFichierAuZip(String uriFichier, String nomDuFichier, String uriZip) throws IOException {
        Map<String, String> zipProperties = new HashMap<String, String>();
        zipProperties.put("create", "false");
        zipProperties.put("encoding", "UTF-8");
        // pour windows
        String uriZipModified = uriZip.replaceAll("\\\\", "/");
        // pour linux enelver le premier slash
        if (uriZipModified.startsWith("/")) {
            uriZipModified = uriZipModified.replaceFirst("/", "");
        }
        LOG.info("urizipmodified :{}", uriZipModified);
        URI zipDisck = URI.create("jar:file:/" + uriZipModified);
        java.nio.file.FileSystem zipfs = java.nio.file.FileSystems.newFileSystem(zipDisck,
                zipProperties);
        File f = new File(uriFichier);
        URI uri = f.toURI();
        java.nio.file.Path zipFilePath = zipfs.getPath(nomDuFichier);
        java.nio.file.Path addNewFile = Paths.get(uri);
        Files.copy(addNewFile, zipFilePath);
        zipfs.close();
    }

    /**
     * aquitte la mise à disposition
     * @param identifiant
     * @param statut REUSSIE,ECHOUE
     * @param token
     * @return
     */
    @SuppressWarnings("unchecked")
    @GET
    @Path("/{identifiant}/{statut}")
    @Produces(MediaType.TEXT_XML)
    public JAXBElement<? extends Object> serviceAquitementDeLaMiseAdisposition(
            @PathParam("identifiant") Integer identifiant, @PathParam("statut") String statut,
            @QueryParam(ConstantesRestWebService.XML_QNAME_TOKEN) String token) {

        AuthentificationRestWebService auth = new AuthentificationRestWebService();
        JAXBElement<ErreurBean> errorToken = auth.verificationToken(token);
        String message = errorToken.getValue().getMessage();
        if (message == null && message.isEmpty()) {

            JAXBElement<ErreurBean> resError = new JAXBElement<ErreurBean>(new QName(
                    ConstantesRestWebService.XML_QNAME_ERREUR), ErreurBean.class, new ErreurBean());
            JAXBElement<MisADispositionAcquitementBean> res = new JAXBElement<MisADispositionAcquitementBean>(
                    new QName(ConstantesRestWebService.XML_QNAME_RESULTAT),
                    MisADispositionAcquitementBean.class, null);
            // tester si le statut est vide
            if (statut == null || statut.isEmpty()) {
                LOG.error("Probleme : le statut non fourni pour le contrat " + identifiant);
                throw new WebApplicationException(Response.Status.INTERNAL_SERVER_ERROR);
            }
            // obtenir le code statut qui se trouve sur la base
            int statutCode = StatutRecuperationEnum.getCode(statut);
            if (statutCode < StatutRecuperationEnum.ATTENTE.getCode()) {
                LOG.error(" Probleme : le statut" + statut + " non repartorié pour le contrat " + identifiant);
                throw new WebApplicationException(Response.Status.INTERNAL_SERVER_ERROR);
            }

            EpmTMiseADispositionCritere miseADispositionCritere = new EpmTMiseADispositionCritere();
            miseADispositionCritere.setIdMiseAdisposition(identifiant);
            miseADispositionCritere.setExecution(null);
            // recuper la list des contrats avec le numero de consultation
            // fourni , cette liste peut etre vide ou contient un seul
            // element

            List<EpmTMiseADisposition> miseADispositionList;
            try {
                miseADispositionList = (List<EpmTMiseADisposition>) serviceTechniqueGIM
                        .chercherParCritere(miseADispositionCritere);

                // check si la liste des contrats est vide
                if (miseADispositionList == null || miseADispositionList.size() == 0) {
                    LOG.error("Mise a disposition numero {} est non  trouvé", identifiant);
                    throw new WebApplicationException(Response.Status.INTERNAL_SERVER_ERROR);
                }

                EpmTMiseADisposition miseADisposition = miseADispositionList.get(0);
                // check si la liste des contrats est null
                if (miseADisposition == null) {
                    LOG.error("la base retoune une mise à disposition null avec  le ID"
                            + identifiant);
                    throw new WebApplicationException(Response.Status.INTERNAL_SERVER_ERROR);
                }
                miseADisposition.setStatutRecuperation(statutCode);
                miseADisposition.setDateRecuperation(Calendar.getInstance().getTime());

                serviceTechniqueGIM.modifier(miseADisposition);
            } catch (TechnicalNoyauException e) {
                LOG.error("pour la mise à disposition " + identifiant, e);
                throw new WebApplicationException(Response.Status.INTERNAL_SERVER_ERROR);
            }

            MisADispositionAcquitementBean misADispositionAcquitementBean = new MisADispositionAcquitementBean();
            misADispositionAcquitementBean.setResponse("OK");
            res.setValue(misADispositionAcquitementBean);
            return res;
        } else {
            return errorToken;
        }

    }

    /**
     * cette webmethode retourne la liste des mises à disposition en attente
     * d'etre transferé, <br/>
     * exemple: <br/>
     * &lt;resultat&gt; <br/>
     * &lt;listMiseAdispostion&gt; <br/>
     * &lt;miseAdisposition&gt; <br/>
     * &lt;applicationtiers&gt;alfresco&lt;/applicationtiers&gt; <br/>
     * &lt;id&gt;1&lt;/id&gt; <br/>
     * &lt;/miseAdisposition&gt; <br/>
     * &lt;miseAdisposition&gt; <br/>
     * &lt;applicationtiers&gt;airs&lt;/applicationtiers&gt; <br/>
     * &lt;id&gt;2&lt;/id&gt; <br/>
     * &lt;/miseAdisposition&gt; <br/>
     * &lt;/listMiseAdispostion&gt; <br/>
     * &lt;/resultat&gt;
     * @param response
     * @param token
     * @return
     */
    @GET
    @Path("/listeMisADisposition")
    @Produces(MediaType.APPLICATION_XML)
    public JAXBElement<? extends Object> getListeMiseADisposition(
            @Context HttpServletResponse response,
            @QueryParam(ConstantesRestWebService.XML_QNAME_TOKEN) String token,
            @QueryParam(ConstantesRestWebService.XML_QNAME_APPLICATION_TIERS) String applicationTiers) {

        AuthentificationRestWebService auth = new AuthentificationRestWebService();
        JAXBElement<ErreurBean> errorToken = auth.verificationToken(token);
        String message = errorToken.getValue().getMessage();
        if (message == null && message.isEmpty()) {
            JAXBElement<ListMiseAdispositionBean> res = new JAXBElement<ListMiseAdispositionBean>(
                    new QName(ConstantesRestWebService.XML_QNAME_RESULTAT),
                    ListMiseAdispositionBean.class, null);

            EpmTMiseADispositionCritere miseADispositionCritere = new EpmTMiseADispositionCritere();
            // recuperation de l'application tiers
            Integer idApplicationTiers = null;
            if (applicationTiers != null && !applicationTiers.isEmpty()) {
                EpmTRefApplicationTiersCritere applicationTiersCritere = new EpmTRefApplicationTiersCritere();
                applicationTiersCritere.setCodeExterne(applicationTiers);
                try {
                    List<EpmTRefApplicationTiers> listApplicationTiers = generiqueDAO.findByCritere(applicationTiersCritere);
                    if (listApplicationTiers != null &&  listApplicationTiers.size() > 0 && listApplicationTiers.get(0) != null) {
                        idApplicationTiers = listApplicationTiers.get(0).getId();
                    }

                } catch (TechnicalNoyauException e) {
                    LOG.error(" lors de la recupération de l'application tiers" + applicationTiers,
                            e);
                    throw new WebApplicationException(Response.Status.INTERNAL_SERVER_ERROR);
                }

                if (idApplicationTiers == null) {
                    LOG.error("l'application tiers {} n'existe pas  dans la base de données",
                            applicationTiers);
                    throw new WebApplicationException(Response.Status.INTERNAL_SERVER_ERROR);
                }

            }

            // recuperer toutes les mise à disposition qui sont en etat
            // d'attente
            miseADispositionCritere.setStatutRecuperation(1);
            // setter l'application tiers
            if (idApplicationTiers != null) {
                miseADispositionCritere.setIdApplicationTiers(idApplicationTiers);
            }
            ListMiseAdispositionBean listMiseAdispositionBean = new ListMiseAdispositionBean();
            try {
                @SuppressWarnings("unchecked")
                List<EpmTMiseADisposition> listEpmTMiseADisposition = (List<EpmTMiseADisposition>) serviceTechniqueGIM.chercherParCritere(miseADispositionCritere);
                // catch excepetion if list est null
                if (listEpmTMiseADisposition == null) {
                    LOG.error(" la liste retournée est null lors de la recupération des mises à disposition");
                    throw new WebApplicationException(Response.Status.INTERNAL_SERVER_ERROR);
                }

                List<MiseAdispositionBean> listMiseAdisposition = new ArrayList<MiseAdispositionBean>();
                for (EpmTMiseADisposition epmTMiseADisposition : listEpmTMiseADisposition) {

                    // Ne pas ajouter la Mise a Disposition si elle n'a pas de
                    // documents
                    Set<EpmTDocumentMiseADispositionPassation> epmTDocumentsSet = epmTMiseADisposition
                            .getDocumentsMiseADisposition();
                    if (epmTDocumentsSet != null && epmTDocumentsSet.size() > 0) {
                        MiseAdispositionBean miseAdispositionBean = new MiseAdispositionBean();
                        miseAdispositionBean.setId(String.valueOf(epmTMiseADisposition.getId()));
                        listMiseAdisposition.add(miseAdispositionBean);
                    }
                }
                listMiseAdispositionBean.setMiseAdispositionList(listMiseAdisposition);
            } catch (TechnicalNoyauException e) {
                LOG.error("lors de la recupération des mises à disposition", e);
                throw new WebApplicationException(Response.Status.INTERNAL_SERVER_ERROR);
            }
            res.setValue(listMiseAdispositionBean);
            return res;
        } else {
            return errorToken;
        }
    }

    private EpmTRefDirectionService recupererDirectionServiceBeneficiaire(int dirServiceVision) {
        try {
            Collection<EpmTRefDirectionService> direcServiceBenifs = referentielsServiceLocal.getAllReferentiels().getRefDirectionServiceLecture();
            for (EpmTRefDirectionService dirServiceBenif : direcServiceBenifs)
                if (dirServiceBenif.getId() == dirServiceVision)
                    return dirServiceBenif;
        } catch (NonTrouveNoyauException e) {
            LOG.error("Erreur :" + e.getMessage());

        } catch (TechnicalNoyauException e) {
            LOG.error("Erreur :" + e.getMessage());
        }

        return null;
    }

    /**
     * @param serviceTechniqueGIM the serviceTechniqueGIM to set
     */
    public final void setServiceTechniqueGIM(ServiceTechniqueGIM serviceTechniqueGIM) {
        MiseAdispositionDocumentsWebService.serviceTechniqueGIM = serviceTechniqueGIM;
    }

    public final void setReferentielsServiceLocal(ReferentielsServiceLocal referentielsServiceLocal) {
        MiseAdispositionDocumentsWebService.referentielsServiceLocal = referentielsServiceLocal;
    }

    public final void setGeneriqueDAO(GeneriqueDAO generiqueDAO) {
        MiseAdispositionDocumentsWebService.generiqueDAO = generiqueDAO;
    }

    public final void setRepertoireTemporaire(String repertoireTemporaire) {
        MiseAdispositionDocumentsWebService.repertoireTemporaire = repertoireTemporaire;
    }

}
