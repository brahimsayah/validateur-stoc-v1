/**
 * 
 */
package fr.atexo.rsem.noyau.ws.beans.miseADisposition;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * @author KBE
 * 
 */
@XmlRootElement(name = "resultat")
public class AcquitementMiseAdispositionBean {

    private String response;

    /**
     * statut de l'envoi acquitté attente envoyer TODO c'est souvent acquitté
     */
    private String statut;

    /**
     * la mise a disposition de l'envoi
     */
    private String miseAdisposition;

    /**
     * 
     */
    public AcquitementMiseAdispositionBean() {

    }

    /**
     * @return the statut
     */
    public String getStatut() {
	return statut;
    }

    /**
     * @param statut
     *            the statut to set
     */
    public void setStatut(String statut) {
	this.statut = statut;
    }

    /**
     * @return the miseAdisposition
     */
    public String getMiseAdisposition() {
	return miseAdisposition;
    }

    /**
     * @param miseAdisposition
     *            the miseAdisposition to set
     */
    public void setMiseAdisposition(String miseAdisposition) {
	this.miseAdisposition = miseAdisposition;
    }

    @XmlElement
    public String getResponse() {
	return response;
    }

    public void setResponse(String reponse) {
	this.response = reponse;
    }

}
