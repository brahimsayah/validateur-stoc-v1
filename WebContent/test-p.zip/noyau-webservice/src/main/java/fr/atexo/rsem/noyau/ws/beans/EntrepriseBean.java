package fr.atexo.rsem.noyau.ws.beans;

/**
 * Utilise pour l'echange d'informations avec des entites externes a RSEM.
 * @author RVI
 * @version $Revision$, $Date$, $Author$
 */
public class EntrepriseBean {

    private String siret;

    private String raisonSociale;

    private AdresseBean adresse;

    public final AdresseBean getAdresse() {
        return adresse;
    }

    public final void setAdresse(final AdresseBean valeur) {
        this.adresse = valeur;
    }

    public final String getSiret() {
        return siret;
    }

    public final void setSiret(final String valeur) {
        this.siret = valeur;
    }

    public final String getRaisonSociale() {
        return raisonSociale;
    }

    public final void setRaisonSociale(final String valeur) {
        this.raisonSociale = valeur;
    }
}
