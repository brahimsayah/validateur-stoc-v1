package fr.atexo.rsem.noyau.ws.rest.metier;

import fr.atexo.rsem.noyau.ws.beans.redaction.Consultation;
import fr.paris.epm.noyau.commun.exception.ApplicationNoyauException;
import fr.paris.epm.noyau.commun.exception.TechnicalNoyauException;
import fr.paris.epm.noyau.persistance.EpmTConsultation;
import fr.paris.epm.noyau.persistance.EpmTUtilisateur;

public interface InitialisationConsultationWebServiceGIM {

    /**
     * A partir d'une consultation externe, mise a jour ou création de la consultation associée
     * 
     * @param consultation consultation externe passée par flux XML
     * @param utilisateur utilisateur associe a la consultation.
     * @throws TechnicalNoyauException
     * @throws ApplicationNoyauException
     */
    EpmTConsultation miseAJourConsultation(final Consultation consultation, final EpmTUtilisateur utilisateur);

}
