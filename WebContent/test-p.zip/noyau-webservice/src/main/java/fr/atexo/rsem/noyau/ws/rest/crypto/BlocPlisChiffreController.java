package fr.atexo.rsem.noyau.ws.rest.crypto;

import fr.atexo.rsem.noyau.ws.beans.ErreurBean;
import fr.atexo.rsem.noyau.ws.rest.AuthentificationRestWebService;
import fr.atexo.rsem.noyau.ws.util.MultipartRequest;
import fr.paris.epm.noyau.commun.exception.DataException;
import fr.paris.epm.noyau.commun.exception.NonTrouveNoyauException;
import fr.paris.epm.noyau.commun.exception.TechnicalNoyauException;
import fr.paris.epm.noyau.metier.FichierSurDisqueGRM;
import fr.paris.epm.noyau.metier.PlisCritere;
import fr.paris.epm.noyau.persistance.EpmTDocument;
import fr.paris.epm.noyau.persistance.EpmTFichierSurDisque;
import fr.paris.epm.noyau.persistance.EpmTPlisGenerique;
import fr.paris.epm.noyau.service.GeneriqueServiceSecurise;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletResponse;
import javax.xml.bind.JAXBElement;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

/**
 * Created by ael on 16/03/17.
 */
// The Java class will be hosted at the URI path "/blocPlis"
@Controller
//@Api(value = "blocPlisChiffre", description = "Ce WebService récupére un bloc plis chiffré", consumes = "application/json")
public class BlocPlisChiffreController {

    private static final Logger LOG = LoggerFactory.getLogger(BlocPlisChiffreController.class);

    @Autowired
    private GeneriqueServiceSecurise depotService ;

    @Autowired
    private FichierSurDisqueGRM fichierSurDisqueGRM;

    private static String cheminRacine;

    @RequestMapping(value = "/blocPlisChiffre/{idPlisMpe}/{token}", method=RequestMethod.GET)
    public ResponseEntity<Object> blocPlisChiffre(HttpServletResponse response, @PathVariable int idPlisMpe,
                                                  @PathVariable("token") String token) {

        LOG.info("/blocPlisChiffre/" + idPlisMpe + "/" + token);

        AuthentificationRestWebService auth = new AuthentificationRestWebService();
        JAXBElement<ErreurBean> errorToken = auth.verificationToken(token);

        // en cas d'un jeton authentification invalide on retourne un message d'erreur d'authentification avec le statut UNAUTHORIZED
        if (!StringUtils.isEmpty(errorToken.getValue().getMessage()))
            return erreur("Accés non autorisé : ", HttpStatus.UNAUTHORIZED);

        try {
            //on recupére le pli concerné
            EpmTPlisGenerique pli = recupererPliGenereique(idPlisMpe);
            if (pli == null)
                return erreur("Pli non trouvé : " ,HttpStatus.NOT_FOUND);

            //on trie la liste des blocs selon le nom de fichier pour le rassemeblement se fait correctement
            List<EpmTDocument> listeBlocs = new ArrayList<>(pli.getBlocsPlis());
            Collections.sort(listeBlocs, new Comparator<EpmTDocument>() {
                @Override
                public int compare(EpmTDocument epmTDocument1, EpmTDocument epmTDocument2) {
                    if (epmTDocument1.getId() < epmTDocument2.getId()) {
                        return -1;
                    } else {
                        return 1;
                    }
                }
            });

            response.addHeader("BOUNDARY", MultipartRequest.BOUNDARY);
            ServletOutputStream outputStream = response.getOutputStream();
            MultipartRequest multi = new MultipartRequest(outputStream);
            for (Object objet : listeBlocs) {
                EpmTDocument document = (EpmTDocument)objet;
                if (document == null) // en cas d'un flux vide on retourne un tableau binaire vide avec le statut not found
                    return erreur("L'un des blocs est erroné : ", HttpStatus.FORBIDDEN);

                //extraire le fichier attaché au document
                File file = recupererFichier(document);

                if (file == null)// en cas d'un fichier vide on retourne un message d'erreur avec le statut FORBIDDEN
                    return erreur("L'un des blocs est erroné : ", HttpStatus.FORBIDDEN);

                multi.ajouterFichier(document.getNomFichier(), file);
            }
            multi.fin();
            return new ResponseEntity<Object>("Transfert terminé en succés", HttpStatus.OK);
        } catch (DataException e) {
            return erreur("Erreur DataException : ", HttpStatus.FORBIDDEN);
        } catch (IOException e) {
            return erreur("Erreur IOException : ", HttpStatus.FORBIDDEN);
        } catch (NonTrouveNoyauException e) {
            return erreur("Erreur NonTrouveNoyauException : ", HttpStatus.FORBIDDEN);
        } catch (TechnicalNoyauException e) {
            return erreur("Erreur TechnicalNoyauException : ", HttpStatus.FORBIDDEN);
        } catch (Exception e) {
            return erreur("Erreur Exception générale : ", HttpStatus.FORBIDDEN);
        }
    }

    private EpmTPlisGenerique recupererPliGenereique(int idPlisMpe ) throws TechnicalNoyauException {
        EpmTPlisGenerique epmTPli = null;

        PlisCritere plisCritere = new PlisCritere();
        plisCritere.setIdRegistreDemat(idPlisMpe);
        List<EpmTPlisGenerique> plisList = depotService.chercherEpmTObject(0, plisCritere);
        if (!plisList.isEmpty())
            epmTPli = plisList.get(0);

        if (epmTPli == null)
            throw new DataException(" Plis " +  idPlisMpe + " non trouvé !");

        return epmTPli;
    }

    private ResponseEntity<Object> erreur(String message, HttpStatus statut) {
        LOG.error(message + this.getClass().getName() + " : " + getLineNumber());
        return new ResponseEntity<Object>(message, statut);
    }

    private static int getLineNumber() {
        return Thread.currentThread().getStackTrace()[2].getLineNumber();
    }

    private File recupererFichier(EpmTDocument document) throws NonTrouveNoyauException, TechnicalNoyauException {
        int idFichier = document.getFichierSurDisque().getId();
        EpmTFichierSurDisque fichierSurDisque = (EpmTFichierSurDisque) fichierSurDisqueGRM.charger(idFichier);
        String fileName = cheminRacine + File.separator + fichierSurDisque.getCheminFichier() + File.separator + fichierSurDisque.getNomFichier();
        return new File(fileName);
    }

    public void setCheminRacine(String cheminRacine) {
        BlocPlisChiffreController.cheminRacine = cheminRacine;
    }

}