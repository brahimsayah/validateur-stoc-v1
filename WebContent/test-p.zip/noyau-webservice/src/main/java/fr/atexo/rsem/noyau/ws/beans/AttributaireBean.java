package fr.atexo.rsem.noyau.ws.beans;

import java.util.Date;
import java.util.List;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElementWrapper;

/**
 * Bean répresentant les informations du attributaire d'une consultation. Ce
 * bean est utilisé par le Webservice REST pour échanges des données du contrat
 * d'EPM avec des applications tiers
 
 * @author Rebeca Dantas
 * @version $Revision$, $Date$, $Author$
 */
public class AttributaireBean {

    private String raisonSocial;
    private String siret;
    private String adresse;
    private String codePostal;
    private String commune;
    private String telephone;
    private String fax;
    private String email;
    private List<ContractantBean> contractants;
    private String moyenNotification;
    private Date dateNotification;
    private String typeAttributaire;
    
    public String getSiret() {
        return siret;
    }
    
    public String getAdresse() {
        return adresse;
    }
    
    public String getCodePostal() {
        return codePostal;
    }
    
    public String getCommune() {
        return commune;
    }
    
    public String getFax() {
        return fax;
    }
    
    public String getEmail() {
        return email;
    }
    
    public String getRaisonSocial() {
        return raisonSocial;
    }
    
	public final String getTelephone() {
		return telephone;
	}
    
    public void setSiret(String valeur) {
        this.siret = valeur;
    }
    
    public void setAdresse(String valeur) {
        this.adresse = valeur;
    }
    
    public void setCodePostal(String valeur) {
        this.codePostal = valeur;
    }
    
    public void setCommune(String valeur) {
        this.commune = valeur;
    }
    
	public final void setTelephone(String valeur) {
		this.telephone = valeur;
	}

	public void setFax(String valeur) {
        this.fax = valeur;
    }
    
    public void setEmail(String valeur) {
        this.email = valeur;
    }
    
    public void setRaisonSocial(String valeur) {
        this.raisonSocial = valeur;
    }

    /**
     * @return the contractants
     */
    @XmlElementWrapper(name = "contractants")
    @XmlElement(name = "contractant")    
    public List<ContractantBean> getContractants() {
        return contractants;
    }

    /**
     * @param contractants the contractants to set
     */
    public void setContractants(List<ContractantBean> valeur) {
        this.contractants = valeur;
    }

	/**
	 * @return the moyenNotification
	 */
	public String getMoyenNotification() {
		return moyenNotification;
	}

	/**
	 * @param moyenNotification the moyenNotification to set
	 */
	public void setMoyenNotification(String valeur) {
		moyenNotification = valeur;
	}
    
	
	public Date getDateNotification() {
		return dateNotification;
	}

	public void setDateNotification(Date dateDeNotification) {
		dateNotification = dateDeNotification;
	}

    public final String getTypeAttributaire() {
        return typeAttributaire;
    }

    public final void setTypeAttributaire(String valeur) {
        this.typeAttributaire = valeur;
    }
    
    
}
