package fr.atexo.rsem.noyau.ws.service;

import fr.atexo.rsem.noyau.ws.beans.AvenantBean;
import fr.atexo.rsem.noyau.ws.beans.ConsultationBean;
import fr.paris.epm.noyau.commun.exception.NonTrouveNoyauException;
import fr.paris.epm.noyau.commun.exception.TechnicalNoyauException;
import fr.paris.epm.noyau.persistance.EpmTAvenant;
import fr.paris.epm.noyau.persistance.EpmTContrat;

import java.util.List;
import java.util.Map;

/**
 * Service pour transformer l'objet EpmTConsultation en ConsultationBean (objet externalisé)
 *
 * @author RDA
 * @version $Revision$, $Date$, $Author$
 */
public interface AttributionMarcheService {

	/**
	 * Conversion des objets EpmTConsultation vers des objets @{ConsultationBean} et @{ContratBean} qui serviront
	 * de réponse aux appels du webservice contrat
	 *
	 * @return consultations : une liste de consultations attribués
	 * @throws TechnicalNoyauException
	 * @throws NonTrouveNoyauException
	 */
	List<ConsultationBean> conversionEpmTConsultationVersConsultationBean(Map<String, List<EpmTContrat>> contratsParConsultation);

	/**
	 * Conversion des objets EpmTAvenant vers des objets @{AvenantBean} qui
	 * servira de réponse aux appels du webservice contrat
	 *
	 * @param epmTAvenants
	 *            : l'ensemble d'avenants recupérés en base de données
	 * @return avenants : une liste d'avenants attribués
	 * @throws TechnicalNoyauException
	 */
	List<AvenantBean> conversionEpmTAvenantVersConsultationBean(Map<Integer, List<EpmTContrat>> contratsParAvenant);

	/**
	 * Conversion des objets  {@link EpmTAvenant} vers des objets {@link AvenantBean} qui
	 * servira de réponse aux appels du webservice contrat
	 * @param {@link List} de {@link EpmTAvenant epmTAvenants}
	 * @return {@link List} de {@link AvenantBean}
	 * @throws TechnicalNoyauException
	 */
	List<AvenantBean> conversionEpmTAvenantVersAvenantBean(List<EpmTAvenant> epmTAvenants);

}
