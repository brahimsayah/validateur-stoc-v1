package fr.atexo.rsem.noyau.ws.rest.metier;

import fr.atexo.rsem.noyau.ws.beans.redaction.*;
import fr.paris.epm.noyau.commun.Constantes;
import fr.paris.epm.noyau.commun.exception.ApplicationNoyauException;
import fr.paris.epm.noyau.commun.exception.NonTrouveNoyauException;
import fr.paris.epm.noyau.commun.exception.TechnicalNoyauException;
import fr.paris.epm.noyau.metier.*;
import fr.paris.epm.noyau.metier.objetvaleur.EtapeSimple;
import fr.paris.epm.noyau.metier.objetvaleur.Referentiels;
import fr.paris.epm.noyau.metier.objetvaleur.Selects;
import fr.paris.epm.noyau.persistance.*;
import fr.paris.epm.noyau.persistance.referentiel.*;
import fr.paris.epm.noyau.service.ReferentielsServiceLocal;
import org.dozer.DozerBeanMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.xml.datatype.XMLGregorianCalendar;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;

/**
 * Classe Métier qui fournit la méthode pour la mise à jour de consultation
 */
public class InitialisationConsultationWebServiceGIMImpl implements InitialisationConsultationWebServiceGIM {


    private static final Logger LOG = LoggerFactory.getLogger(InitialisationConsultationWebServiceGIMImpl.class);

    private AdministrationGIM administrationGIM;
    private CalendrierGIM calendrierGIM;
    private DozerBeanMapper conversionService;
    private ConsultationGIM consultationGIM;
    private GeneriqueDAO generiqueDAO;
    private ReferentielsServiceLocal referentielsServiceLocal;
    private SelectsGIM selectsService;

    private static final String IDENTIFIANT_TRANCHE_FIXE = "0";

    /**
     * A partir d'une consultation externe, mise a jour ou création de la consultation associée
     *
     * @param consultation consultation externe passée par flux XML
     * @param utilisateur utilisateur associe a la consultation.
     * @throws TechnicalNoyauException
     * @throws ApplicationNoyauException
     */
    @Override
    public EpmTConsultation miseAJourConsultation(final Consultation consultation, final EpmTUtilisateur utilisateur)
            throws TechnicalNoyauException, ApplicationNoyauException {

        EpmTConsultation epmTConsultation = null;
        if (consultation.getReferenceExterne() != null && !consultation.getReferenceExterne().isEmpty()) {
            String referenceRSEM = consultation.getReferenceExterne().trim();
            ConsultationCritere consultationCritere = new ConsultationCritere();
            consultationCritere.setNumeroConsultationExterne(referenceRSEM);
            consultationCritere.setIdOrganisme(utilisateur.getIdOrganisme());
            try {
                epmTConsultation = (EpmTConsultation) administrationGIM.chercherUniqueParCritere(consultationCritere);
            } catch (TechnicalNoyauException | ApplicationNoyauException e) {
                LOG.error(e.getMessage(), e.fillInStackTrace());
                throw e;
            }
        }

        Referentiels referentiels = referentielsServiceLocal.getAllReferentiels();
        Selects selects = selectsService.getAllSelects();
        if (epmTConsultation == null) {
            epmTConsultation = conversionService.map(consultation, EpmTConsultation.class);
            epmTConsultation.setNumeroConsultation(consultation.getNumeroConsultation());
            epmTConsultation.setNumeroConsultationExterne(consultation.getReferenceExterne());
            // Autre opération
            epmTConsultation.setAutreOperation("Autre opération");

            // Utilisateur
            epmTConsultation.setEpmTUtilisateur(utilisateur);
            epmTConsultation.setDateModification(Calendar.getInstance());
            epmTConsultation.setIdOrganisme(utilisateur.getIdOrganisme());

            if (consultation.getClausesSociales() != null)
                epmTConsultation.setClausesSociales("oui");
            else
                epmTConsultation.setClausesSociales("non");

            if (consultation.getClausesEnvironnementales() != null)
                epmTConsultation.setClausesEnvironnementales("oui");
            else
                epmTConsultation.setClausesEnvironnementales("non");

            initialiserValeurConsultation(epmTConsultation, consultation, referentiels, selects);

            // Creation du calendrier...
            epmTConsultation = consultationGIM.modifierConsultation(epmTConsultation,false);

            //mise à jour de la date de modification en cas d'une consultation déjà existante
        } else {
            Calendar dateModification = Calendar.getInstance();
            dateModification.setTime(new Date());
            if (consultation.getIntitule() != null && !consultation.getIntitule().equals(epmTConsultation.getIntituleConsultation())) {
                epmTConsultation.setDateModification(dateModification);
            } else if (consultation.getObjet() != null && !consultation.getObjet().equals(epmTConsultation.getObjet())) {
                epmTConsultation.setDateModification(dateModification);
            } else if (consultation.getTypeProcedure() != null && epmTConsultation.getEpmTRefProcedure() != null && !consultation.getTypeProcedure().equals(epmTConsultation.getEpmTRefProcedure().getAcronyme())) {
                epmTConsultation.setDateModification(dateModification);
            } else if (epmTConsultation.getRefReponseElectronique() != null && consultation.getReponseElectronique() != null && !consultation.getReponseElectronique().equals(epmTConsultation.getRefReponseElectronique().getCodeExterne())) {
                epmTConsultation.setDateModification(dateModification);
            } else if (epmTConsultation.getSignature() != null && ((consultation.isSignatureELectronique() && !epmTConsultation.getSignature()) || !consultation.isSignatureELectronique() && epmTConsultation.getSignature())) {
                epmTConsultation.setDateModification(dateModification);
            } else if (epmTConsultation.getChiffrement() != null && ((consultation.isChiffrementPlis() && !epmTConsultation.getChiffrement()) || (!consultation.isChiffrementPlis() && epmTConsultation.getChiffrement()))) {
                epmTConsultation.setDateModification(dateModification);
            } else if ((Constantes.OUI.equals(epmTConsultation.getEnveloppeUniqueReponse()) && !consultation.isEnveloppeUnique()) || (Constantes.NON.equals(epmTConsultation.getEnveloppeUniqueReponse()) && consultation.isEnveloppeUnique())) {
                epmTConsultation.setDateModification(dateModification);
            } else if (consultation.getNaturePrestation() != null && epmTConsultation.getEpmTRefNature() != null && consultation.getNaturePrestation().equals(epmTConsultation.getEpmTRefNature().getLibelle())) {
                epmTConsultation.setDateModification(dateModification);
            } else if (consultation.getPouvoirAdjudicateur() != null && epmTConsultation.getEpmTRefPouvoirAdjudicateur() != null && consultation.getPouvoirAdjudicateur().equals(epmTConsultation.getEpmTRefPouvoirAdjudicateur().getLibelle())) {
                epmTConsultation.setDateModification(dateModification);
            } else if (consultation.getStatut() != null && epmTConsultation.getEpmTRefStatut() != null && consultation.getStatut().equals(epmTConsultation.getEpmTRefStatut().getLibelle())) {
                epmTConsultation.setDateModification(dateModification);
            } else if ((Constantes.OUI.equals(epmTConsultation.getTransverse()) && !consultation.isTransverse()) || (Constantes.NON.equals(epmTConsultation.getTransverse()) && consultation.isTransverse())) {
                epmTConsultation.setDateModification(dateModification);
            } else if (consultation.getArticle() != null && epmTConsultation.getEpmTRefArticle() != null && consultation.getArticle().equals(epmTConsultation.getEpmTRefArticle().getLibelle())) {
                epmTConsultation.setDateModification(dateModification);
            } else if (consultation.getDirectionService() != null && epmTConsultation.getEpmTRefDirectionService() != null && consultation.getDirectionService().equals(epmTConsultation.getEpmTRefDirectionService().getLibelle())) {
                epmTConsultation.setDateModification(dateModification);
            }

            conversionService.map(consultation, epmTConsultation);
            epmTConsultation.setNumeroConsultation(consultation.getNumeroConsultation());

            if (consultation.getClausesSociales() != null)
                epmTConsultation.setClausesSociales("oui");
            else
                epmTConsultation.setClausesSociales("non");

            if (consultation.getClausesEnvironnementales() != null)
                epmTConsultation.setClausesEnvironnementales("oui");
            else
                epmTConsultation.setClausesEnvironnementales("non");

            initialiserValeurConsultation(epmTConsultation, consultation, referentiels, selects);
        }
        epmTConsultation.setNumeroConsultationExterne(consultation.getReferenceExterne());

        // Date de remise de plis
        if (consultation.getDateRemisePlis() != null) {
            Date dateRemisePlis = consultation.getDateRemisePlis().toGregorianCalendar().getTime();
            sauvegardeCalendrier(dateRemisePlis, EpmTEtapeCal.RECEPTION_CANDIDATURES, epmTConsultation.getId());
        }

        // Date de mise en ligne
        if (consultation.getDateMiseLigne() != null) {
            Date dateMiseEnLigne = consultation.getDateMiseLigne().toGregorianCalendar().getTime();
            sauvegardeCalendrier(dateMiseEnLigne, EpmTEtapeCal.NOTIFICATION, epmTConsultation.getId());
        }

        epmTConsultation.setSignature(consultation.isSignatureELectronique());
        epmTConsultation.setChiffrement(consultation.isChiffrementPlis());
        epmTConsultation.setEnveloppeUniqueReponse(consultation.isEnveloppeUnique() ? Constantes.OUI : Constantes.NON);
        epmTConsultation.setEpmTUtilisateur(utilisateur);

        if (consultation.getLots() == null || consultation.getLots().getLot() == null || consultation.getLots().getLot().isEmpty()) {
            epmTConsultation.setAllotissement(Constantes.NON);

            remplirPaireTypeComplexe(consultation, epmTConsultation, referentiels);
            //initialiser les valeurs des lots si la consultation est allotissement
        } else {
            epmTConsultation.setAllotissement(Constantes.OUI);
            epmTConsultation.setCritereAppliqueTousLots(false);
            initialiserValeurLots(consultation, epmTConsultation);
        }
        // Sauvegarde de la consultation
        try {
            ValeurConditionnementExterneCritere critereExterne = new ValeurConditionnementExterneCritere();
            critereExterne.setIdConsultation(epmTConsultation.getId());
            List<EpmTValeurConditionnementExterne> listExterne = consultationGIM.chercherParCritere(critereExterne);
            consultationGIM.supprimer(listExterne);
            listExterne = remplirPaireTypeConsultation(consultation,
                    epmTConsultation.getId());
            consultationGIM.modifier(listExterne);

            ValeurConditionnementExterneCritereComplexe critereExterneComplexe = new ValeurConditionnementExterneCritereComplexe();
            critereExterneComplexe.setIdConsultation(epmTConsultation.getId());
            List<EpmTValeurConditionnementExterneComplexe> listeExterneComplexe = consultationGIM.chercherParCritere(critereExterneComplexe);
            consultationGIM.supprimer(listeExterneComplexe);
            listeExterneComplexe = remplirPaireTypeComplexeConsultation(consultation, epmTConsultation.getId());
            consultationGIM.modifier(listeExterneComplexe);

            epmTConsultation = generiqueDAO.merge(epmTConsultation);

        } catch (TechnicalNoyauException e) {
            LOG.error(e.getMessage(), e.fillInStackTrace());
            throw e;
        }

        return epmTConsultation;
    }


    private void initialiserValeurConsultation(EpmTConsultation epmTConsultation, Consultation consultation,
                                               Referentiels referentiels, Selects selects)
            throws ApplicationNoyauException {

        epmTConsultation.setJustificationNonAllotissement(consultation.getJustificationNonAllotissement());
        epmTConsultation.setTransverse((consultation.isTransverse() ? Constantes.OUI : Constantes.NON));
        epmTConsultation.setRefReponseElectronique(getEpmTRefReponseElectronique(referentiels, consultation, true, epmTConsultation.getIdOrganisme()));

        String messageErreur = " n'existe pas.";
        // Intitulé de la consultation
        if (consultation.getIntitule() != null && !"".equals(consultation.getIntitule())) {
            epmTConsultation.setIntituleConsultation(consultation.getIntitule());
        } else {
            ApplicationNoyauException e = new ApplicationNoyauException("L'intitulé de la consultation doit être renseigné");
            LOG.error(e.getMessage());
            throw e;
        }

        // Objet de la consultation
        if (consultation.getObjet() != null && !"".equals(consultation.getObjet())) {
            epmTConsultation.setObjet(consultation.getObjet());
        } else {
            ApplicationNoyauException e = new ApplicationNoyauException("L'objet de la consultation doit être renseigné");
            LOG.error(e.getMessage());
            throw e;
        }

        // Procedure
        epmTConsultation.setEpmTRefProcedure(getEpmTRefProcedure(referentiels, consultation, true, epmTConsultation.getIdOrganisme()));
        if (epmTConsultation.getEpmTRefProcedure() == null) {
            ApplicationNoyauException e = new ApplicationNoyauException("Le type de de procedure " + consultation.getTypeProcedure() + messageErreur);
            LOG.error(e.getMessage());
            throw e;
        }

        // Nature prestation
        epmTConsultation.setEpmTRefNature(getEpmTRefNature(referentiels,
                consultation, true, epmTConsultation.getIdOrganisme()));
        if (epmTConsultation.getEpmTRefNature() == null) {
            ApplicationNoyauException e = new ApplicationNoyauException(
                    "La nature de prestation "
                            + consultation.getNaturePrestation()
                            + messageErreur);
            LOG.error(e.getMessage());
            throw e;
        }

        // Attribution
        epmTConsultation.setEpmTRefAttribution(getAttributionById(selects, 1, epmTConsultation.getIdOrganisme()));

        // Pouvoir adjudicateur
        epmTConsultation.setEpmTRefPouvoirAdjudicateur(getEpmTRefPouvoirAdjudicateur(referentiels, consultation, true, epmTConsultation.getIdOrganisme()));
        if (epmTConsultation.getEpmTRefPouvoirAdjudicateur() == null) {
            ApplicationNoyauException e = new ApplicationNoyauException("Le pouvoir adjudicateur " + consultation.getPouvoirAdjudicateur() + messageErreur);
            LOG.error(e.getMessage());
            throw e;
        }

        // Article
        epmTConsultation.setEpmTRefArticle(getEpmTRefArticle(referentiels, consultation, true, epmTConsultation.getIdOrganisme()));

        // Direction service
        EpmTRefDirectionService epmTRefDirectionService = getEpmTRefDirectionService(referentiels, consultation, true, epmTConsultation.getIdOrganisme());
        if (epmTRefDirectionService != null) {
            epmTConsultation.setEpmTRefDirectionService(epmTRefDirectionService);
            epmTConsultation.setDirServiceVision(epmTRefDirectionService.getId());
        } else {
            ApplicationNoyauException e = new ApplicationNoyauException("La direction service " + consultation.getDirectionService() + messageErreur);
            LOG.error(e.getMessage());
            throw e;
        }

        // Type Contrat <-> EpmTRefAttribution
        EpmTRefAttribution epmTRefAttribution = null;
        if (consultation.getTypeContrat() != null) {
            try {
                List<EpmTRefAttribution> refs = generiqueDAO.findAll(EpmTRefAttribution.class);
                for (EpmTRefAttribution ref : refs) {
                    if (consultation.getTypeContrat().getId() == ref.getIdExterne()) {
                        epmTRefAttribution = ref;
                        break;
                    }
                }
            } catch (TechnicalNoyauException e) {
                LOG.error("Le Type d'attribution avec l'id : " + consultation.getTypeContrat() + " est introuvable dans le noyau");
            }
        }
        if (epmTRefAttribution != null) {
            epmTConsultation.setEpmTRefAttribution(epmTRefAttribution);
        }

        // Lieu d'execution
        if (consultation.getLieuExecutions() != null) {
            Set<EpmTRefLieuExecution> epmTRefLieuExecutions = getListEpmTLieuExecutions(referentiels, consultation.getLieuExecutions().getLieuExecution());
            epmTConsultation.setLieuxExecution(epmTRefLieuExecutions);
        }

        // Statut
        epmTConsultation.setEpmTRefStatut(getEpmTRefStatut(selects, consultation, true, epmTConsultation.getIdOrganisme()));
        if (epmTConsultation.getEpmTRefStatut() == null) {
            ApplicationNoyauException e = new ApplicationNoyauException("Le statut " + consultation.getStatut() + messageErreur);
            LOG.error(e.getMessage());
            throw e;
        }

        //Codes CPV
        Set<EpmTCpv> cpvSet = epmTConsultation.getCpvs();
        if (consultation.getListeCodeCPV() != null && !consultation.getListeCodeCPV().getCpv().isEmpty()) {
            if (cpvSet == null) {
                cpvSet = new HashSet<EpmTCpv>();
                epmTConsultation.setCpvs(cpvSet);
            } else {
                cpvSet.clear();
            }

            for (CPVType cpvType : consultation.getListeCodeCPV().getCpv()) {
                EpmTCpv epmTCpv = new EpmTCpv();

                epmTCpv.setPrincipal(cpvType.isPrincipal());

                epmTCpv.setConsultation(epmTConsultation);
                epmTCpv.setCodeCpv(cpvType.getCodeCPV().trim());
                epmTCpv.setLibelleCpv(cpvType.getLibelleCPV().trim());
                cpvSet.add(epmTCpv);
            }
        }

        // Mharche Public Simplifie
        epmTConsultation.setMarchePublicSimplifie(consultation.isMps());

        // Forme groupement attributaire
        EpmTRefGroupementAttributaire epmTRefGroupementAttributaire = getEpmTRefGroupementAttributaire(selects, consultation.getFormeGroupementAttributaire(), epmTConsultation.getIdOrganisme());
        epmTConsultation.setEpmTRefGroupementAttributaire(epmTRefGroupementAttributaire);

        //Durée du marché
        DureeMarcheType dureeMarcheType = consultation.getDureeMarche();
        EpmTRefChoixMoisJour choixMJ = getEpmTRefChoixMoisJour(selects, dureeMarcheType, false, epmTConsultation.getIdOrganisme());
        epmTConsultation.setEpmTRefChoixMoisJour(choixMJ);

        if (dureeMarcheType != null && choixMJ != null) {
            EpmTRefDureeDelaiDescription epmTRefDureeDelaiDescription = getEmTRefDureeDelaiDescription(selects, dureeMarcheType, epmTConsultation.getIdOrganisme());
            if (epmTRefDureeDelaiDescription != null) {
                epmTConsultation.setEpmTRefDureeDelaiDescription(epmTRefDureeDelaiDescription);
                if (epmTRefDureeDelaiDescription.getId() == EpmTRefDureeDelaiDescription.DUREE_MARCHE_EN_MOIS_EN_JOUR) {
                    if (choixMJ.getId() == EpmTRefChoixMoisJour.EN_JOUR)
                        epmTConsultation.setDureeMarche(Integer.valueOf(dureeMarcheType.getNbJours()));
                    else
                        epmTConsultation.setDureeMarche(Integer.valueOf(dureeMarcheType.getNbMois()));
                    epmTConsultation.setDescriptionDuree(null);
                    epmTConsultation.setDateExecutionPrestationsDebut(null);
                    epmTConsultation.setDateExecutionPrestationsFin(null);
                } else if(epmTRefDureeDelaiDescription.getId() == EpmTRefDureeDelaiDescription.DESCRIPTION_LIBRE) {
                    epmTConsultation.setDescriptionDuree(dureeMarcheType.getDescriptionLibre());
                    epmTConsultation.setDureeMarche(null);
                    epmTConsultation.setDateExecutionPrestationsDebut(null);
                    epmTConsultation.setDateExecutionPrestationsFin(null);
                    epmTConsultation.setEpmTRefChoixMoisJour(getEpmTRefChoixMoisJour(selects, dureeMarcheType, false, epmTConsultation.getIdOrganisme()));
                } else if(epmTRefDureeDelaiDescription.getId() == EpmTRefDureeDelaiDescription.DELAI_EXECUTION_DU_AU) {
                    epmTConsultation.setDureeMarche(null);
                    epmTConsultation.setDescriptionDuree(null);
                    Calendar calendarDateDu = convertGregorianCalendarToCalendar(dureeMarcheType.getDateACompterDu());
                    epmTConsultation.setDateExecutionPrestationsDebut(calendarDateDu);
                    Calendar calendarDateJusquau = convertGregorianCalendarToCalendar(dureeMarcheType.getDateJusquau());
                    epmTConsultation.setDateExecutionPrestationsFin(calendarDateJusquau);
                    epmTConsultation.setEpmTRefChoixMoisJour(getEpmTRefChoixMoisJour(selects, dureeMarcheType, false, epmTConsultation.getIdOrganisme()));
                }
            }
        }

        //Delai de validité des offres
        epmTConsultation.setDelaiValiditeOffres(Integer.valueOf(consultation.getDureeValiditeOffreEnJour()));

        // Criteres d'attribution
        if(consultation.getCriteresAttribution() != null) {
            EpmTRefCritereAttribution epmTRefCritereAttribution = getEpmTRefCritereAttribution(referentiels, consultation.getCriteresAttribution(), epmTConsultation.getIdOrganisme());
            if(epmTRefCritereAttribution != null && epmTConsultation.getEpmTBudLotOuConsultation() != null) {
                epmTConsultation.setCritereAttribution(epmTRefCritereAttribution);
            }

            // Liste des critéres d'attribution liés à la consultation
            Set<EpmTCritereAttributionConsultation> listeCritereAttributionConsultation = getEpmTCritereAttributionConsultation(epmTConsultation, referentiels, consultation.getCriteresAttribution(), epmTConsultation.getIdOrganisme());
            //si non alloti
            if (listeCritereAttributionConsultation != null && epmTConsultation.getEpmTBudLotOuConsultation() != null && epmTConsultation.getListeCritereAttribution() != null) {
                epmTConsultation.getListeCritereAttribution().clear();
                epmTConsultation.getListeCritereAttribution().addAll(listeCritereAttributionConsultation);
            } else if (listeCritereAttributionConsultation != null && epmTConsultation.getEpmTBudLotOuConsultation() != null && epmTConsultation.getListeCritereAttribution() == null) {
                epmTConsultation.setListeCritereAttribution(listeCritereAttributionConsultation);
            }
        }


        //Nombre de candidats admis
        NombreCandidatsType nombreCandidatsType = consultation.getNombreCandidats();
        EpmTRefNbCandidatsAdmis refNombreCandidatAdmis = null;
        Integer idRefNbCandidat = null;
        if(nombreCandidatsType != null) {
            if(nombreCandidatsType.getNombreFixe() != null && nombreCandidatsType.getNombreFixe() != 0) {
                epmTConsultation.setNombreCandidatsFixe(nombreCandidatsType.getNombreFixe().intValue());
                epmTConsultation.setNombreCandidatsMax(null);
                epmTConsultation.setNombreCandidatsMin(null);
                idRefNbCandidat = EpmTRefNbCandidatsAdmis.ID_FIXE;
            } else {
                epmTConsultation.setNombreCandidatsFixe(null);
            }

            if(nombreCandidatsType.getNombreMax() != null && nombreCandidatsType.getNombreMax() != 0) {
                epmTConsultation.setNombreCandidatsMax(nombreCandidatsType.getNombreMax().intValue());
                idRefNbCandidat = EpmTRefNbCandidatsAdmis.ID_FOURCHETTE;
            } else {
                epmTConsultation.setNombreCandidatsMax(null);
            }

            if(nombreCandidatsType.getNombreMin() != null && nombreCandidatsType.getNombreMin() != 0) {
                epmTConsultation.setNombreCandidatsMin(nombreCandidatsType.getNombreMin().intValue());
                idRefNbCandidat = EpmTRefNbCandidatsAdmis.ID_FOURCHETTE;
            } else {
                epmTConsultation.setNombreCandidatsMin(null);
            }

            if(nombreCandidatsType.getReductionProgressive() != null) {
                epmTConsultation.setEnPhasesSuccessives(Constantes.OUI);
            } else {
                epmTConsultation.setEnPhasesSuccessives(Constantes.NON);
            }
        } else {
            epmTConsultation.setNombreCandidatsFixe(null);
            epmTConsultation.setNombreCandidatsMax(null);
            epmTConsultation.setNombreCandidatsMin(null);
            epmTConsultation.setEnPhasesSuccessives(Constantes.NON);
        }

        if (idRefNbCandidat != null) {
            refNombreCandidatAdmis = getEpmTRefNbCandidatsAdmis(selects, idRefNbCandidat, epmTConsultation.getIdOrganisme());
        }

        epmTConsultation.setEpmTRefNbCandidatsAdmis(refNombreCandidatAdmis);

        initialiserValeurConsultationInformationsComplementaires(epmTConsultation.getEpmTBudLotOuConsultation(), consultation.getInformationsComplementaires(),
                referentiels, selects, epmTConsultation.getIdOrganisme());

    }

    /**
     * Rempli les paireTypeComplexe dans l'objet
     * epmTBudLot depuis le flux dans le cas d'une consultation allotie. 
     * @param lot
     * @param epmTBudLot
     * @param epmTConsultation
     */
    private void remplirPaireTypeComplexePourLot(LotType lot, EpmTBudLot epmTBudLot, EpmTConsultation epmTConsultation) {

        EpmTBudLotOuConsultation epmTBudLotOuConsultation = null;
        if(epmTBudLot.getEpmTBudLotOuConsultation()!=null){
            epmTBudLotOuConsultation = epmTBudLot.getEpmTBudLotOuConsultation();
        }

        if(epmTBudLotOuConsultation != null){
            Set<EpmTValeurConditionnementExterneComplexe> conditionnementExterneComplexe = epmTBudLotOuConsultation
                    .getEpmTValeurConditionnementExternesComplexe();

            if (conditionnementExterneComplexe == null ) {
                conditionnementExterneComplexe = new HashSet<EpmTValeurConditionnementExterneComplexe>();
                epmTBudLotOuConsultation.setEpmTValeurConditionnementExternesComplexe(conditionnementExterneComplexe);
            }

            Set<EpmTValeurConditionnementExterne> conditionnementExternes = epmTBudLotOuConsultation
                    .getEpmTValeurConditionnementExternes();

            if (conditionnementExternes == null) {
                conditionnementExternes = new HashSet<EpmTValeurConditionnementExterne>();
                epmTBudLotOuConsultation.setEpmTValeurConditionnementExternes(conditionnementExternes);
            }

            conditionnementExternes = epmTBudLotOuConsultation
                    .getEpmTValeurConditionnementExternes();
            conditionnementExternes.clear();

            ListPaireTypeComplexe pairesTypeComplexe = lot
                    .getPairesTypeComplexe();
            if (pairesTypeComplexe != null) {
                if (epmTBudLotOuConsultation
                        .getEpmTValeurConditionnementExternesComplexe() == null) {
                    epmTConsultation
                            .setEpmTBudLotOuConsultation(epmTBudLotOuConsultation);
                }

                conditionnementExterneComplexe = epmTBudLotOuConsultation
                        .getEpmTValeurConditionnementExternesComplexe();
                conditionnementExterneComplexe.clear();

                List<ListPaireType> listPaireTypeComplexe = pairesTypeComplexe
                        .getPaireTypeComplexe();
                for (ListPaireType paireTypeComplexe : listPaireTypeComplexe) {
                    List<PaireType> listPaireType = paireTypeComplexe
                            .getPaireType();
                    if (listPaireType != null) {

                        Set<EpmTValeurConditionnementExterne> setValeurConditionnementExterne = new HashSet<EpmTValeurConditionnementExterne>();
                        for (PaireType paireType : listPaireType) {
                            EpmTValeurConditionnementExterne valeurConditionnementExterne = new EpmTValeurConditionnementExterne();
                            valeurConditionnementExterne
                                    .setIdConsultation(epmTConsultation.getId());
                            valeurConditionnementExterne.setClef(paireType
                                    .getCle());
                            valeurConditionnementExterne.setValeur(paireType
                                    .getValeur());
                            setValeurConditionnementExterne
                                    .add(valeurConditionnementExterne);
                        }
                        EpmTValeurConditionnementExterneComplexe valeurConditionnementExterneComplexe = new EpmTValeurConditionnementExterneComplexe();
                        valeurConditionnementExterneComplexe
                                .setEpmTValeurConditionnementExternes(setValeurConditionnementExterne);
                        valeurConditionnementExterneComplexe
                                .setIdLotConsultation(epmTBudLotOuConsultation
                                        .getId());
                        valeurConditionnementExterneComplexe
                                .setIdObjetComplexe(paireTypeComplexe
                                        .getIdObjetComplexe());
                        conditionnementExterneComplexe
                                .add(valeurConditionnementExterneComplexe);

                    }
                }
            }

            ListPaireType listPairesType = lot.getPairesType();
            if (listPairesType != null) {
                for (PaireType paireType : listPairesType.getPaireType()) {
                    EpmTValeurConditionnementExterne valeurConditionnementExterne = new EpmTValeurConditionnementExterne();
                    valeurConditionnementExterne
                            .setIdConsultation(epmTConsultation.getId());
                    valeurConditionnementExterne.setClef(paireType.getCle());
                    valeurConditionnementExterne.setValeur(paireType
                            .getValeur());
                    conditionnementExternes.add(valeurConditionnementExterne);
                }
            }
        }

    }

    /**
     * Rempli les paireType dans le cas d'une consultation non-allotie Crée un
     * objet EpmTBudLotOuConsultation et lui associe un ensemble
     * EpmTValeurConditionnementExterneComplexe
     *
     * @param consultation
     * @param idConsultation
     */
    private List<EpmTValeurConditionnementExterneComplexe> remplirPaireTypeComplexeConsultation(Consultation consultation, Integer idConsultation) {

        List<EpmTValeurConditionnementExterneComplexe> conditionnementExterneComplexe = new ArrayList<EpmTValeurConditionnementExterneComplexe>();

        conditionnementExterneComplexe.clear();

        ListPaireTypeComplexe pairesTypeComplexe = consultation
                .getPairesTypeComplexe();
        if (pairesTypeComplexe != null) {

            List<ListPaireType> listPaireTypeComplexe = pairesTypeComplexe
                    .getPaireTypeComplexe();
            for (ListPaireType paireTypeComplexe : listPaireTypeComplexe) {
                List<PaireType> listPaireType = paireTypeComplexe
                        .getPaireType();
                if (listPaireType != null) {

                    Set<EpmTValeurConditionnementExterne> setValeurConditionnementExterne = new HashSet<EpmTValeurConditionnementExterne>();
                    for (PaireType paireType : listPaireType) {
                        EpmTValeurConditionnementExterne valeurConditionnementExterne = new EpmTValeurConditionnementExterne();
                        valeurConditionnementExterne
                                .setIdConsultation(idConsultation);
                        valeurConditionnementExterne
                                .setClef(paireType.getCle());
                        valeurConditionnementExterne.setValeur(paireType
                                .getValeur());
                        setValeurConditionnementExterne
                                .add(valeurConditionnementExterne);
                    }
                    EpmTValeurConditionnementExterneComplexe valeurConditionnementExterneComplexe = new EpmTValeurConditionnementExterneComplexe();
                    valeurConditionnementExterneComplexe
                            .setEpmTValeurConditionnementExternes(setValeurConditionnementExterne);
                    valeurConditionnementExterneComplexe
                            .setIdConsultation(idConsultation);
                    valeurConditionnementExterneComplexe
                            .setIdObjetComplexe(paireTypeComplexe
                                    .getIdObjetComplexe());
                    conditionnementExterneComplexe
                            .add(valeurConditionnementExterneComplexe);
                }
            }
        }
        return conditionnementExterneComplexe;
    }


    /**
     * Rempli les paireTypeComplexe depuis le flux dans le cas d'une
     * consultation non-allotie Crée un objet EpmTBudLotOuConsultation et lui
     * associe un ensemble EpmTValeurConditionnementExterneComplexe
     *
     * @param consultation
     * @param epmTConsultation
     */
    private void remplirPaireTypeComplexe(Consultation consultation, EpmTConsultation epmTConsultation, Referentiels referentiels) {

        EpmTBudLotOuConsultation epmTBudLotOuConsultation = null;
        if (epmTConsultation.getEpmTBudLotOuConsultation() == null) {
            epmTBudLotOuConsultation = new EpmTBudLotOuConsultation();
            epmTConsultation.setEpmTBudLotOuConsultation(epmTBudLotOuConsultation);
        }
        epmTBudLotOuConsultation = epmTConsultation.getEpmTBudLotOuConsultation();

        Set<EpmTValeurConditionnementExterneComplexe> conditionnementExterneComplexe = epmTBudLotOuConsultation.getEpmTValeurConditionnementExternesComplexe();
        if (conditionnementExterneComplexe == null ) {
            conditionnementExterneComplexe = new HashSet<EpmTValeurConditionnementExterneComplexe>();
            epmTBudLotOuConsultation.setEpmTValeurConditionnementExternesComplexe(conditionnementExterneComplexe);
        }

        // Clauses Sociales
        ClausesSocialesType clausesSocialesType = consultation.getClausesSociales();
        if (clausesSocialesType != null) {
            epmTConsultation.setClausesSociales(Constantes.OUI);
            epmTConsultation.getEpmTBudLotOuConsultation().setClausesSociales(true);

            Set<EpmTRefClausesSociales> refClausesSociales = new HashSet<>();
            if (clausesSocialesType.isMarcheReserve()) {
                epmTConsultation.setNombreHeureClauseSociale(clausesSocialesType.getNombreHeure().doubleValue());
                epmTConsultation.setPourcentageClauseSociale(Double.valueOf(clausesSocialesType.getPourcentage()));
                refClausesSociales.add(getEpmTRefClausesSociales(referentiels, EpmTRefClausesSociales.CODE_CLAUSE_ATELIERS));
            }
            if (clausesSocialesType.isConditionExecution()) {
                refClausesSociales.add(getEpmTRefClausesSociales(referentiels, EpmTRefClausesSociales.CODE_CLAUSE_INSERTION));
            }
            if (clausesSocialesType.isCritereAttribution()) {
                if (clausesSocialesType.isCritereAttribution()) {
                    epmTConsultation.getEpmTBudLotOuConsultation().setClausesSocialesPresentCriteresAttribution(true);
                }
            }
            epmTConsultation.getEpmTBudLotOuConsultation().setClausesSocialesChoixUtilisateur(refClausesSociales);

        } else {
            epmTConsultation.setClausesSociales(Constantes.NON);
            epmTConsultation.getEpmTBudLotOuConsultation().setClausesSociales(false);
            epmTConsultation.setNombreHeureClauseSociale(null);
            epmTConsultation.setPourcentageClauseSociale(null);
        }

        // Clauses Environnamentales
        ClausesEnvironnementalesType clausesEnvironnementales = consultation.getClausesEnvironnementales();
        if (clausesEnvironnementales != null) {
            epmTConsultation.getEpmTBudLotOuConsultation().setClausesEnvironnementales(true);
            epmTConsultation.setClausesEnvironnementales(Constantes.OUI);

            Set<EpmTRefClausesEnvironnementales> refClausesEnvironnementales = new HashSet<>();
            EpmTRefClausesEnvironnementales valeur = new EpmTRefClausesEnvironnementales();
            if (clausesEnvironnementales.isSpecificationTechnique()){
                refClausesEnvironnementales.add(getEpmTRefClausesEnvironnementales(referentiels, EpmTRefClausesEnvironnementales.CODE_CLAUSE_SPECIFICATION));
            }
            if (clausesEnvironnementales.isConditionExecution()){
                refClausesEnvironnementales.add(getEpmTRefClausesEnvironnementales(referentiels, EpmTRefClausesEnvironnementales.CODE_CLAUSE_CONDITIONS));
            }
            if (clausesEnvironnementales.isCritereAttribution()){
                refClausesEnvironnementales.add(getEpmTRefClausesEnvironnementales(referentiels, EpmTRefClausesEnvironnementales.CODE_CLAUSE_SELECTION));
            }
            epmTConsultation.getEpmTBudLotOuConsultation().setClausesEnvironnementalesChoixUtilisateur(refClausesEnvironnementales);
        } else {
            epmTConsultation.setClausesEnvironnementales(Constantes.NON);
            epmTConsultation.getEpmTBudLotOuConsultation().setClausesEnvironnementales(false);
        }

        conditionnementExterneComplexe.clear();

        ListPaireTypeComplexe pairesTypeComplexe = consultation.getPairesTypeComplexe();
        if (pairesTypeComplexe != null) {

            List<ListPaireType> listPaireTypeComplexe = pairesTypeComplexe.getPaireTypeComplexe();
            for (ListPaireType paireTypeComplexe : listPaireTypeComplexe) {
                List<PaireType> listPaireType = paireTypeComplexe.getPaireType();
                if (listPaireType != null) {

                    Set<EpmTValeurConditionnementExterne> setValeurConditionnementExterne = new HashSet<EpmTValeurConditionnementExterne>();
                    for (PaireType paireType : listPaireType) {
                        EpmTValeurConditionnementExterne valeurConditionnementExterne = new EpmTValeurConditionnementExterne();
                        valeurConditionnementExterne.setIdConsultation(epmTConsultation.getId());
                        valeurConditionnementExterne.setClef(paireType.getCle());
                        valeurConditionnementExterne.setValeur(paireType.getValeur());
                        setValeurConditionnementExterne.add(valeurConditionnementExterne);
                    }
                    EpmTValeurConditionnementExterneComplexe valeurConditionnementExterneComplexe = new EpmTValeurConditionnementExterneComplexe();
                    valeurConditionnementExterneComplexe
                            .setEpmTValeurConditionnementExternes(setValeurConditionnementExterne);
                    valeurConditionnementExterneComplexe
                            .setIdLotConsultation(epmTBudLotOuConsultation.getId());
                    valeurConditionnementExterneComplexe.setIdObjetComplexe(paireTypeComplexe
                            .getIdObjetComplexe());
                    conditionnementExterneComplexe.add(valeurConditionnementExterneComplexe);
                }
            }
        }
    }

    /**
     * Charge les valeurss de chaque lot depuis le flux pour les
     * ajouter dans les lots de l'EpmTConsultation
     *
     * @param consultation
     * @param epmTConsultation
     * @throws NonTrouveNoyauException
     * @throws TechnicalNoyauException
     */
    private void initialiserValeurLots(Consultation consultation, EpmTConsultation epmTConsultation) throws NonTrouveNoyauException,
            TechnicalNoyauException {

        int compte = 1;
        for (LotType lotNouveau : consultation.getLots().getLot()) {
            // Si le numero de lot dans consultation est null, affecter un numero à partir de 1.
            if (lotNouveau.getNumeroLot() == null || lotNouveau.getNumeroLot().isEmpty()) {
                lotNouveau.setNumeroLot(String.valueOf(compte++));
            }
        }

        if (epmTConsultation.getEpmTBudLots() == null) {
            epmTConsultation.setEpmTBudLots(new HashSet<EpmTBudLot>());
        }

        Set<EpmTBudLot> listLotAncienASupprime = new HashSet<EpmTBudLot>();
        List<LotType> listLotNouveauPourMiseAJour = new ArrayList<LotType>();


        for (Iterator<EpmTBudLot> iter = epmTConsultation.getEpmTBudLots().iterator(); iter.hasNext();) {
            EpmTBudLot lotAncien = iter.next();
            int nombrePresentDanslistLotNouveau = 0;
            for (LotType lotNouveau : consultation.getLots().getLot()) {

                // mise à jour le lot s'il est dans epmTConsultation et consultation (1)
                if ((lotAncien.getNumeroLot()).equals(lotNouveau.getNumeroLot())) {

                    miseAJourEpmTBudLot(lotNouveau, lotAncien, consultation,
                            epmTConsultation);
                    listLotNouveauPourMiseAJour.add(lotNouveau);
                    continue;
                }else {
                    nombrePresentDanslistLotNouveau++;
                }
                // si le lot n'est pas dans epmTConsultation, on va le supprimer 
                if (nombrePresentDanslistLotNouveau == consultation.getLots().getLot().size()) {
                    listLotAncienASupprime.add(lotAncien);
                }
            }
        }

        // supprimer les lots dans epmTConsultation, ces lots ne sont pas
        // présents dans consultation (2)
        epmTConsultation.getEpmTBudLots().removeAll(listLotAncienASupprime);

        // ajouter les lots dans epmTConsultation qui sont présents dans
        // consultation mais pas dans epmTConsultation (3)
        List<LotType> listlotNouveauAAjouter = new ArrayList<LotType>();
        listlotNouveauAAjouter.addAll(consultation.getLots().getLot());
        listlotNouveauAAjouter.removeAll(listLotNouveauPourMiseAJour);
        for (LotType lotNouveauAAjouter : listlotNouveauAAjouter) {
            epmTConsultation.getEpmTBudLots().add(
                    miseAJourEpmTBudLot(lotNouveauAAjouter, null, consultation, epmTConsultation));
        }
    }



    /**
     * Rempli les paireType dans le cas d'une consultation non-allotie Crée un
     * objet EpmTBudLotOuConsultation et lui associe un ensemble
     * EpmTValeurConditionnementExterne
     *
     * @param consultation
     * @param idConsultation
     */
    private List<EpmTValeurConditionnementExterne> remplirPaireTypeConsultation(Consultation consultation, Integer idConsultation) {
        List<EpmTValeurConditionnementExterne> conditionnementExternes = new ArrayList<EpmTValeurConditionnementExterne>();

        ListPaireType pairesType = consultation.getPairesType();
        if (pairesType != null) {
            List<PaireType> listPaireType = pairesType.getPaireType();
            if (listPaireType != null) {
                for (PaireType paireType : listPaireType) {

                    EpmTValeurConditionnementExterne valeurConditionnementExterne = new EpmTValeurConditionnementExterne();
                    valeurConditionnementExterne.setIdConsultation(idConsultation);
                    valeurConditionnementExterne.setClef(paireType.getCle());
                    valeurConditionnementExterne.setValeur(paireType.getValeur());
                    conditionnementExternes.add(valeurConditionnementExterne);
                }
            }
        }
        return conditionnementExternes;
    }

    /**
     * la méthode peut mettre à jour l'objet 'epmTBudLot' en reprenant les
     * valeurs de l'objet 'lot', si 'epmTBudLot' est null, cette méthode va
     * créer un nouveau objet de classe 'EpmTBudLot' en reprenant les
     * valeurs de l'objet 'lot'.  
     *
     * @param lotNouveau objet qui apporte les valeurs pour la mise à jour 
     * @param lotAMettreAJour objet à mettre à jour. S'il est null, un nouveau objet de classe 'EpmTBudLot' va être créé
     * @param consultation la cosultation associé avec 'lot'
     * @param epmTConsultation la cosultation associé avec 'epmTBudLot'
     * @return objet déjà mis à jour ou objet créé
     * @throws TechnicalNoyauException
     * @throws NonTrouveNoyauException
     */
    private EpmTBudLot miseAJourEpmTBudLot(LotType lotNouveau, EpmTBudLot lotAMettreAJour, Consultation consultation, EpmTConsultation epmTConsultation) throws NonTrouveNoyauException,
            TechnicalNoyauException {

        Referentiels referentiels = referentielsServiceLocal.getAllReferentiels();
        Selects selects = selectsService.getAllSelects();

        EpmTBudLot epmTBudLot;

        // on met à jour le lot si le lotAMettreAJour est pas null, sinon on crée un nouveau objet du lot 
        if(lotAMettreAJour == null){
            epmTBudLot = new EpmTBudLot();
        }else{
            epmTBudLot = lotAMettreAJour;
        }

        epmTBudLot.setDescriptionSuccinte(lotNouveau.getDescription());
        epmTBudLot.setIntituleLot(lotNouveau.getIntitule());

        if(lotNouveau.getNumeroLot() != null && !lotNouveau.getNumeroLot().isEmpty()){
            epmTBudLot.setNumeroLot(lotNouveau.getNumeroLot());
        }

        // Nature de la prestation
        epmTBudLot.setEpmTRefNature(getEpmTRefNature(referentiels, consultation, true, epmTConsultation.getIdOrganisme()));


        // Durée du marché
        DureeMarcheType dureeMarcheType = lotNouveau.getDureeMarche();
        EpmTRefChoixMoisJour choixMJ = getEpmTRefChoixMoisJour(selects, dureeMarcheType, false, epmTConsultation.getIdOrganisme());
        epmTBudLot.setEpmTRefChoixMoisJour(choixMJ);

        if (dureeMarcheType != null && choixMJ != null) {
            EpmTRefDureeDelaiDescription epmTRefDureeDelaiDescription = getEmTRefDureeDelaiDescription(
                    selects, dureeMarcheType, epmTConsultation.getIdOrganisme());
            if (epmTRefDureeDelaiDescription != null) {
                epmTBudLot.setEpmTRefDureeDelaiDescription(epmTRefDureeDelaiDescription);
                if (epmTRefDureeDelaiDescription.getId() == EpmTRefDureeDelaiDescription.DUREE_MARCHE_EN_MOIS_EN_JOUR) {
                    if (choixMJ.getId() == EpmTRefChoixMoisJour.EN_JOUR) {
                        epmTBudLot
                                .setDureeMarche(Integer.valueOf(dureeMarcheType.getNbJours()));
                    } else {
                        epmTBudLot.setDureeMarche(Integer.valueOf(dureeMarcheType.getNbMois()));
                    }
                    epmTBudLot.setDescriptionDuree(null);
                    epmTBudLot.setDateDebut(null);
                    epmTBudLot.setDateFin(null);
                } else if (epmTRefDureeDelaiDescription.getId() == EpmTRefDureeDelaiDescription.DESCRIPTION_LIBRE) {
                    epmTBudLot.setDescriptionDuree(dureeMarcheType.getDescriptionLibre());
                    epmTBudLot.setDureeMarche(null);
                    epmTBudLot.setDateDebut(null);
                    epmTBudLot.setDateFin(null);
                    epmTBudLot.setEpmTRefChoixMoisJour(getEpmTRefChoixMoisJour(selects,
                            dureeMarcheType, false, epmTConsultation.getIdOrganisme()));
                } else if (epmTRefDureeDelaiDescription.getId() == EpmTRefDureeDelaiDescription.DELAI_EXECUTION_DU_AU) {
                    epmTBudLot.setDureeMarche(null);
                    epmTBudLot.setDescriptionDuree(null);
                    Calendar calendarDateDu = convertGregorianCalendarToCalendar(dureeMarcheType
                            .getDateACompterDu());
                    epmTBudLot.setDateDebut(calendarDateDu);
                    Calendar calendarDateJusquau = convertGregorianCalendarToCalendar(dureeMarcheType
                            .getDateJusquau());
                    epmTBudLot.setDateFin(calendarDateJusquau);
                    epmTBudLot.setEpmTRefChoixMoisJour(getEpmTRefChoixMoisJour(selects,
                            dureeMarcheType, false, epmTConsultation.getIdOrganisme()));
                }
            }
        }

        //Codes CPV
        Set<EpmTCpv> cpvSet = epmTBudLot.getCpvs();
        if (lotNouveau.getListeCodeCPV() != null
                && !lotNouveau.getListeCodeCPV().getCpv().isEmpty()) {
            if (cpvSet == null) {
                cpvSet = new HashSet<EpmTCpv>();
                epmTBudLot.setCpvs(cpvSet);
            } else {
                cpvSet.clear();
            }

            for (CPVType cpvType : lotNouveau.getListeCodeCPV().getCpv()) {
                EpmTCpv epmTCpv = new EpmTCpv();

                epmTCpv.setPrincipal(false);
                if(cpvType.isPrincipal()){
                    epmTCpv.setPrincipal(true);
                }

                epmTCpv.setLot(epmTBudLot);
                epmTCpv.setCodeCpv(cpvType.getCodeCPV().trim());
                epmTCpv.setLibelleCpv(cpvType.getLibelleCPV().trim());
                cpvSet.add(epmTCpv);
            }
        }

        EpmTBudLotOuConsultation epmTBudLotOuConsultation = new EpmTBudLotOuConsultation();
        epmTBudLotOuConsultation = initialiserValeurConsultationInformationsComplementaires(epmTBudLotOuConsultation, lotNouveau.getInformationsComplementaires(), referentiels, selects, epmTConsultation.getIdOrganisme());


        // Clauses Sociales
        ClausesSocialesType clausesSocialesType = lotNouveau.getClausesSociales();
        if (clausesSocialesType != null) {
            epmTBudLotOuConsultation.setClausesSociales(true);
            Set<EpmTRefClausesSociales> refClausesSociales = new HashSet<>();
            EpmTRefClausesSociales valeur = new EpmTRefClausesSociales();
            if (clausesSocialesType.isMarcheReserve()){
                epmTBudLotOuConsultation.setNombreHeureClauseSociale(clausesSocialesType.getNombreHeure().doubleValue());
                epmTBudLotOuConsultation.setPourcentageClauseSociale(Double.valueOf(clausesSocialesType.getPourcentage()));
                refClausesSociales.add(getEpmTRefClausesSociales(referentiels, EpmTRefClausesSociales.CODE_CLAUSE_ATELIERS));
            }
            if (clausesSocialesType.isConditionExecution())
                refClausesSociales.add(getEpmTRefClausesSociales(referentiels, EpmTRefClausesSociales.CODE_CLAUSE_INSERTION));
            if (clausesSocialesType.isCritereAttribution())
                epmTBudLotOuConsultation.setClausesSocialesPresentCriteresAttribution(true);
            epmTBudLotOuConsultation.setClausesSocialesChoixUtilisateur(refClausesSociales);
        } else {
            epmTBudLotOuConsultation.setClausesSociales(false);
            epmTBudLotOuConsultation.setNombreHeureClauseSociale(null);
            epmTBudLotOuConsultation.setPourcentageClauseSociale(null);
        }

        // Clauses Environnamentales
        epmTBudLotOuConsultation.setClausesEnvironnementales(false);
        ClausesEnvironnementalesType clausesEnvironnementales = lotNouveau.getClausesEnvironnementales();
        if (clausesEnvironnementales != null) {
            Set<EpmTRefClausesEnvironnementales> refClausesEnvironnementales = new HashSet<>();
            EpmTRefClausesEnvironnementales valeur = new EpmTRefClausesEnvironnementales();
            if (clausesEnvironnementales.isSpecificationTechnique())
                refClausesEnvironnementales.add(getEpmTRefClausesEnvironnementales(referentiels, EpmTRefClausesEnvironnementales.CODE_CLAUSE_SPECIFICATION));
            if (clausesEnvironnementales.isConditionExecution())
                refClausesEnvironnementales.add(getEpmTRefClausesEnvironnementales(referentiels, EpmTRefClausesEnvironnementales.CODE_CLAUSE_CONDITIONS));
            if (clausesEnvironnementales.isCritereAttribution())
                refClausesEnvironnementales.add(getEpmTRefClausesEnvironnementales(referentiels, EpmTRefClausesEnvironnementales.CODE_CLAUSE_SELECTION));
            epmTBudLotOuConsultation.setClausesEnvironnementalesChoixUtilisateur(refClausesEnvironnementales);
            epmTBudLotOuConsultation.setClausesEnvironnementales(true);
        }

        //Criteres d'attribution
        if(lotNouveau.getCriteresAttribution() != null) {
            CriteresAttributionType criteresAttribution = lotNouveau.getCriteresAttribution();

            EpmTRefCritereAttribution refCritereOrganisme = getEpmTRefCritereAttribution(referentiels, criteresAttribution, epmTConsultation.getIdOrganisme());
            epmTBudLot.setCritereAttribution(refCritereOrganisme);

            Set<EpmTCritereAttributionConsultation> criteresAttributionConsultation = getEpmTCritereAttributionConsultation(epmTConsultation, referentiels, criteresAttribution, epmTConsultation.getIdOrganisme());
            epmTBudLot.setListeCritereAttribution(criteresAttributionConsultation);
        }

        epmTBudLot.setEpmTBudLotOuConsultation(epmTBudLotOuConsultation);

        remplirPaireTypeComplexePourLot(lotNouveau, epmTBudLot, epmTConsultation);

        return epmTBudLot;

    }

    private EpmTBudLotOuConsultation initialiserValeurConsultationInformationsComplementaires(
            EpmTBudLotOuConsultation epmTBudLotOuConsultation, InformationsCommunesLotEtConsultationType informationsCommunesLotEtConsultation,
            Referentiels referentiels, Selects selects, Integer idOrganisme) {

        if(informationsCommunesLotEtConsultation != null) {
            //Variantes autorisees
            boolean isVarianteAutorisee = informationsCommunesLotEtConsultation.isVarianteAutorisee();
            epmTBudLotOuConsultation.setVariantesAutorisees(isVarianteAutorisee ? Constantes.OUI : Constantes.NON);

            //Variantes techniques
            String valeurVarianteTechnique = informationsCommunesLotEtConsultation.getVariantesTechniquesObligatoires();
            epmTBudLotOuConsultation.setOptionsTechniquesImposees(Constantes.NON);
            if (valeurVarianteTechnique != null && !valeurVarianteTechnique.isEmpty()) {
                epmTBudLotOuConsultation.setOptionsTechniquesImposees(Constantes.OUI);
                epmTBudLotOuConsultation.setDescriptionOptionsImposees(valeurVarianteTechnique);
            }

            // Variantes obligatoires
            boolean isVariantesExigees = informationsCommunesLotEtConsultation.getVariantesExigees();
            epmTBudLotOuConsultation.setVariantesExigees(isVariantesExigees ? Constantes.OUI : Constantes.NON);

            //CCAG
            EpmTRefCcag epmTRefCcag = getEpmTRefCcag(referentiels, informationsCommunesLotEtConsultation.getCcag(), idOrganisme);
            epmTBudLotOuConsultation.setEpmTRefCcag(epmTRefCcag);

            // Droits de propriété intellectuelle
            EpmTRefDroitProprieteIntellectuelle epmTRefDroitProprieteIntellectuelle =
                    getEpmTRefDroitProprieteIntellectuelle(referentiels, informationsCommunesLotEtConsultation.getDroitProprieteIntellectuelle(), idOrganisme);
            epmTBudLotOuConsultation.setDroitProprieteIntellectuelle(epmTRefDroitProprieteIntellectuelle);

            //Marche reconductible
            if (informationsCommunesLotEtConsultation.getMarcheReconductible() != null) {
                epmTBudLotOuConsultation.setReconductible(Constantes.OUI);
                if (informationsCommunesLotEtConsultation.getMarcheReconductible() != null) {
                    epmTBudLotOuConsultation.setNbReconductions(Integer.valueOf(informationsCommunesLotEtConsultation.getMarcheReconductible().getNombreDeReconduction()));
                }
                epmTBudLotOuConsultation.setModalitesReconduction(informationsCommunesLotEtConsultation.getMarcheReconductible().getModalitesDeReconduction());
            } else {
                epmTBudLotOuConsultation.setReconductible(Constantes.NON);
            }

            //Tranches
            if (epmTBudLotOuConsultation.getEpmTBudTranches() != null && !epmTBudLotOuConsultation.getEpmTBudTranches().isEmpty())
                epmTBudLotOuConsultation.getEpmTBudTranches().clear();

            Set<EpmTBudTranche> epmTBudTranches = getListeEpmTBudTranche(selects, informationsCommunesLotEtConsultation.getTranches(), idOrganisme);

            if (epmTBudLotOuConsultation.getEpmTBudTranches() != null && epmTBudTranches != null)
                epmTBudLotOuConsultation.getEpmTBudTranches().addAll(epmTBudTranches);
            else if (epmTBudTranches != null)
                epmTBudLotOuConsultation.setEpmTBudTranches(epmTBudTranches);

            Set<EpmTRefTypeStructureSociale> structureSocialeReserves = getListeStructuresSocialeReserves(referentiels, informationsCommunesLotEtConsultation.getStructuresSocialeReserves(), idOrganisme);
            epmTBudLotOuConsultation.setListeStructureSocialeReserves(structureSocialeReserves);

            //Lots techniques
            if (informationsCommunesLotEtConsultation.getLotsTechniques() != null) {
                List<LotTechniqueType> lotsTechniques = informationsCommunesLotEtConsultation.getLotsTechniques().getLotTechnique();
                Set<EpmTLotTechnique> epmTLotsTechniques = new HashSet<EpmTLotTechnique>();
                for (LotTechniqueType lotTechnique : lotsTechniques) {
                    EpmTLotTechnique epmTLotTechnique = conversionService.map(lotTechnique, EpmTLotTechnique.class);
                    epmTLotTechnique.setPrincipal(lotTechnique.isLotPrincipal() ? Constantes.OUI : Constantes.NON);

                    if (epmTBudLotOuConsultation.getEpmTBudTranches() != null && !epmTBudLotOuConsultation.getEpmTBudTranches().isEmpty()) {
                        Set<EpmTBudTranche> tranchesAssocies = getEpmTBudTranchesAssocies(lotTechnique.getTranches(), epmTBudLotOuConsultation.getEpmTBudTranches());
                        if (epmTLotTechnique.getEpmTBudTranches() != null) {
                            epmTLotTechnique.getEpmTBudTranches().clear();
                            epmTLotTechnique.getEpmTBudTranches().addAll(tranchesAssocies);
                        } else {
                            epmTLotTechnique.setEpmTBudTranches(tranchesAssocies);
                        }
                    }
                    epmTLotsTechniques.add(epmTLotTechnique);
                }
                if (epmTBudLotOuConsultation.getEpmTLotTechniques() != null) {
                    epmTBudLotOuConsultation.getEpmTLotTechniques().clear();
                    epmTBudLotOuConsultation.getEpmTLotTechniques().addAll(epmTLotsTechniques);
                } else {
                    epmTBudLotOuConsultation.setEpmTLotTechniques(epmTLotsTechniques);
                }

                epmTBudLotOuConsultation.setDecompositionLotsTechniques(Constantes.OUI);
            } else {
                epmTBudLotOuConsultation.setDecompositionLotsTechniques(Constantes.NON);
                if ( epmTBudLotOuConsultation.getEpmTLotTechniques() != null) {
                    epmTBudLotOuConsultation.getEpmTLotTechniques().clear();
                }
            }

            epmTBudLotOuConsultation.setEpmTBudFormePrix(getEpmTBudFormePrix(selects, informationsCommunesLotEtConsultation.getFormeDePrix(), idOrganisme));
        }
        return epmTBudLotOuConsultation;
    }

    //TODO
    private EpmTBudFormePrix getEpmTBudFormePrix(Selects selects, FormeDePrixType formePrixType, Integer idOrganisme) {
        EpmTBudFormePrix epmTBudFormePrix = null;

        if(formePrixType != null) {
            FDPPartieForfaitaireType fdpPartieForfaitaireType = formePrixType.getFormeDePrixForfaitaire();
            FDPPartieUnitaireType fdpPartieUnitaireType = formePrixType.getFormeDePrixUnitaire();
            FDPMixteType fdpPartieMixteType = formePrixType.getFormeDePrixMixte();

            if(fdpPartieMixteType != null) {
                EpmTBudFormePrixPm pm = new EpmTBudFormePrixPm();
                //TODO dozer ?
                EpmTBudFormePrixPf pf = getEpmTBudFormePrixPf(selects, fdpPartieMixteType.getPartieForfaitaire(), idOrganisme);
                pm.setPfDateValeur(pf.getPfDateValeur());
                pm.setPfEpmTRefVariations(pf.getPfEpmTRefVariations());
                pm.setPfEstimationHt(pf.getPfEstimationHt());
                pm.setPfEstimationTtc(pf.getPfEstimationTtc());

                EpmTBudFormePrixPu pu = getEpmTBudFormePrixPu(selects, fdpPartieMixteType.getPartieUnitaire(), idOrganisme);
                pm.setPuDateValeur(pu.getPuDateValeur());
                pm.setPuEpmTRefVariations(pu.getPuEpmTRefVariations());
                pm.setPuEstimationHt(pu.getPuEstimationHt());
                pm.setPuEstimationTtc(pu.getPuEstimationTtc());
                pm.setPuEpmTRefBonQuantite(pu.getEpmTRefBonQuantite());
                pm.setPuEpmTRefMinMax(pu.getEpmTRefMinMax());
                pm.setPuEpmTRefTypePrix(pu.getEpmTRefTypePrix());

                pm.setPuMaxHt(pu.getPuMaxHt());
                pm.setPuMinHt(pu.getPuMinHt());

                epmTBudFormePrix = pm;
            }else if(fdpPartieForfaitaireType != null) {
                epmTBudFormePrix = getEpmTBudFormePrixPf(selects, fdpPartieForfaitaireType, idOrganisme);

            }else if(fdpPartieUnitaireType != null) {
                epmTBudFormePrix = getEpmTBudFormePrixPu(selects, fdpPartieUnitaireType, idOrganisme);
            }
        }
        return epmTBudFormePrix;
    }


    /**
     * Dans le cas ou obligatoire == false, on renvoi le premier objet qu'on
     * récupère juste pour faire passer la sauvegarde en base de données
     *
     * @return EpmTRefNature
     */
    private EpmTRefNature getEpmTRefNature(final Referentiels referentiels, final Consultation consultation, final boolean obligatoire, Integer idOrganisme) {

        List<Referentiel> refs = filterReferentielByIdOrganisme(referentiels.getRefNature(), idOrganisme);
        for (Referentiel ref : refs) {
            EpmTRefNature nature = (EpmTRefNature) ref;
            if (obligatoire) {
                if (nature.getCodeGo() != null
                        && consultation.getNaturePrestation() != null
                        && nature.getCodeGo().equals(consultation.getNaturePrestation().value())) {
                    return nature;
                }
            } else {
                return nature;
            }
        }
        return null;
    }

    private EpmTRefAttribution getAttributionById(final Selects selects, final int id, Integer idOrganisme) {

        List<EpmTRefAttribution> attributions = filterSelectByIdOrganisme(selects.getAttribution(), idOrganisme);

        for (EpmTRefAttribution attribution : attributions)
            if (attribution.getId() == id)
                return attribution;
        return null;
    }

    /**
     * @param selects
     * @param consultation
     * @param obligatoire
     *            Dans le cas ou obligatoire == false, on renvoi le premier
     *            objet qu'on récupère juste pour faire passer la sauvegarde en
     *            base de données
     * @return EpmTRefStatut
     */
    private EpmTRefStatut getEpmTRefStatut(final Selects selects, final Consultation consultation,
                                           final boolean obligatoire, Integer idOrganisme) {

        List<EpmTRefStatut> statuts = filterSelectByIdOrganisme(selects.getStatut(), idOrganisme);

        for (EpmTRefStatut statut : statuts) {
            if (obligatoire) {
                if (statut.getCodeGo() != null && consultation.getStatut() != null && consultation.getStatut().equals(statut.getCodeGo())) {
                    return statut;
                }
            } else {
                return statut;
            }
        }
        return null;
    }

    /**
     * @param obligatoire
     *            Dans le cas ou obligatoire == false, on renvoi le premier
     *            objet qu'on récupère juste pour faire passer la sauvegarde en
     *            base de données
     * @return EpmTRefDirectionService
     */
    private EpmTRefDirectionService getEpmTRefDirectionService(
            final Referentiels referentiels, final Consultation consultation,
            final boolean obligatoire, Integer idOrganisme) {

        List<Referentiel> refs = filterReferentielByIdOrganisme(referentiels.getRefDirectionServiceLecture(), idOrganisme);

        for (Referentiel ref : refs) {
            EpmTRefDirectionService directionService = (EpmTRefDirectionService) ref;
            if (obligatoire) {
                if (directionService.getCode() != null
                        && consultation.getDirectionService() != null
                        && consultation.getDirectionService().equals(directionService.getCode())) {
                    return directionService;
                }
            } else {
                return directionService;
            }
        }
        return null;
    }

    private EpmTRefClausesSociales getEpmTRefClausesSociales(final Referentiels referentiels, String code){
        for (Referentiel ref :referentiels.getRefClausesSociales()){
            EpmTRefClausesSociales refClausesSociales = (EpmTRefClausesSociales) ref;
            if (refClausesSociales.getCodeClause() != null
                    && code.equals(refClausesSociales.getCodeClause())) {
                return refClausesSociales;
            }
        }
        return null;
    }

    private EpmTRefClausesEnvironnementales getEpmTRefClausesEnvironnementales(final Referentiels referentiels, String code){
        for (Referentiel ref :referentiels.getRefClausesEnvironnementales()){
            EpmTRefClausesEnvironnementales refClausesEnvironnementales = (EpmTRefClausesEnvironnementales) ref;
            if (refClausesEnvironnementales.getCodeClause() != null
                    && code.equals(refClausesEnvironnementales.getCodeClause())) {
                return refClausesEnvironnementales;
            }
        }
        return null;
    }

    /**
     * @param referentiels
     * @param consultation
     * @param obligatoire
     *            Dans le cas ou obligatoire == false, on renvoi le premier
     *            objet qu'on récupère juste pour faire passer la sauvegarde en
     *            base de données
     * @return EpmTRefArticle
     */
    private EpmTRefArticle getEpmTRefArticle(Referentiels referentiels, Consultation consultation, final boolean obligatoire, Integer idOrganisme) {

        List<Referentiel> refs = filterReferentielByIdOrganisme(referentiels.getRefArticle(), idOrganisme);

        for (Referentiel ref : refs) {
            EpmTRefArticle article = (EpmTRefArticle) ref;
            if (obligatoire) {
                if (article.getCodeExterne() != null
                        && consultation.getArticle() != null
                        && consultation.getArticle().equals(article.getCodeExterne())) {
                    return article;
                }
            } else {
                return article;
            }
        }
        return null;
    }

    /**
     * @param referentiels
     * @param consultation
     * @param obligatoire
     *            Dans le cas ou obligatoire == false, on renvoi le premier
     *            objet qu'on récupère juste pour faire passer la sauvegarde en
     *            base de données
     * @return EpmTRefPouvoirAdjudicateur
     */
    private EpmTRefPouvoirAdjudicateur getEpmTRefPouvoirAdjudicateur(
            final Referentiels referentiels, final Consultation consultation,
            final boolean obligatoire, Integer idOrganisme) {

        List<Referentiel> refs = filterReferentielByIdOrganisme(referentiels.getRefPouvoirAdjudicateur(), idOrganisme);

        for (Referentiel ref : refs) {
            EpmTRefPouvoirAdjudicateur pouvoirAdjudicateur = (EpmTRefPouvoirAdjudicateur) ref;
            if (obligatoire) {
                if (pouvoirAdjudicateur.getCodeGo() != null
                        && consultation.getPouvoirAdjudicateur() != null
                        && pouvoirAdjudicateur.getCodeGo().equals(consultation.getPouvoirAdjudicateur())) {
                    return pouvoirAdjudicateur;
                }
            } else {
                return pouvoirAdjudicateur;
            }
        }
        return null;
    }

    /**
     * @param referentiels
     * @param consultation
     * @param obligatoire
     *            Dans le cas ou obligatoire == false, on renvoi le premier
     *            objet qu'on récupère juste pour faire passer la sauvegarde en
     *            base de données
     * @return EpmTRefProcedure
     */
    private EpmTRefProcedure getEpmTRefProcedure(final Referentiels referentiels, final Consultation consultation, final boolean obligatoire, Integer idOrganisme) {

        List<Referentiel> refs = filterReferentielByIdOrganisme(referentiels.getRefProcedureLecture(), idOrganisme);

        for (Referentiel ref : refs) {
            EpmTRefProcedure procedure = (EpmTRefProcedure) ref;
            if (obligatoire) {
                if (procedure.getCodeGo() != null && consultation.getTypeProcedure() != null && procedure.getCodeGo().equals(consultation.getTypeProcedure())) {
                    return procedure;
                }
            } else {
                return procedure;
            }
        }
        return null;
    }

    /**
     * @param obligatoire
     *            Dans le cas ou obligatoire == false, on renvoi le premier
     *            objet qu'on récupère juste pour faire passer la sauvegarde en
     *            base de données
     * @return EpmTRefChoixMoisJour
     */
    private EpmTRefChoixMoisJour getEpmTRefChoixMoisJour(final Selects selects, DureeMarcheType dureeMarcheType, final boolean obligatoire, Integer idOrganisme) {

        List<EpmTRefChoixMoisJour> choixMoisJours = filterSelectByIdOrganisme(selects.getChoixMoisJour(), idOrganisme);

        for (EpmTRefChoixMoisJour choixMoisJour : choixMoisJours) {
            if (obligatoire || dureeMarcheType != null) {
                if (dureeMarcheType.getNbJours() != null && choixMoisJour.getId() == EpmTRefChoixMoisJour.EN_JOUR) {
                    return choixMoisJour;
                } else if(dureeMarcheType.getNbMois() != null && choixMoisJour.getId() == EpmTRefChoixMoisJour.EN_MOIS) {
                    return choixMoisJour;
                }
            }
        }
        return choixMoisJours.get(0);
    }

    /**
     * Recherche dans le referentiel le CCAG correspondant à celui envoyé par le flux MPE.
     * Si pas de correspondance, on renvoi le dernier objet qu'on
     * récupère juste pour faire passer la sauvegarde en base de données
     *
     * @param referentiels
     * @param ccag
     * @return
     */
    private EpmTRefCcag getEpmTRefCcag(final Referentiels referentiels, final String ccag, Integer idOrganisme) {

        List<Referentiel> refs = filterReferentielByIdOrganisme(referentiels.getRefCcag(), idOrganisme);

        EpmTRefCcag epmTRefCcag = null;
        for (Referentiel ref : refs) {
            epmTRefCcag = (EpmTRefCcag) ref;
            if (epmTRefCcag.getCodeExterne().equals(ccag)) {
                return epmTRefCcag;
            }

        }

        return epmTRefCcag;

    }

    private Set<EpmTBudTranche> getListeEpmTBudTranche(Selects selects, ListeTrancheType listeTrancheType, Integer idOrganisme) {
        if(listeTrancheType != null && listeTrancheType.getTrancheFixe() != null && listeTrancheType.getTranchesCondionnelle() != null && !listeTrancheType.getTranchesCondionnelle().isEmpty()) {
            Set<EpmTBudTranche> tranches = new HashSet<EpmTBudTranche>();
            EpmTBudTranche epmTBudTrancheFixe = new EpmTBudTranche();
            epmTBudTrancheFixe.setCodeTranche("");
            epmTBudTrancheFixe.setIntituleTranche(listeTrancheType.getTrancheFixe().getIntitule());
            epmTBudTrancheFixe.setEpmTRefNatureTranche(getEpmTRefNatureTranche(selects, EpmTRefNatureTranche.TRANCHE_FIXE, idOrganisme));
            epmTBudTrancheFixe.setEpmTBudFormePrix(getEpmTBudFormePrix(selects, listeTrancheType.getTrancheFixe().getFormeDePrix(), idOrganisme));
            tranches.add(epmTBudTrancheFixe);

            EpmTRefNatureTranche natureTrancheConditionnelle = getEpmTRefNatureTranche(selects, EpmTRefNatureTranche.TRANCHE_CONDITIONNELLE, idOrganisme);
            for(TrancheConditionnelleType trancheConditionnelle : listeTrancheType.getTranchesCondionnelle()) {
                EpmTBudTranche epmTBudTranche = conversionService.map(trancheConditionnelle, EpmTBudTranche.class);
                epmTBudTranche.setEpmTRefNatureTranche(natureTrancheConditionnelle);
                EpmTBudFormePrix fdp = getEpmTBudFormePrix(selects, trancheConditionnelle.getFormeDePrix(), idOrganisme);
                if(fdp != null) {
                    epmTBudTranche.setEpmTBudFormePrix(fdp);
                }
                tranches.add(epmTBudTranche);
            }
            return tranches;
        }

        return null;
    }


    private EpmTBudFormePrixPu getEpmTBudFormePrixPu(Selects selects, FDPPartieUnitaireType fdpPartieUnitaireType, Integer idOrganisme) {
        EpmTBudFormePrixPu pu = new EpmTBudFormePrixPu();

        //infos défauts fdp
        EpmTBudFormePrixPf pf = getEpmTBudFormePrixPf(selects, fdpPartieUnitaireType.getPartieForfaitaire(), idOrganisme);
        pu.setPuDateValeur(pf.getPfDateValeur());
        pu.setPuEpmTRefVariations(pf.getPfEpmTRefVariations());
        pu.setPuEstimationHt(pf.getPfEstimationHt());
        pu.setPuEstimationTtc(pf.getPfEstimationTtc());

        // bon de commande et mini maxi
        EpmTRefBonQuantite epmTRefBonQuantite = getEpmTRefBonQuantite(selects, fdpPartieUnitaireType, idOrganisme);
        if(epmTRefBonQuantite != null) {
            pu.setEpmTRefBonQuantite(epmTRefBonQuantite);
            if(epmTRefBonQuantite.getId() == EpmTRefBonQuantite.ID_BON_COMMANDE) {
                EpmTRefMinMax epmTRefMinMax = getEpmTRefMinMax(selects, fdpPartieUnitaireType.getBonDeCommande(), idOrganisme);
                if(epmTRefMinMax != null) {
                    pu.setEpmTRefMinMax(epmTRefMinMax);
                    if(epmTRefMinMax.getId() == 1) {
                        MiniMaxiType miniMaxiType = fdpPartieUnitaireType.getBonDeCommande().getAvecMiniMaxi();
                        pu.setPuMinHt(miniMaxiType.getMini().doubleValue());
                        pu.setPuMaxHt(miniMaxiType.getMaxi().doubleValue());
                    }
                }
            }
        }

        //type de prix
        Set<EpmTRefTypePrix> epmTRefTypePrix = getEpmTRefTypePrix(selects, fdpPartieUnitaireType.getTypePrix(), idOrganisme);
        if(epmTRefTypePrix != null) {
            pu.setEpmTRefTypePrix(epmTRefTypePrix);
        }

        return pu;
    }

    private EpmTBudFormePrixPf getEpmTBudFormePrixPf(Selects selects, FDPPartieForfaitaireType fdpPartieForfaitaireType, Integer idOrganisme) {
        EpmTBudFormePrixPf pf = new EpmTBudFormePrixPf();

        if(fdpPartieForfaitaireType != null) {
            Calendar pfDateValeur = convertStringDateToCalendar(fdpPartieForfaitaireType.getDateDeValeur());
            if(pfDateValeur != null) {
                pf.setPfDateValeur(pfDateValeur);
            }

            if(fdpPartieForfaitaireType.getEstimationInterneHT() != null) {
                pf.setPfEstimationHt(fdpPartieForfaitaireType.getEstimationInterneHT().doubleValue());
            }

            if(fdpPartieForfaitaireType.getEstimationInterneTTC() != null) {
                pf.setPfEstimationTtc(fdpPartieForfaitaireType.getEstimationInterneTTC().doubleValue());
            }

            pf.setPfEpmTRefVariations(getEpmTRefVariation(selects, fdpPartieForfaitaireType.getVariationsPrix(), idOrganisme));
        }

        return pf;
    }

    private Set<EpmTRefVariation> getEpmTRefVariation(Selects selects, VariationPrixType variationsPrixType, Integer idOrganisme) {

        Set<EpmTRefVariation> epmTRefVariations = new HashSet<EpmTRefVariation>();

        if (variationsPrixType != null && variationsPrixType.getVariationsPrix() != null) {
            List<String> libellesVariationPrix = variationsPrixType.getVariationsPrix();
            List<EpmTRefVariation> variations = filterSelectByIdOrganisme(selects.getVariationTous(), idOrganisme);
            for (EpmTRefVariation variation : variations)
                if (libellesVariationPrix.contains(variation.getCodeExterne()))
                    epmTRefVariations.add(variation);
        }
        return epmTRefVariations;
    }

    private Set<EpmTRefTypePrix> getEpmTRefTypePrix(Selects selects, TypePrixType typePrixType, Integer idOrganisme) {

        Set<EpmTRefTypePrix> epmTRefTypePrix = new HashSet<EpmTRefTypePrix>();

        if (typePrixType != null && typePrixType.getTypePrix() != null) {
            List<String> libellesTypePrix = typePrixType.getTypePrix();

            List<EpmTRefTypePrix> typesPrix = filterSelectByIdOrganisme(selects.getTypePrix(), idOrganisme);
            for (EpmTRefTypePrix refTypePrix : typesPrix)
                if (libellesTypePrix.contains(refTypePrix.getCodeExterne()))
                    epmTRefTypePrix.add(refTypePrix);
        }
        return epmTRefTypePrix;
    }

    private EpmTRefMinMax getEpmTRefMinMax(Selects selects, BonDeCommandeType bonDeCommande, Integer idOrganisme) {

        if(bonDeCommande != null) {
            List<EpmTRefMinMax> epmTRefsMinMax = filterSelectByIdOrganisme(selects.getMinMax(), idOrganisme);

            for(EpmTRefMinMax epmTRefMinMax : epmTRefsMinMax) {
                if(bonDeCommande.getAvecMiniMaxi() != null && epmTRefMinMax.getId() == 1)
                    return epmTRefMinMax;
                if (bonDeCommande.getSansMiniMaxi() != null && bonDeCommande.getSansMiniMaxi() && epmTRefMinMax.getId() == 2)
                    return epmTRefMinMax;
            }
        }
        return null;
    }

    private EpmTRefBonQuantite getEpmTRefBonQuantite(Selects selects, FDPPartieUnitaireType partieUnitaire, Integer idOrganisme) {

        if(partieUnitaire != null) {
            List<EpmTRefBonQuantite> refBonCommandes = filterSelectByIdOrganisme(selects.getBonQuantite(), idOrganisme);

            for (EpmTRefBonQuantite refBonCommande : refBonCommandes) {
                if(partieUnitaire.getBonDeCommande() !=null && refBonCommande.getId() == EpmTRefBonQuantite.ID_BON_COMMANDE)
                    return refBonCommande;
                else if(partieUnitaire.getAutresPrixUnitaires() !=null && partieUnitaire.getAutresPrixUnitaires() && refBonCommande.getId() != EpmTRefBonQuantite.ID_BON_COMMANDE)
                    return refBonCommande;
            }
        }
        return null;
    }

    private EpmTRefGroupementAttributaire getEpmTRefGroupementAttributaire(Selects selects, String formeGroupementAttributaire, Integer idOrganisme) {

        if(formeGroupementAttributaire != null) {
            List<EpmTRefGroupementAttributaire> refs = filterSelectByIdOrganisme(selects.getGroupementAttributaire(), idOrganisme);

            for (EpmTRefGroupementAttributaire refGroupementAttributaire : refs)
                if(formeGroupementAttributaire.equals(refGroupementAttributaire.getCodeExterne()))
                    return refGroupementAttributaire;
        }
        return null;
    }

    private EpmTRefCritereAttribution getEpmTRefCritereAttribution(Referentiels referentiels, CriteresAttributionType criteresAttribution, Integer idOrganisme) {
        if(criteresAttribution != null) {

            List<Referentiel> refs = filterReferentielByIdOrganisme(referentiels.getRefCritereAttribution(), idOrganisme);

            for(Referentiel ref : refs) {
                EpmTRefCritereAttribution epmTRefCritereAttribution = (EpmTRefCritereAttribution) ref;

                //si critere du type "énoncé dans le cahier des charges
                if(criteresAttribution.getCritereCDC() != null && epmTRefCritereAttribution.getTypeCritere().equals(EpmTRefCritereAttribution.TYPE_CAHIER_CHARGES)) {
                    return epmTRefCritereAttribution;
                    //si critere du type "unique du prix plus bas"
                } else if(criteresAttribution.getCriterePrix() != null && epmTRefCritereAttribution.getTypeCritere().equals(EpmTRefCritereAttribution.TYPE_CRITERE_PRIX)) {
                    return epmTRefCritereAttribution;
                    //si critere du type "énoncés ci après" => libre
                } else if(criteresAttribution.getListeCritereLibre() != null && criteresAttribution.getListeCritereLibre().getCritereLibre() != null && !criteresAttribution.getListeCritereLibre().getCritereLibre().isEmpty() && epmTRefCritereAttribution.getTypeCritere().equals(EpmTRefCritereAttribution.TYPE_CRITERE_ORDRE)) {
                    return epmTRefCritereAttribution;
                } else if(criteresAttribution.getListeCriterePondere() != null && criteresAttribution.getListeCriterePondere().getCriterePondere() != null && !criteresAttribution.getListeCriterePondere().getCriterePondere().isEmpty() && epmTRefCritereAttribution.getTypeCritere().equals(EpmTRefCritereAttribution.TYPE_CRITERE_PONDERE)) {
                    return epmTRefCritereAttribution;
                }
            }
        }
        return null;
    }

    private EpmTRefDureeDelaiDescription getEmTRefDureeDelaiDescription(Selects selects, DureeMarcheType dureeMarcheType, Integer idOrganisme) {

        List<EpmTRefDureeDelaiDescription> refs = filterSelectByIdOrganisme(selects.getDureeDelaiDescription(), idOrganisme);

        for (EpmTRefDureeDelaiDescription epmTRefDureeDelaiDescription : refs) {
            if ((dureeMarcheType.getNbJours() != null || dureeMarcheType.getNbMois() != null) && EpmTRefDureeDelaiDescription.DUREE_MARCHE_EN_MOIS_EN_JOUR == epmTRefDureeDelaiDescription.getId()) {
                return epmTRefDureeDelaiDescription;
            } else if (dureeMarcheType.getDescriptionLibre() != null && EpmTRefDureeDelaiDescription.DESCRIPTION_LIBRE == epmTRefDureeDelaiDescription.getId()) {
                return epmTRefDureeDelaiDescription;
            } else if (dureeMarcheType.getDateACompterDu() != null && dureeMarcheType.getDateJusquau() != null && EpmTRefDureeDelaiDescription.DELAI_EXECUTION_DU_AU == epmTRefDureeDelaiDescription.getId()) {
                return epmTRefDureeDelaiDescription;
            }
        }
        return null;
    }

    private EpmTRefNatureTranche getEpmTRefNatureTranche(Selects selects, int idTranche, Integer idOrganisme) {

        List<EpmTRefNatureTranche> naturesTranche = filterSelectByIdOrganisme(selects.getNatureTranche(), idOrganisme);

        for (EpmTRefNatureTranche epmTRefNatureTranche : naturesTranche)
            if(epmTRefNatureTranche.getId() == idTranche)
                return epmTRefNatureTranche;
        return null;
    }

    private Calendar convertGregorianCalendarToCalendar(XMLGregorianCalendar dateACompterDuXML) {
        Date dateDu = dateACompterDuXML.toGregorianCalendar().getTime();
        Calendar calendarDateDu = Calendar.getInstance();
        calendarDateDu.setTime(dateDu);
        return calendarDateDu;
    }

    private Calendar convertStringDateToCalendar(String dateDeValeur) {
        try {
            if(dateDeValeur != null && !dateDeValeur.isEmpty()) {
                DateFormat pfDateValeurFormat = new SimpleDateFormat("MM/yyyy");
                Date pfDateValeur = pfDateValeurFormat.parse(dateDeValeur);
                Calendar calendarPfDateValeur = Calendar.getInstance();
                calendarPfDateValeur.setTime(pfDateValeur);
                return calendarPfDateValeur;
            }
        } catch (ParseException e) {
            LOG.debug(e.getMessage(), e.fillInStackTrace());
        }

        return null;
    }

    private List<Referentiel> filterReferentielByIdOrganisme(Collection<? extends Referentiel> refs, Integer idOrganisme) {
        List<Referentiel> resultatOrganisme = new ArrayList<Referentiel>();
        List<Referentiel> resultatDefault = new ArrayList<Referentiel>();

        for (Referentiel referentiel : refs) {
            if(referentiel.getEpmTRefOrganisme() == null) {
                resultatDefault.add(referentiel);
            } else if(referentiel.getEpmTRefOrganisme() != null && referentiel.getEpmTRefOrganisme().getId() == idOrganisme) {
                resultatOrganisme.add(referentiel);
            }
        }

        if(resultatOrganisme.isEmpty()) {
            return resultatDefault;
        }

        return resultatOrganisme;
    }

    private <T extends Select> List<T> filterSelectByIdOrganisme(Collection<T> selects, Integer idOrganisme) {
        List<T> resultatOrganisme = new ArrayList<T>();
        List<T> resultatDefault = new ArrayList<T>();

        for (T select : selects) {
            if (select.getEpmTRefOrganisme() == null) {
                resultatDefault.add(select);
            } else if(select.getEpmTRefOrganisme() != null && select.getEpmTRefOrganisme().getId() == idOrganisme) {
                resultatOrganisme.add(select);
            }
        }

        if (resultatOrganisme.isEmpty()) {
            return resultatDefault;
        }

        return resultatOrganisme;
    }

    private EpmTRefNbCandidatsAdmis getEpmTRefNbCandidatsAdmis(Selects selects, int idNbCandidatAdmin, Integer idOrganisme) {

        List<EpmTRefNbCandidatsAdmis> epmTRefNbCandidats = filterSelectByIdOrganisme(selects.getNbCandidatsAdmis(), idOrganisme);

        for(EpmTRefNbCandidatsAdmis epmTRefNbCandidat : epmTRefNbCandidats)
            if(epmTRefNbCandidat.getId() == idNbCandidatAdmin)
                return epmTRefNbCandidat;
        return null;
    }

    /**
     * la méthode peut créer une liste de EpmTCritereAttributionConsultation en récupérant un objet de CriteresAttributionType
     *
     * @param consultation la cosultation associé avec la liste de EpmTCritereAttributionConsultation
     * @param referentiels
     * @param criteresAttribution
     * @param idOrganisme
     * @return la liste de EpmTCritereAttributionConsultation
     */
    private Set<EpmTCritereAttributionConsultation> getEpmTCritereAttributionConsultation(EpmTConsultation consultation, Referentiels referentiels, CriteresAttributionType criteresAttribution, Integer idOrganisme) {

        Set<EpmTCritereAttributionConsultation> listeCritereAttributionConsultation = new HashSet<EpmTCritereAttributionConsultation>();

        if(criteresAttribution != null) {

            List<Referentiel> refs = filterReferentielByIdOrganisme(referentiels.getRefCritereAttribution(), idOrganisme);

            for(Referentiel ref : refs) {
                EpmTRefCritereAttribution epmTRefCritereAttribution = (EpmTRefCritereAttribution) ref;

                //si critere du type "énoncé dans le cahier des charges
                if(criteresAttribution.getCritereCDC() != null && epmTRefCritereAttribution.getTypeCritere().equals(EpmTRefCritereAttribution.TYPE_CAHIER_CHARGES)) {
                    EpmTCritereAttributionConsultation epmTCritereAttributionConsultation =  new EpmTCritereAttributionConsultation();
                    epmTCritereAttributionConsultation.setId(0);
                    epmTCritereAttributionConsultation.setEnonce(epmTRefCritereAttribution.getLibelle());
                    epmTCritereAttributionConsultation.setOrdre(0);
                    epmTCritereAttributionConsultation.setEpmTConsultation(consultation);
                    listeCritereAttributionConsultation.add(epmTCritereAttributionConsultation);

                    return listeCritereAttributionConsultation;

                    //si critere du type "unique du prix plus bas"
                } else if(criteresAttribution.getCriterePrix() != null && epmTRefCritereAttribution.getTypeCritere().equals(EpmTRefCritereAttribution.TYPE_CRITERE_PRIX)) {
                    EpmTCritereAttributionConsultation epmTCritereAttributionConsultation =  new EpmTCritereAttributionConsultation();
                    epmTCritereAttributionConsultation.setId(0);
                    epmTCritereAttributionConsultation.setEnonce(epmTRefCritereAttribution.getLibelle());
                    epmTCritereAttributionConsultation.setOrdre(0);
                    epmTCritereAttributionConsultation.setEpmTConsultation(consultation);
                    listeCritereAttributionConsultation.add(epmTCritereAttributionConsultation);

                    return listeCritereAttributionConsultation;

                    //si critere du type "énoncés ci après" => libre
                } else if(criteresAttribution.getListeCritereLibre() != null && criteresAttribution.getListeCritereLibre().getCritereLibre() != null && !criteresAttribution.getListeCritereLibre().getCritereLibre().isEmpty() && epmTRefCritereAttribution.getTypeCritere().equals(EpmTRefCritereAttribution.TYPE_CRITERE_ORDRE)) {

                    int compte = 0;
                    for(CritereLibreType critereLibre: criteresAttribution.getListeCritereLibre().getCritereLibre()){

                        EpmTCritereAttributionConsultation epmTCritereAttributionConsultation =  new EpmTCritereAttributionConsultation();
                        epmTCritereAttributionConsultation.setId(0);
                        epmTCritereAttributionConsultation.setEnonce(critereLibre.getEnonce().trim());
                        epmTCritereAttributionConsultation.setOrdre(compte++);
                        epmTCritereAttributionConsultation.setEpmTConsultation(consultation);
                        if(critereLibre.getListeSousCriteresAttribution() != null && critereLibre.getListeSousCriteresAttribution().getSousCriteresAttribution() != null) {
                            Set<EpmTSousCritereAttributionConsultation> listeSousCriteres = new HashSet<EpmTSousCritereAttributionConsultation>();

                            int ordreSC = 0;
                            for (SousCriteresAttributionType sousCriteresAttribution : critereLibre.getListeSousCriteresAttribution().getSousCriteresAttribution()) {
                                EpmTSousCritereAttributionConsultation epmTSousCritere = new EpmTSousCritereAttributionConsultation();
                                epmTSousCritere.setId(0);
                                epmTSousCritere.setEnonce(sousCriteresAttribution.getCritere());
                                epmTSousCritere.setOrdre(ordreSC++);
                                listeSousCriteres.add(epmTSousCritere);
                            }
                            epmTCritereAttributionConsultation.setSousCritere(listeSousCriteres);
                        }
                        listeCritereAttributionConsultation.add(epmTCritereAttributionConsultation);
                    }

                    return listeCritereAttributionConsultation;

                } else if(criteresAttribution.getListeCriterePondere() != null && criteresAttribution.getListeCriterePondere().getCriterePondere() != null && !criteresAttribution.getListeCriterePondere().getCriterePondere().isEmpty() && epmTRefCritereAttribution.getTypeCritere().equals(EpmTRefCritereAttribution.TYPE_CRITERE_PONDERE)) {

                    int compte = 0;
                    for(CriterePondereType criterePondere: criteresAttribution.getListeCriterePondere().getCriterePondere()){
                        EpmTCritereAttributionConsultation epmTCritereAttributionConsultation =  new EpmTCritereAttributionConsultation();
                        epmTCritereAttributionConsultation.setId(0);
                        epmTCritereAttributionConsultation.setEnonce(criterePondere.getEnonce().trim());
                        epmTCritereAttributionConsultation.setOrdre(compte++);
                        Double ponderation = Double.valueOf(criterePondere.getPourcentagePonderation());
                        epmTCritereAttributionConsultation.setPonderation(ponderation);
                        epmTCritereAttributionConsultation.setEpmTConsultation(consultation);
                        if(criterePondere.getListeSousCriteresAttribution() != null && criterePondere.getListeSousCriteresAttribution().getSousCriteresAttribution() != null) {
                            Set<EpmTSousCritereAttributionConsultation> listeSousCriteres = new HashSet<EpmTSousCritereAttributionConsultation>();

                            int ordreSC = 0;
                            for (SousCriteresAttributionType sousCriteresAttribution : criterePondere.getListeSousCriteresAttribution().getSousCriteresAttribution()) {
                                EpmTSousCritereAttributionConsultation epmTSousCritere = new EpmTSousCritereAttributionConsultation();
                                epmTSousCritere.setId(0);
                                epmTSousCritere.setEnonce(sousCriteresAttribution.getCritere());
                                epmTSousCritere.setPonderation(Double.valueOf(sousCriteresAttribution.getPourcentagePonderation()));
                                epmTSousCritere.setOrdre(ordreSC++);
                                listeSousCriteres.add(epmTSousCritere);
                            }
                            epmTCritereAttributionConsultation.setSousCritere(listeSousCriteres);
                        }
                        listeCritereAttributionConsultation.add(epmTCritereAttributionConsultation);
                    }

                    return listeCritereAttributionConsultation;
                }
            }
        }
        return listeCritereAttributionConsultation;
    }

    private Set<EpmTBudTranche> getEpmTBudTranchesAssocies(ListCodeTrancheType listCodesTranches, Set<EpmTBudTranche> tranches) {
        Set<EpmTBudTranche> tranchesAssocies = new HashSet<EpmTBudTranche>();

        if (listCodesTranches != null && listCodesTranches.getCodeTranche() != null
                && !listCodesTranches.getCodeTranche().isEmpty()) {
            for (Iterator it = tranches.iterator(); it.hasNext();) {
                EpmTBudTranche tranche = (EpmTBudTranche) it.next();
                if (listCodesTranches.getCodeTranche().contains(tranche.getCodeTranche())
                        || (tranche.getEpmTRefNatureTranche().getId() == EpmTRefNatureTranche.TRANCHE_FIXE && (listCodesTranches.getCodeTranche().contains(IDENTIFIANT_TRANCHE_FIXE)))) {
                    tranchesAssocies.add(tranche);
                }
            }
        }
        return tranchesAssocies;
    }

    private EpmTRefReponseElectronique getEpmTRefReponseElectronique(Referentiels referentiels, Consultation consultation, final boolean obligatoire, Integer idOrganisme) {
        List<Referentiel> refs = filterReferentielByIdOrganisme(referentiels.getRefReponseElectronique(), idOrganisme);

        for (Referentiel ref : refs) {
            EpmTRefReponseElectronique epmTRefReponseElectronique = (EpmTRefReponseElectronique) ref;

            if (epmTRefReponseElectronique.getCodeExterne() != null
                    && consultation.getReponseElectronique() != null
                    && consultation.getReponseElectronique().equals(epmTRefReponseElectronique.getCodeExterne())) {
                return epmTRefReponseElectronique;
            }

        }
        return null;
    }

    /**
     * Recherche dans le referentiel Droits de propriété intellectuelle correspondant à celui envoyé par le flux MPE.
     */
    private EpmTRefDroitProprieteIntellectuelle getEpmTRefDroitProprieteIntellectuelle(final Referentiels referentiels, final String droitProprieteIntellectuelle, Integer idOrganisme) {
        List<Referentiel> refs = filterReferentielByIdOrganisme(referentiels.getRefDroitProprieteIntellectuelle(), idOrganisme);
        for (Referentiel ref : refs) {
            EpmTRefDroitProprieteIntellectuelle epmTRefDroitProprieteIntellectuelle = (EpmTRefDroitProprieteIntellectuelle) ref;
            if (epmTRefDroitProprieteIntellectuelle.getCodeExterne() != null && epmTRefDroitProprieteIntellectuelle.getCodeExterne().equals(droitProprieteIntellectuelle)) {
                return epmTRefDroitProprieteIntellectuelle;
            }
        }
        return null;
    }

    private Set<EpmTRefTypeStructureSociale> getListeStructuresSocialeReserves(Referentiels referentiels, StructuresSocialeReserveType structuresSocialeReserveType, Integer idOrganisme) {
        Set<EpmTRefTypeStructureSociale> resultat = new HashSet<>();
        if (structuresSocialeReserveType != null) {
            List<String> structureSocialeReserves = structuresSocialeReserveType.getStructureSocialeReserve();
            for (String code : structureSocialeReserves) {
                for (Referentiel ref : referentiels.getRefStructureSocialeReserves()) {
                    EpmTRefTypeStructureSociale epmTRefTypeStructureSociale = (EpmTRefTypeStructureSociale) ref;
                    if (epmTRefTypeStructureSociale.getCodeExterne().equals(code)) {
                        resultat.add(epmTRefTypeStructureSociale);
                    }
                }
            }
        }
        return resultat;
    }

    private Set<EpmTRefLieuExecution> getListEpmTLieuExecutions(Referentiels referentiels, List<String> listCodeLieuExecutions) {
        Set<EpmTRefLieuExecution> result = new HashSet<EpmTRefLieuExecution>();

        List<EpmTRefLieuExecution> epmTRefLieuExecutions = referentiels.getRefLieuExecution();
        for (String codeLieuExecution : listCodeLieuExecutions)
            for (EpmTRefLieuExecution lieuExecution : epmTRefLieuExecutions)
                if (lieuExecution.getCode().equals(codeLieuExecution))
                    result.add(lieuExecution);
        return result;
    }

    /**
     * sauvegarder ou modifier la date d'une étape de calendrier
     *
     */
    private void sauvegardeCalendrier(Date date, int typeEtape, Integer idConsultation) throws TechnicalNoyauException, ApplicationNoyauException {

        // Date de remise de plis
        EtapeSimple etape = null;

        etape = calendrierGIM.chargerEtapeDateCal(idConsultation, typeEtape);

        if (etape == null) {
            etape = new EtapeSimple();
        }
        etape.setDate(date);

        // Sauvegarde des dates de calendrier
        EpmTEtapeCal etapeCal;
        if (etape.getId() == 0) {
            etapeCal = new EpmTEtapeCal();
            etapeCal.setTypeEtape(typeEtape);
        } else {
            EtapeCalCritere etapeCalCritere = new EtapeCalCritere();
            etapeCalCritere.setId(etape.getId());

            etapeCal = (EpmTEtapeCal) consultationGIM.chercherUniqueParCritere(etapeCalCritere);
        }


        etapeCal.setDateHerite(etape.getDate());

        CalendrierCritere calendrierCritere = new CalendrierCritere();
        calendrierCritere.setConsultation(idConsultation);
        EpmTCalendrier epmTCalendrier = (EpmTCalendrier) consultationGIM.chercherUniqueParCritere(calendrierCritere);

        if (epmTCalendrier == null) {
            epmTCalendrier = new EpmTCalendrier();
            epmTCalendrier.setConsultation(idConsultation);
        }

        if (epmTCalendrier.getEtapes() == null) {
            epmTCalendrier.setEtapes(new ArrayList<EpmTEtapeCal>());
        }

        epmTCalendrier.getEtapes().add(etapeCal);

        epmTCalendrier = (EpmTCalendrier) consultationGIM.modifier(epmTCalendrier);
    }


    public final void setAdministrationGIM(final AdministrationGIM valeur) {
        this.administrationGIM = valeur;
    }

    public final void setConversionService(final DozerBeanMapper valeur) {
        this.conversionService = valeur;
    }

    public final void setCalendrierGIM(final CalendrierGIM valeur) {
        this.calendrierGIM = valeur;
    }

    public final void setConsultationGIM(final ConsultationGIM valeur) {
        this.consultationGIM = valeur;
    }

    public final void setReferentielsServiceLocal(ReferentielsServiceLocal referentielsServiceLocal) {
        this.referentielsServiceLocal = referentielsServiceLocal;
    }

    public final void setGeneriqueDAO(GeneriqueDAO generiqueDAO) {
        this.generiqueDAO = generiqueDAO;
    }

    public final void setSelectsService(final SelectsGIM valeur) {
        this.selectsService = valeur;
    }

}
