package fr.atexo.rsem.noyau.ws.beans.miseADisposition;

public class MiseAdispositionBean {

    /**
     * id de la mise à disposition
     */
    private String id;

    /**
     * @return the id
     */
    public final String getId() {
        return id;
    }

    /**
     * @param id the id to set
     */
    public final void setId(String id) {
        this.id = id;
    }

}
