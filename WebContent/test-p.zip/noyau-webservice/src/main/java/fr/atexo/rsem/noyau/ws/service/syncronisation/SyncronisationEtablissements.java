package fr.atexo.rsem.noyau.ws.service.syncronisation;

import com.atexo.execution.common.dto.EtablissementDTO;
import com.atexo.execution.common.dto.FournisseurDTO;
import fr.paris.epm.noyau.metier.EpmTContratCritere;
import fr.paris.epm.noyau.metier.GeneriqueDAO;
import fr.paris.epm.noyau.persistance.EpmTAttributaire;
import fr.paris.epm.noyau.persistance.EpmTContrat;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

/**
 * Created by dcs on 08/12/16.
 * for Atexo
 */
@Service
public class SyncronisationEtablissements {

    private GeneriqueDAO generiqueDAO;

    public SyncronisationEtablissements() {
        System.out.println("test");
    }

    public List<EtablissementDTO> getEtablissementWithSiretAndAfterDate(long date) {

        List<EtablissementDTO> listEtablissementDTO = new ArrayList<>();

        EpmTContratCritere contratCritere = new EpmTContratCritere();
        contratCritere.setJoinAttributaire(true);
        contratCritere.setDateValidationAPartirDe(new Date(date));
        List<EpmTContrat> listEpmTContrats = generiqueDAO.findByCritere(contratCritere);

        listEpmTContrats.forEach(
                c -> listEtablissementDTO.addAll(c.getAttributaires().stream()
                        .filter(a -> a.getSiret() != null)
                        .map(a -> {
                            EtablissementDTO etablisementDTO = new EtablissementDTO();
                            etablisementDTO.setDateModificationExterne(c.getDateValidation());
                            etablisementDTO.setId(new Long(a.getId()));
                            etablisementDTO.setSiret(a.getSiret());
                            etablisementDTO.setFournisseur(epmTAttributaireToFourniseurDTO(a));
                            return etablisementDTO;
                        })
                        .collect(Collectors.toList())));

        return listEtablissementDTO;
    }

    private FournisseurDTO epmTAttributaireToFourniseurDTO(EpmTAttributaire epmTAttributaire) {
        FournisseurDTO fournisseurDTO = new FournisseurDTO();
        fournisseurDTO.setSiren(epmTAttributaire.getSiren());
        fournisseurDTO.setRaisonSociale((epmTAttributaire.getRaisonSocial()));
        return fournisseurDTO;
    }

    public void setGeneriqueDAO(GeneriqueDAO generiqueDAO) {
        this.generiqueDAO = generiqueDAO;
    }

}
