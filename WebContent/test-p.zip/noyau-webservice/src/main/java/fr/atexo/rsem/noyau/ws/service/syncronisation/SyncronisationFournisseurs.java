package fr.atexo.rsem.noyau.ws.service.syncronisation;

import com.atexo.execution.common.dto.FournisseurDTO;
import fr.paris.epm.noyau.metier.EntrepriseCritere;
import fr.paris.epm.noyau.persistance.EpmTEntreprise;
import fr.paris.epm.noyau.service.AdministrationServiceSecurise;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

/**
 * Created by dcs on 08/12/16.
 * for Atexo
 */
@Service
public class SyncronisationFournisseurs {

    @Autowired
    AdministrationServiceSecurise administrationService;

    public List<FournisseurDTO> getFournisseursAfterDate(long date) {

        EntrepriseCritere entrepriseCritere = new EntrepriseCritere();
        entrepriseCritere.setLastSynchro(new Date(date));

        List<EpmTEntreprise> listEpmTEntreprises = administrationService.chercherEpmTObject(0, entrepriseCritere);

        return listEpmTEntreprises.stream()
                .map(e -> {
                    FournisseurDTO fournisseurDTO = new FournisseurDTO();

                    fournisseurDTO.setDateModificationExterne(e.getDateCreationFiche());
                    fournisseurDTO.setEmail(e.getEmail());
                    fournisseurDTO.setNom(e.getNom());
                    fournisseurDTO.setFax(e.getFax());
                    fournisseurDTO.setSiren(e.getSiren());
                    fournisseurDTO.setId((long) e.getId());
                    fournisseurDTO.setCodeApeNafNace(e.getCodeAPE());
                    fournisseurDTO.setRaisonSociale(e.getNom());
                    fournisseurDTO.setFormeJuridique(e.getFormeJuridique().getLibelle());

                    String telephone = null;
                    if (e.getTelephoneFixe() != null)
                        telephone = e.getTelephoneFixe();
                    else if (e.getTelephoneMobile() != null)
                        telephone = e.getTelephoneMobile();
                    fournisseurDTO.setTelephone(telephone);

                    return fournisseurDTO;
                }).collect(Collectors.toList());
    }

}
