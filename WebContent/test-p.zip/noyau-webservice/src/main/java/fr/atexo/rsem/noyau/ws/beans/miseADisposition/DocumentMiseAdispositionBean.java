package fr.atexo.rsem.noyau.ws.beans.miseADisposition;

import java.io.File;
import java.util.Date;

public class DocumentMiseAdispositionBean {

    /**
     * Chemin du fichier après la décompression de l'archive. Utilisé uniquement
     * par les clients du webService. N'est pas utilisé pour la génération du
     * XML.
     */
    private File pathFichier;
    
    /**
     * nom du document
     */
    private String nomDeFichier;
    /**
     * type du document
     */
    private String type;
    
    /**
     * La catégorie du document (piéce du dce, piéce de la réponse, aapc etc...)
     */
    private String categorie;
    
    /**
     * La date du document (date de création de du document ou date saisie par l'utilisateur dans l'interface)
     */
    private Date date;
    
    /**
     * Commmentaire du document saisi pas l'utilisateur.
     */
    private String commentaire;
    
    /**
     * Objet du document dans le cas d'un document externe.
     */
    private String objet;
    
    private boolean preRemplis = false;
    
    /**
     * indiquer étape spécifique
     */
    private String statut;

    /**
     * @return String
     */
    public final String getNomDeFichier() {
        return nomDeFichier;
    }

    /**
     * @param nomDeFichier
     */

    public final void setNomDeFichier(String nomDeFichier) {
        this.nomDeFichier = nomDeFichier;
    }

    /**
     * @return String
     */
    public final String getType() {
        return type;
    }

    /**
     * @param type
     */
    public final void setType(final String valeur) {
        this.type = valeur;
    }

    public final String getCategorie() {
        return categorie;
    }

    public final void setCategorie(final String valeur) {
        this.categorie = valeur;
    }

    public final Date getDate() {
        return date;
    }

    public final void setDate(final Date valeur) {
        this.date = valeur;
    }

    public final String getCommentaire() {
        return commentaire;
    }

    public final void setCommentaire(final String valeur) {
        this.commentaire = valeur;
    }

    public final String getObjet() {
        return objet;
    }

    public final void setObjet(final String valeur) {
        this.objet = valeur;
    }

    public final boolean isPreRemplis() {
        return preRemplis;
    }

    public final void setPreRemplis(final boolean valeur) {
        this.preRemplis = valeur;
    }

    public final String getStatut() {
		return statut;
	}

	public final void setStatut(final String valeur) {
		this.statut = valeur;
	}

	/**
     * @return Chemin du fichier après la décompression de l'archive. Utilisé uniquement
     * par les clients du webService. N'est pas utilisé pour la génération du
     * XML.
     */
    public final File getPathFichier() {
        return pathFichier;
    }

    /**
     * @param valeur chemin du fichier après la décompression de l'archive. Utilisé uniquement
     * par les clients du webService. N'est pas utilisé pour la génération du
     * XML.
     */
    public final void setPathFichier(final File valeur) {
        this.pathFichier = valeur;
    }
}
