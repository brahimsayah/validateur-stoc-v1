
package fr.atexo.rsem.noyau.ws.beans;

import java.util.Date;
import java.util.List;

import javax.xml.bind.annotation.XmlElementWrapper;

/**
 * Bean répresentant les estimations de la forme de prix lors de la création
 * d'une consultation. Ce bean est utilisé par le Webservice REST pour échanges
 * des données du contrat d'EPM avec des applications tiers
 * 
 * @author RDA
 * @version $Revision$, $Date$, $Author$
 */
public class EstimationPrixBean {

	/**
	 * Type de prix : Prix sur catalogue, Bordereau de prix ou Autre
	 */
	private List<String> typePrix;
	/**
	 * Variation du prix partie unitaire : Actualisables  ou Révisables ou Fermes.
	 */
	
	private List<String> variationPrixUnitaire;
	/**
	 * Variation du prix partie forfaitaire : Actualisables  ou Révisables ou Fermes.
	 */
	private List<String> variationPrixForfaitaire;

    private FormePrixBean formePrix;
    private Date datePrix;
    private double estimationHTForfataire;
    private double estimationHTUnitaire;
    private double estimationTTCForfataire;
    private double estimationTTCUnitaire;
	/**
	 * @return the typePrix
	 */
    @XmlElementWrapper(name="listeTypesPrix")
	public final List<String> getTypePrix() {
		return typePrix;
	}
	/**
	 * @param typePrix the typePrix to set
	 */
	public final void setTypePrix(List<String> valeur) {
		this.typePrix = valeur;
	}
	/**
	 * @return the variationPrixUnitaire
	 */
	@XmlElementWrapper(name="listeVariationsPrixUnitaire")
	public final List<String> getVariationPrixUnitaire() {
		return variationPrixUnitaire;
	}
	/**
	 * @param variationPrixUnitaire the variationprix to set
	 */
	public final void setVariationPrixUnitaire(List<String> valeur) {
		this.variationPrixUnitaire = valeur;
	}
	/**
	 * @return the variationPrixForfaitaire
	 */
	@XmlElementWrapper(name="listeVariationsPrixForfaitaire")
	public final List<String> getVariationPrixForfaitaire() {
		return variationPrixForfaitaire;
	}
	/**
	 * @param variationPrixForfaitaire the variationprix to set
	 */
	public final void setVariationPrixForfaitaire(List<String> valeur) {
		this.variationPrixForfaitaire = valeur;
	}
	/**
	 * @return the formePrix
	 */
	public final FormePrixBean getFormePrix() {
		return formePrix;
	}
	/**
	 * @param formePrix the formePrix to set
	 */
	public final void setFormePrix(FormePrixBean valeur) {
		this.formePrix = valeur;
	}
	/**
	 * @return the datePrix
	 */
	public final Date getDatePrix() {
		return datePrix;
	}
	/**
	 * @param datePrix the datePrix to set
	 */
	public final void setDatePrix(Date valeur) {
		this.datePrix = valeur;
	}
	/**
	 * @return the estimationHTForfataire
	 */
	public final double getEstimationHTForfataire() {
		return estimationHTForfataire;
	}
	/**
	 * @param estimationHTForfataire the estimationHTForfataire to set
	 */
	public final void setEstimationHTForfataire(double valeur) {
		this.estimationHTForfataire = valeur;
	}
	/**
	 * @return the estimationHTUnitaire
	 */
	public final double getEstimationHTUnitaire() {
		return estimationHTUnitaire;
	}
	/**
	 * @param estimationHTUnitaire the estimationHTUnitaire to set
	 */
	public final void setEstimationHTUnitaire(double valeur) {
		this.estimationHTUnitaire = valeur;
	}
	/**
	 * @return the estimationTTCForfataire
	 */
	public final double getEstimationTTCForfataire() {
		return estimationTTCForfataire;
	}
	/**
	 * @param estimationTTCForfataire the estimationTTCForfataire to set
	 */
	public final void setEstimationTTCForfataire(double valeur) {
		this.estimationTTCForfataire = valeur;
	}
	/**
	 * @return the estimationTTCUnitaire
	 */
	public final double getEstimationTTCUnitaire() {
		return estimationTTCUnitaire;
	}
	/**
	 * @param estimationTTCUnitaire the estimationTTCUnitaire to set
	 */
	public final void setEstimationTTCUnitaire(double valeur) {
		this.estimationTTCUnitaire = valeur;
	}

}
