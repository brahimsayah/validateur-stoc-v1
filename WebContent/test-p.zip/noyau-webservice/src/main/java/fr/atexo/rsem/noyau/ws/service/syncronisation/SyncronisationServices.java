package fr.atexo.rsem.noyau.ws.service.syncronisation;

import com.atexo.execution.common.dto.ServiceDTO;
import fr.paris.epm.noyau.persistance.referentiel.EpmTRefDirectionService;
import fr.paris.epm.noyau.service.AdministrationServiceSecurise;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * Created by dcs on 07/12/16.
 * for Atexo
 */
@Service
public class SyncronisationServices {

    @Autowired
    AdministrationServiceSecurise administrationService;

    public List<ServiceDTO> getAllServices() {

        List<EpmTRefDirectionService> listEpmTRefDirectionService = administrationService.listerDirectionServices(0);

        Map<Long, Long> relation = new HashMap<Long, Long>();
        List<ServiceDTO> listServicesDTO = listEpmTRefDirectionService.stream()
                .map(s -> {
                    ServiceDTO serviceDTO = new ServiceDTO();

                    serviceDTO.setNom(s.getNom());
                    serviceDTO.setId((long) s.getId());
                    serviceDTO.setActif(s.isActifLecture());

                    if (s.getTypeEntite() != null)
                        serviceDTO.setNiveau(Integer.parseInt(s.getTypeEntite()));

                    s.getEnfants().forEach(e -> relation.put((long) e.getId(), (long) s.getId()));

                    return serviceDTO;
                })
                .collect(Collectors.toList());

        listServicesDTO.stream()
                .filter(s -> relation.containsKey(s.getId()))
                .forEach(s -> s.setIdParent(relation.get(s.getId())));

        return listServicesDTO;
    }

}
