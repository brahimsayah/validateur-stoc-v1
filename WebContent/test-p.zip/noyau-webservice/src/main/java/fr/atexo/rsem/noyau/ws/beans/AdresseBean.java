package fr.atexo.rsem.noyau.ws.beans;

import javax.xml.bind.annotation.XmlElement;

/**
 * Utilise pour l'echange d'informations avec des entites externes a RSEM.
 * @author RVI
 * @version $Revision$, $Date$, $Author$
 */
public class AdresseBean {

    private String adresse;

    private String codePostal;

    private String ville;

    private String telephone;

    private String fax;

    private String email;

    public final String getAdresse() {
        return adresse;
    }

    public final void setAdresse(final String valeur) {
        this.adresse = valeur;
    }

    public final String getCodePostal() {
        return codePostal;
    }

    public final void setCodePostal(final String valeur) {
        this.codePostal = valeur;
    }

    @XmlElement(name = "commune")
    public final String getVille() {
        return ville;
    }

    public final void setVille(final String valeur) {
        this.ville = valeur;
    }

    public final String getTelephone() {
        return telephone;
    }

    public final void setTelephone(final String valeur) {
        this.telephone = valeur;
    }

    public final String getFax() {
        return fax;
    }

    public final void setFax(final String valeur) {
        this.fax = valeur;
    }

    public final String getEmail() {
        return email;
    }

    public final void setEmail(final String valeur) {
        this.email = valeur;
    }
}
