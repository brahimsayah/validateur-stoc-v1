package fr.atexo.rsem.noyau.ws.service.syncronisation;

import com.atexo.execution.common.dto.UtilisateurDTO;
import fr.paris.epm.noyau.persistance.EpmTUtilisateur;
import fr.paris.epm.noyau.service.AdministrationServiceSecurise;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

/**
 * Created by dcs on 30/11/16.
 * for Atexo
 */
@Service
public class SyncronisationUtilisateur {

    @Autowired
    AdministrationServiceSecurise administrationService;

    public List<UtilisateurDTO> getAllUtilisateur() {

        List<EpmTUtilisateur> listEpmTUtilisateur = administrationService.listerUtilisateurs(0);

        return listEpmTUtilisateur.stream()
                .map(SyncronisationStaticClass::epmTUtilisateurToUtilisateurDTO)
                .collect(Collectors.toList());
    }

}
