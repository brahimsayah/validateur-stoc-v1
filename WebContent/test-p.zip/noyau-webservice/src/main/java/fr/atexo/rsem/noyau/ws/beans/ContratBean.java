
package fr.atexo.rsem.noyau.ws.beans;

import java.util.Date;
import java.util.List;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElementWrapper;

/**
 * Bean répresentant les informations d'un contrat. Ce
 * bean est utilisé par le Webservice REST pour échanges des données du contrat
 * d'EPM avec des applications tiers
 * 
 * @author RDA
 * @version $Revision$, $Date$, $Author$
 */
public class ContratBean extends ContratSimpleBean {
    
	/**
	 * Date de demande de legalité lors de l'attribution du marché
	 */
	private Date dateDemandeLegalite;
	/**
	 * Date de signature lors de l'attribution du marché
	 */
	private Date dateSignature;

	/**
	 * Le prix estimé lors de la définition des données de la consultation
	 * (formulaire amont)
	 */
    private EstimationPrixBean estimationPrix;

    private String numeroLot;

    private Boolean marcheABonDeCommande;
    
    private List<TrancheBean> tranches;
	
    private List<LotTechniqueBean> lotsTechniques;
	private Integer nombreReconductions;
	private String modalitesReconduction;
	private String variantesTechniques;
	
	private Integer idMiseADispositionExecution;
    
    /**
     * Type d'attributaire : Groupement, Solidaire
     */
    private String typeAttributaire;

	/**
	 * @return the dateDemandeLegalite
	 */
	public final Date getDateDemandeLegalite() {
		return dateDemandeLegalite;
	}

	/**
	 * @param dateDemandeLegalite
	 *            the dateDemandeLegalite to set
	 */
	public final void setDateDemandeLegalite(Date valeur) {
		this.dateDemandeLegalite = valeur;
	}

	/**
	 * @return the dateSignature
	 */
	public final Date getDateSignature() {
		return dateSignature;
	}

	/**
	 * @param dateSignature
	 *            the dateSignature to set
	 */
	public final void setDateSignature(Date valeur) {
		this.dateSignature = valeur;
	}

	/**
	 * @return the estimationPrix
	 */
	public final EstimationPrixBean getEstimationPrix() {
		return estimationPrix;
	}
	/**
	 * @param estimationPrix the estimationPrix to set
	 */
	public final void setEstimationPrix(EstimationPrixBean valeur) {
		this.estimationPrix = valeur;
	}
	/**
	 * @return the numeroLot
	 */
	public final String getNumeroLot() {
		return numeroLot;
	}
	/**
	 * @param numeroLot the numeroLot to set
	 */
	public final void setNumeroLot(String valeur) {
		this.numeroLot = valeur;
	}
	/**
	 * @return the marcheABonDeCommande
	 */
	public final Boolean getMarcheABonDeCommande() {
		return marcheABonDeCommande;
	}
	/**
	 * @param marcheABonDeCommande the marcheABonDeCommande to set
	 */
	public final void setMarcheABonDeCommande(Boolean valeur) {
		this.marcheABonDeCommande = valeur;
	}
	/**
	 * @return the tranches
	 */
	@XmlElementWrapper(name = "tranches")
	@XmlElement(name="tranche")	
	public final List<TrancheBean> getTranches() {
		return tranches;
	}
	/**
	 * @param tranches the tranches to set
	 */
	public final void setTranches(List<TrancheBean> valeur) {
		this.tranches = valeur;
	}
	/**
	 * @return the lotsTechniques
	 */
	@XmlElementWrapper(name = "lotsTechniques")
	@XmlElement(name="lotTechnique")
	public final List<LotTechniqueBean> getLotsTechniques() {
		return lotsTechniques;
	}
	/**
	 * @param lotsTechniques the lotsTechniques to set
	 */
	public final void setLotsTechniques(List<LotTechniqueBean> valeur) {
		this.lotsTechniques = valeur;
	}
	/**
	 * @return the typeAttributaire
	 */
	public final String getTypeAttributaire() {
		return typeAttributaire;
	}
	/**
	 * @param typeAttributaire the typeAttributaire to set
	 */
	public final void setTypeAttributaire(String valeur) {
		this.typeAttributaire = valeur;
	}
	
	/**
	 * @return the nombreReconductions
	 */
	public final Integer getNombreReconductions() {
		return nombreReconductions;
	}

	/**
	 * @param nombreReconductions
	 *            the nombreReconductions to set
	 */
	public final void setNombreReconductions(Integer valeur) {
		this.nombreReconductions = valeur;
	}

	/**
	 * @return the modalitesReconduction
	 */
	public final String getModalitesReconduction() {
		return modalitesReconduction;
	}

	/**
	 * @param modalitesReconduction
	 *            the modalitesReconduction to set
	 */
	public final void setModalitesReconduction(String valeur) {
		this.modalitesReconduction = valeur;
	}

	/**
	 * @return the variantesTechniques
	 */
	public final String getVariantesTechniques() {
		return variantesTechniques;
	}

	/**
	 * @param variantesTechniques
	 *            the variantesTechniques to set
	 */
	public final void setVariantesTechniques(String valeur) {
		this.variantesTechniques = valeur;
	}

    public final Integer getIdMiseADispositionExecution() {
        return idMiseADispositionExecution;
    }

    public final void setIdMiseADispositionExecution(final Integer valeur) {
        this.idMiseADispositionExecution = valeur;
    }
}
