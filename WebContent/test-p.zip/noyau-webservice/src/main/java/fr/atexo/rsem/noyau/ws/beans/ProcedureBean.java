package fr.atexo.rsem.noyau.ws.beans;

public class ProcedureBean {

	/**
	 * L'intitulé : consultation / avenant
	 */
	private String intitule;

	/**
	 * L'objet : consultation / avenant
	 */
	private String objet;

	/**
	 * Nom du pouvoir adjudicateur de la consultation
	 */
	private String nomContractantPublicMarche;
	/**
	 * Code externe du pouvoir adjudicateur de la consultation
	 */
	private String codeContractantPublicMarche;
	/**
	 * Nom de la direction service responsable de la consultation
	 */
	private String nomResponsableMarche;

	/**
	 * Code externe de la direction service responsable de la consultation
	 */
	private String codeResponsableMarche;

	/**
	 * Nom de la direction service beneficiaire de la consultation
	 */
	private String nomServiceGestionnaireDuMarche;
	/**
	 * Code externe de la direction service beneficiaire de la consultation
	 */
	private String codeServiceGestionnaireDuMarche;

	/**
	 * Nom de la direction service
	 */
	private String nomDirectionServiceMarche;

	/**
	 * Code de la direction service
	 */
	private String codeDirectionServiceMarche;
	
	/**
	 * Procédure de passation
	 */
	private String procedure;
	
	/**
	 * Code d'organisme (gérer le multi-entité)
	 */
	private String codeOrganisme;
	
	/**
	 * @return the intitule
	 */
	public final String getIntitule() {
		return intitule;
	}

	/**
	 * @param intitule
	 *            the intitule to set
	 */
	public final void setIntitule(String valeur) {
		this.intitule = valeur;
	}

	/**
	 * @return the objet
	 */
	public final String getObjet() {
		return objet;
	}

	/**
	 * @param objet
	 *            the objet to set
	 */
	public final void setObjet(String valeur) {
		this.objet = valeur;
	}

	/**
	 * @return the nomContractantPublicMarche
	 */
	public final String getNomContractantPublicMarche() {
		return nomContractantPublicMarche;
	}

	/**
	 * @param nomContractantPublicMarche
	 *            the nomContractantPublicMarche to set
	 */
	public final void setNomContractantPublicMarche(String valeur) {
		this.nomContractantPublicMarche = valeur;
	}

	/**
	 * @return the codeContractantPublicMarche
	 */
	public final String getCodeContractantPublicMarche() {
		return codeContractantPublicMarche;
	}

	/**
	 * @param codeContractantPublicMarche
	 *            the codeContractantPublicMarche to set
	 */
	public final void setCodeContractantPublicMarche(String valeur) {
		this.codeContractantPublicMarche = valeur;
	}

	/**
	 * @return the nomResponsableMarche
	 */
	public final String getNomResponsableMarche() {
		return nomResponsableMarche;
	}

	/**
	 * @param nomResponsableMarche
	 *            the nomResponsableMarche to set
	 */
	public final void setNomResponsableMarche(String valeur) {
		this.nomResponsableMarche = valeur;
	}

	/**
	 * @return the codeResponsableMarche
	 */
	public final String getCodeResponsableMarche() {
		return codeResponsableMarche;
	}

	/**
	 * @param codeResponsableMarche
	 *            the codeResponsableMarche to set
	 */
	public final void setCodeResponsableMarche(String valeur) {
		this.codeResponsableMarche = valeur;
	}

	/**
	 * @return the nomServiceGestionnaireDuMarche
	 */
	public final String getNomServiceGestionnaireDuMarche() {
		return nomServiceGestionnaireDuMarche;
	}

	/**
	 * @param nomServiceGestionnaireDuMarche
	 *            the nomServiceGestionnaireDuMarche to set
	 */
	public final void setNomServiceGestionnaireDuMarche(String valeur) {
		this.nomServiceGestionnaireDuMarche = valeur;
	}

	/**
	 * @return the codeServiceGestionnaireDuMarche
	 */
	public final String getCodeServiceGestionnaireDuMarche() {
		return codeServiceGestionnaireDuMarche;
	}

	/**
	 * @param codeServiceGestionnaireDuMarche
	 *            the codeServiceGestionnaireDuMarche to set
	 */
	public final void setCodeServiceGestionnaireDuMarche(String valeur) {
		this.codeServiceGestionnaireDuMarche = valeur;
	}

	/**
	 * @return the nomDirectionServiceMarche
	 */
	public final String getNomDirectionServiceMarche() {
		return nomDirectionServiceMarche;
	}

	/**
	 * @param nomDirectionServiceMarche
	 *            the nomDirectionServiceMarche to set
	 */
	public final void setNomDirectionServiceMarche(String valeur) {
		this.nomDirectionServiceMarche = valeur;
	}

	/**
	 * @return the codeDirectionServiceMarche
	 */
	public final String getCodeDirectionServiceMarche() {
		return codeDirectionServiceMarche;
	}

	/**
	 * @param codeDirectionServiceMarche
	 *            the codeDirectionServiceMarche to set
	 */
	public final void setCodeDirectionServiceMarche(String valeur) {
		this.codeDirectionServiceMarche = valeur;
	}

	/**
	 * @return the procedure
	 */
	public final String getProcedure() {
		return procedure;
	}

	/**
	 * @param procedure
	 *            the procedure to set
	 */
	public final void setProcedure(String valeur) {
		this.procedure = valeur;
	}

	public final String getCodeOrganisme() {
		return codeOrganisme;
	}

	public final void setCodeOrganisme(String valeur) {
		this.codeOrganisme = valeur;
	}

}
