package fr.atexo.rsem.noyau.ws.beans.redaction;

import javax.xml.bind.annotation.XmlElement;

public class ConfigurationType {

    @XmlElement(required = true)
    String plateformeEditeur;

    public String getPlateformeEditeur() {
        return plateformeEditeur;
    }
}
