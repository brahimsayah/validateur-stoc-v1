package fr.atexo.rsem.noyau.ws.rest.crypto;

import fr.atexo.rsem.noyau.ws.beans.ErreurBean;
import fr.atexo.rsem.noyau.ws.rest.AuthentificationRestWebService;
import fr.paris.epm.noyau.commun.exception.NonTrouveNoyauException;
import fr.paris.epm.noyau.commun.exception.TechnicalNoyauException;
import fr.paris.epm.noyau.metier.*;
import fr.paris.epm.noyau.metier.objetvaleur.Selects;
import fr.paris.epm.noyau.persistance.*;
import fr.paris.epm.noyau.persistance.referentiel.EpmTRefStatutEnveloppe;
import fr.paris.epm.noyau.persistance.referentiel.Select;
import fr.paris.epm.noyau.service.GeneriqueServiceSecurise;
import fr.paris.epm.noyau.service.select.SelectsServiceSecurise;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import javax.servlet.http.HttpServletResponse;
import javax.xml.bind.JAXBElement;
import java.util.Collection;
import java.util.List;

/**
 * Created by ael on 16/03/17.
 */
// The Java class will be hosted at the URI path "/blocPlis"
@Controller
//@Api(value = "statutEnveloppe", description = "Ce WebService met a jour une offre ouverte ou en cours de dechiffrement", consumes = "application/json")
public class StatutEnveloppeController {

    private static final Logger LOG = LoggerFactory.getLogger(StatutEnveloppeController.class);
    private final static String OFFRE = "OFFRE";
    private final static String ANONYMAT = "ANONYMAT";
    private final static String CANDIDATURE = "CANDIDATURE";
    private final static String REPONSE = "REPONSE";
    private final static String PROJET = "PROJET";

    @Autowired
    private GeneriqueServiceSecurise depotService;

    @Autowired
    private NotificationGIM notificationGIM;

    @Autowired
    private SelectsServiceSecurise selectsService;

    private static int getLineNumber() {
        return Thread.currentThread().getStackTrace()[2].getLineNumber();
    }

    @RequestMapping(value = "/statutEnveloppe/{idOffreCandidature}/{typeOffreCandidature}/{numeroLot}/{statut}/{idUtilisateur}/{token}", method = RequestMethod.GET)
    public ResponseEntity<String> changerStatut(HttpServletResponse response,
                                                @PathVariable int idOffreCandidature, @PathVariable String typeOffreCandidature,
                                                @PathVariable int numeroLot, @PathVariable int statut, @PathVariable int idUtilisateur,
                                                @PathVariable("token") String token) {

        LOG.info("/statutEnveloppe/" + idOffreCandidature + "/" + typeOffreCandidature + "/" + numeroLot + "/" + statut + "/" + idUtilisateur + "/" + token);

        AuthentificationRestWebService auth = new AuthentificationRestWebService();
        JAXBElement<ErreurBean> errorToken = auth.verificationToken(token);
        if (!StringUtils.isEmpty(errorToken.getValue().getMessage()))
            return erreurAuthentification();
        try {
            //cherher le statut actuel de l'enveloppe
            EpmTRefStatutEnveloppe statutEnveloppe;

            //si l'opération demandée est l'ouverture de l'enveloppe on change le statut actuel par STAT_OUVERTE
            if (EpmTRefStatutEnveloppe.STAT_OUVERTE == statut)
                statutEnveloppe = (EpmTRefStatutEnveloppe) getStatutEnveloppeOuvert(EpmTRefStatutEnveloppe.STAT_OUVERTE);
            //sinon si l'opération demandée est la mise en cours de déchiffrement de l'enveloppe on change le statut actuel par EN_COURS_DECHIFFREMENT
            else if (EpmTRefStatutEnveloppe.STAT_EN_COURS_DECHIFFREMENT == statut)
                statutEnveloppe = (EpmTRefStatutEnveloppe) getStatutEnveloppeOuvert(EpmTRefStatutEnveloppe.STAT_EN_COURS_DECHIFFREMENT);
            //sinon si l'opération demandée est la mise en cours de déchiffrement de l'enveloppe on change le statut actuel par EN_COURS_DECHIFFREMENT
            else if (EpmTRefStatutEnveloppe.STAT_ECHEC_OUVERTURE == statut)
                statutEnveloppe = (EpmTRefStatutEnveloppe) getStatutEnveloppeOuvert(EpmTRefStatutEnveloppe.STAT_ECHEC_OUVERTURE);
            else
                return new ResponseEntity<String>("Paramétre statut incorrecte", HttpStatus.BAD_REQUEST);

            if (OFFRE.equalsIgnoreCase(typeOffreCandidature) || ANONYMAT.equalsIgnoreCase(typeOffreCandidature))// en cas d'une offre
                traiterObjet(EpmTOffreLc.class, idOffreCandidature, numeroLot, statutEnveloppe);
            else if (CANDIDATURE.equalsIgnoreCase(typeOffreCandidature))// en cas d'une candidature
                traiterObjet(EpmTCandidature.class, idOffreCandidature, numeroLot , statutEnveloppe);
            else if (REPONSE.equalsIgnoreCase(typeOffreCandidature))// en cas d'une reponse
                traiterObjet(EpmTReponseLc.class, idOffreCandidature, numeroLot, statutEnveloppe);
            else if (PROJET.equalsIgnoreCase(typeOffreCandidature))// en cas d'un projet
                traiterObjet(EpmTProjetLc.class, idOffreCandidature, numeroLot, statutEnveloppe);
            else
                return new ResponseEntity<String>("Paramétre typeOffreCandidature incorrecte", HttpStatus.BAD_REQUEST);

            // créer une notification
            if (EpmTRefStatutEnveloppe.STAT_OUVERTE == statut) {
                String typeNotification = "";
                switch (typeOffreCandidature.toUpperCase()) {
                case OFFRE:
                    typeNotification = EpmTNotification.DECHIFFREMENT_OFFRE_TERMINE;
                    break;
                case CANDIDATURE:
                    typeNotification = EpmTNotification.DECHIFFREMENT_CANDIDATURE_TERMINE;
                    break;
                case PROJET:
                    typeNotification = EpmTNotification.DECHIFFREMENT_PROJET_TERMINE;
                    break;
                case REPONSE:
                    typeNotification = EpmTNotification.DECHIFFREMENT_REPONSE_TERMINE;
                    break;
                case ANONYMAT:
                    typeNotification = EpmTNotification.DECHIFFREMENT_ANONYMAT_TERMINE;
                    break;
                default:
                    break;
                }
                notificationGIM.creerNotificationPourUtilisateur(typeNotification, idUtilisateur, idOffreCandidature);
            }
            return new ResponseEntity<String>("Mise à jour bien effectuée", HttpStatus.OK);

        } catch (TechnicalNoyauException | NonTrouveNoyauException e) {
            // en cas d'erreur technique
            LOG.error("Erreur lors de la mise à jour du statut de l'enveloppe", e.fillInStackTrace());
            return new ResponseEntity<String>("Erreur technique", HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    private ResponseEntity<String> erreurAuthentification() {
        // en cas d'un jeton authentification invalide on retourne un message d'erreur d'authentification avec le statut not accepted
        LOG.error( "Accés non autorisé : " + this.getClass().getName() + " : " + getLineNumber());
        return new ResponseEntity<String>("Accés non autorisé ", HttpStatus.UNAUTHORIZED);
    }

    private void traiterObjet(Class clazz, int id, Integer numeroLot, EpmTRefStatutEnveloppe statut) throws TechnicalNoyauException {
        if (clazz == EpmTOffreLc.class) {
            EpmTOffreLc offreLc = getEpmTOffreLc(id, numeroLot);
            if (offreLc == null)
                throw new TechnicalNoyauException("Offre LC inexistante : " + id);
            //on applique le nouveau statut à l'objet trouvé auparavant
            offreLc.setStatutEnveloppe(statut);
            depotService.modifierEpmTObject(offreLc);
        } else if (clazz == EpmTCandidature.class) {
            EpmTCandidature epmTCandidature = getEpmTCandidature(id);
            if (epmTCandidature == null)
                throw new TechnicalNoyauException("Candidature inexistante : " + id);
            epmTCandidature.setStatutEnveloppe(statut);
            depotService.modifierEpmTObject(epmTCandidature);
        } else if (clazz == EpmTReponseLc.class) {
            EpmTReponseLc reponse = getReponseLc(id, numeroLot);
            if (reponse == null)
                // en cas de non existance de l'enveloppe on doit avertir l'utilisateur par un message et un statut de Not_Found
                throw new TechnicalNoyauException("Reponse inexistante : " + id);
            //on applique le nouveau statut à l'objet trouvé auparavant
            reponse.setStatutEnveloppe(statut);
            depotService.modifierEpmTObject(reponse);
        } else if (clazz == EpmTProjetLc.class) {
            EpmTProjetLc projet = getProjetLc(id, numeroLot);
            if (projet == null)
                throw new TechnicalNoyauException("Projet inexistant : " + id);
            //on applique le nouveau statut à l'objet trouvé auparavant
            projet.setStatutEnveloppe(statut);
            depotService.modifierEpmTObject(projet);
        }
    }


    private EpmTOffreLc getEpmTOffreLc( final int idOffre, final int numeroLot) {
        EpmTOffreLc res = null;
        OffreLcCritere offreLcCritere  = new OffreLcCritere();
        offreLcCritere.setIdOffre(idOffre);
        offreLcCritere.setNumeroLot(numeroLot);
        List<EpmTOffreLc> epmTOffreLcList = null;
        try {
            epmTOffreLcList = depotService.chercherEpmTObject(0, offreLcCritere);
        } catch (TechnicalNoyauException e) {
            LOG.error(e.getMessage(), e.fillInStackTrace());
            throw e;
        }
        if( !epmTOffreLcList.isEmpty())
            res = epmTOffreLcList.get(0);

        return res;
    }

    private EpmTProjetLc getProjetLc(final int id, final int numeroLot) {
        EpmTProjetLc res = null;
        ProjetLcCritere projetCritere = new ProjetLcCritere();
        projetCritere.setIdProjet(id);
        projetCritere.setNumeroLot(numeroLot);
        List<EpmTProjetLc> reponsesLC = null;
        try {
            reponsesLC = depotService.chercherEpmTObject(0, projetCritere);
        } catch (TechnicalNoyauException e) {
            LOG.error(e.getMessage(), e.fillInStackTrace());
            throw e;
        }
        if (!reponsesLC.isEmpty())
            res = reponsesLC.get(0);
        return res;
    }

    private EpmTReponseLc getReponseLc(final int idReponse, final int numeroLot) {

        EpmTReponseLc res = null;
        ReponseLcCritere reponseLcCritere = new ReponseLcCritere();
        reponseLcCritere.setIdReponse(idReponse);
        reponseLcCritere.setNumeroLot(numeroLot);
        List<EpmTReponseLc> reponsesLC = null;
        try {
            reponsesLC = depotService.chercherEpmTObject(0, reponseLcCritere);
        } catch (TechnicalNoyauException e) {
            LOG.error(e.getMessage(), e.fillInStackTrace());
            throw e;
        }
        if (!reponsesLC.isEmpty())
            res = reponsesLC.get(0);

        return res;
    }

    private EpmTCandidature getEpmTCandidature( final int idCandidature) {

        EpmTCandidature res = null;

        CandidatureCritere candidatureCritere  = new CandidatureCritere();
        candidatureCritere.setId(idCandidature);

        List<EpmTCandidature> epmTCandidatureList = null;
        try {
            epmTCandidatureList = depotService.chercherEpmTObject(0, candidatureCritere);
        } catch (TechnicalNoyauException e) {
            LOG.error(e.getMessage(), e.fillInStackTrace());
            throw e;
        }
        if( !epmTCandidatureList.isEmpty())
            res = epmTCandidatureList.get(0);

        return res;
    }

    private Select getStatutEnveloppeOuvert(int id) {
        Selects selects = selectsService.getAllSelects();
        Collection<EpmTRefStatutEnveloppe> col = selects.getStatutsCandidatures();
        Select select = null;

        for (EpmTRefStatutEnveloppe element : col) {
            if (element.getId() == id) {
                select = element;
                break;
            }
        }
        return select;
    }

}