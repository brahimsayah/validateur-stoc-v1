package fr.atexo.rsem.noyau.ws.rest;

import com.sun.jersey.spi.resource.Singleton;
import fr.atexo.rsem.noyau.ws.beans.*;
import fr.atexo.rsem.noyau.ws.beans.redaction.Consultation;
import fr.atexo.rsem.noyau.ws.beans.redaction.InitialisationType;
import fr.atexo.rsem.noyau.ws.beans.redaction.RedactionType;
import fr.atexo.rsem.noyau.ws.beans.redaction.UtilisateurType;
import fr.atexo.rsem.noyau.ws.rest.constantes.ConstantesRestWebService;
import fr.atexo.rsem.noyau.ws.rest.constantes.ConstantesRestWebService.ErreurEnum;
import fr.atexo.rsem.noyau.ws.rest.metier.InitialisationConsultationWebServiceGIM;
import fr.atexo.rsem.noyau.ws.service.AttributionMarcheService;
import fr.paris.epm.noyau.commun.Constantes;
import fr.paris.epm.noyau.commun.exception.ApplicationNoyauException;
import fr.paris.epm.noyau.commun.exception.NonTrouveNoyauException;
import fr.paris.epm.noyau.commun.exception.TechnicalNoyauException;
import fr.paris.epm.noyau.metier.*;
import fr.paris.epm.noyau.metier.objetvaleur.UtilisateurExterneConsultation;
import fr.paris.epm.noyau.metier.technique.TableStockageEPM;
import fr.paris.epm.noyau.persistance.*;
import fr.paris.epm.noyau.persistance.referentiel.EpmTRefOrganisme;
import fr.paris.epm.noyau.persistance.referentiel.EpmTRefParametrage;
import fr.paris.epm.noyau.persistance.referentiel.EpmTRefTypeMarche;
import fr.paris.epm.noyau.service.ReferentielsServiceLocal;
import org.dozer.DozerBeanMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;
import javax.xml.bind.JAXBElement;
import javax.xml.namespace.QName;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;

/**
 * Web service REST de recuperation des depots et pour la récuperation des
 * marchés
 *
 * @author RVI, RDA
 * @version $Revision$, $Date$, $Author$
 */
@Path("/consultation")
@Singleton
public class ConsultationRestWebService {

    private static final Logger LOG = LoggerFactory.getLogger(ConsultationRestWebService.class);

    /**
     * Table associant un utilisateur externe a une consulation (instanciee par Spring).
     */
    private static AttributionMarcheService attributionMarcheService;

    private static InitialisationConsultationWebServiceGIM initialisationConsultationWebServiceGIM;

    private static GeneriqueDAO generiqueDAO;

    private static DozerBeanMapper conversionService;

    private static ReferentielsServiceLocal referentielsServiceLocal;

    private static TableStockageEPM tableStockageEPM;

    /**
     * Service qui permet de récupèrer un contrat à partir de son reference
     *
     * @param reference numéro du contrat
     * @param token obtenir auprès authentifier
     * @return
     */
    @GET
    @Path("/contrat/{reference}")
    @Produces(MediaType.APPLICATION_XML)
    public JAXBElement<? extends ResponseBean> recupererContratsParId(@PathParam("reference") String reference,
                                                                      @QueryParam(ConstantesRestWebService.XML_QNAME_TOKEN) String token) {
        JAXBElement<ErreurBean> resError = new JAXBElement<ErreurBean>(new QName(ConstantesRestWebService.XML_QNAME_ERREUR), ErreurBean.class, new ErreurBean());
        AuthentificationRestWebService auth = new AuthentificationRestWebService();
        JAXBElement<ErreurBean> erreurs = auth.verificationToken(token);

        String message = erreurs.getValue().getMessage();
        if (message != null && !message.isEmpty())
            return erreurs;

        JAXBElement<ResponseBean> res = new JAXBElement<ResponseBean>(new QName(ConstantesRestWebService.XML_QNAME_CONSULTATIONS), ResponseBean.class, null);
        if (reference == null) {
            LOG.error("Parametre invalide (reference = " + reference + ").");
            res.setValue(resError.getValue());
            return res;
        }

        EpmTContratCritere critere = new EpmTContratCritere();
        critere.setNumeroContrat(reference);
        return recupererMarches(critere, null);
    }

    @GET
    @Path("/contrat/{dateAPartirDe: (0[1-9]|[1-9]|[12][0-9]|3[01])(0[1-9]|1[012]|[1-9])(19|20|21|22)\\d{2}([01][0-9]|2[0123])([012345][0-9])([012345][0-9])}/{dateJusquAu: (0[1-9]|[1-9]|[12][0-9]|3[01])(0[1-9]|1[012]|[1-9])(19|20|21|22)\\d{2}([01][0-9]|2[0123])([012345][0-9])([012345][0-9])}")
    @Produces(MediaType.APPLICATION_XML)
    public JAXBElement<? extends ResponseBean> recupererContratsParDateValidation(@PathParam("dateAPartirDe") String dateAPartirDeParam,
                                                                                  @PathParam("dateJusquAu") String dateJusquAuParam,
                                                                                  @QueryParam(ConstantesRestWebService.XML_QNAME_TOKEN) String token) {

        AuthentificationRestWebService auth = new AuthentificationRestWebService();
        JAXBElement<? extends Object> resultat = auth.deconnexion(token);
        if (!(resultat.getValue() instanceof ErreurBean)) {

            LOG.info("Debut recuperation des contrats");
            JAXBElement<ErreurBean> resError = new JAXBElement<ErreurBean>(new QName(ConstantesRestWebService.XML_QNAME_ERREUR), ErreurBean.class, new ErreurBean());

            Date dateJusquAu = null;
            Date dateAPartirDe = null;
            try {
                dateAPartirDe = traiterParametreDate(dateAPartirDeParam, "ddMMyyyyHHmmss");
                dateJusquAu = traiterParametreDate(dateJusquAuParam, "ddMMyyyyHHmmss");
            } catch (ParseException e1) {
                resError.getValue().setCodeMessage(ErreurEnum.AUTRE, "Probleme lors du parsing de la date saisie (dateAPartirDe = " + dateAPartirDeParam + " -- dateJusquAu = " + dateJusquAuParam + ").");
                LOG.error("Date erreur: " + e1.getMessage());
                return resError;
            }

            EpmTContratCritere critere = new EpmTContratCritere();
            critere.setDateValidationAPartirDe(dateAPartirDe);
            critere.setDateValidationJusquAu(dateJusquAu);

            AvenantCritere avenantCritere = new AvenantCritere();
            avenantCritere.setDateValidationAPartirDe(dateAPartirDe);
            avenantCritere.setDateValidationJusquAu(dateJusquAu);
            return recupererMarches(critere,avenantCritere);
        }
        return (JAXBElement<ResponseBean>) resultat;
    }

    private Date traiterParametreDate(final String dateParametre, final String pattern) throws ParseException {
        SimpleDateFormat format = new SimpleDateFormat(pattern);
        return format.parse(dateParametre);
    }

    /**
     * Méthode générique pour récuperer les marchés
     *
     * @return flux XML des contrats et des avenants
     */
    private JAXBElement<? extends ResponseBean> recupererMarches(EpmTContratCritere epmTContratCritere, AvenantCritere epmTAvenantCritere) {
        JAXBElement<ErreurBean> resError = new JAXBElement<ErreurBean>(new QName(ConstantesRestWebService.XML_QNAME_ERREUR), ErreurBean.class, new ErreurBean());
        JAXBElement<ResponseBean> res = new JAXBElement<ResponseBean>(new QName(ConstantesRestWebService.XML_QNAME_RESULTAT), ResponseBean.class, null);

        List<ConsultationBean> consultations = new ArrayList<ConsultationBean>();
        List<AvenantBean> avenants = new ArrayList<AvenantBean>();

        try {
            List<EpmTContrat> epmTContrats = generiqueDAO.findByCritere(epmTContratCritere);

            Map<String, List<EpmTContrat>> contratsParConsultation = new HashMap<String, List<EpmTContrat>>();
            for (EpmTContrat contrat : epmTContrats) {
                LOG.debug(" Traitement du contrat dont l'id est le  : " + contrat.getId() + " et le n° est le :" + contrat.getNumeroContrat());
                List<EpmTContrat> contrats = contratsParConsultation.get(contrat.getNumeroConsultation());
                if (contrats == null) {
                    contrats = new ArrayList<EpmTContrat>();
                }

                contrats.add(contrat);
                contratsParConsultation.put(contrat.getNumeroConsultation(), contrats);
            }

            if (!contratsParConsultation.isEmpty()) {
                try {
                    consultations.addAll(attributionMarcheService.conversionEpmTConsultationVersConsultationBean(contratsParConsultation));
                } catch (NonTrouveNoyauException e) {
                    String message = "Consultation non trouvé : " + e.getMessage();
                    LOG.error(message);
                    resError.getValue().setCodeMessage(ErreurEnum.AUTRE, message);
                    return resError;
                }
            }

            if (epmTAvenantCritere == null) {
                epmTAvenantCritere = new AvenantCritere();
                epmTAvenantCritere.setIdContratInitial(epmTContrats.get(0).getId());
            }

            List<EpmTAvenant> epmTAvenants = generiqueDAO.findByCritere(epmTAvenantCritere);
            if (epmTAvenants != null) {
                //epmTAvenants.removeIf(epmTAvenant -> epmTAvenant.getIdContratInitial() == null);
                // lambda ne marche pas ici car Jersey de la version 1.5 ne le supporte pas

                Iterator<EpmTAvenant> avenantsIter = epmTAvenants.iterator();
                while (avenantsIter.hasNext()) {
                    if (avenantsIter.next().getIdContratInitial() == null) {
                        avenantsIter.remove();
                    }
                }

                if (!epmTAvenants.isEmpty())
                    avenants.addAll(attributionMarcheService.conversionEpmTAvenantVersAvenantBean(epmTAvenants));
            }

        } catch (TechnicalNoyauException e) {
            LOG.error(e.getMessage());
            resError.getValue().setCodeMessage(ErreurEnum.AUTRE, e.getMessage());
            return resError;
        }

        ResponseBean response = new ResponseBean();
        response.setConsultations(consultations);
        response.setAvenants(avenants);
        res.setValue(response);
        LOG.info("Fin recuperation des contrats");
        return res;
    }

    /**
     * Retourne la liste de depots de la consultation.
     *
     * @param numeroConsultation
     * @return une balise consultation si ok, erreur sinon
     */
    @GET
    @Path("/{numeroConsultation: [a-zA-Z0-9\\-]+}/listeDepots")
    @Produces(MediaType.APPLICATION_XML)
    public JAXBElement<? extends Object> getListeDepots(@PathParam("numeroConsultation") String numeroConsultation) {

        JAXBElement<ErreurBean> resError = new JAXBElement<ErreurBean>(new QName(ConstantesRestWebService.XML_QNAME_ERREUR), ErreurBean.class, new ErreurBean());
        JAXBElement<ConsultationBean> res = new JAXBElement<ConsultationBean>(new QName(ConstantesRestWebService.XML_QNAME_CONSULTATION), ConsultationBean.class, null);
        ConsultationBean consultation = new ConsultationBean();

        ConsultationCritere consultCritere = new ConsultationCritere();
        consultCritere.setReference(numeroConsultation);

        List<EpmTConsultation> consultBddList;
        try {
            consultBddList = generiqueDAO.findByCritere(consultCritere);
        } catch (TechnicalNoyauException e) {
            resError.getValue().setCodeMessage(ErreurEnum.TECHNIQUE_BASE_DE_DONNEES, "Probleme lors de la recuperation d'une consultation (numeroConsultation = " + numeroConsultation + ").");
            LOG.error(resError.getValue().toString(), e);
            return resError;
        }
        if ((consultBddList == null) || consultBddList.isEmpty()) {
            resError.getValue().setCodeMessage(ErreurEnum.ENTITE_NON_TROUVEE, "Aucune consultation " + numeroConsultation + "trouvee en base.");
            LOG.warn(resError.getValue().toString());
            return resError;
        }
        if (consultBddList.size() > 1) {
            resError.getValue().setCodeMessage(ErreurEnum.AUTRE, "Plus d'une consultation " + numeroConsultation + " trouvees en base.");
            LOG.error(resError.getValue().toString());
            return resError;
        }
        EpmTConsultation consultBdd = consultBddList.get(0);

        DepotCritere depotCritere = new DepotCritere();
        depotCritere.setIdConsultation(consultBdd.getId());
        List<EpmTDepot> depotBddList;
        try {
            depotBddList = generiqueDAO.findByCritere(depotCritere);
        } catch (TechnicalNoyauException e) {
            resError.getValue().setCodeMessage(ErreurEnum.TECHNIQUE_BASE_DE_DONNEES, "Probleme lors de la recuperation des depots (numeroConsultation = " + numeroConsultation + ").");
            LOG.error(resError.getValue().toString(), e);
            return resError;
        }
        for (EpmTDepot item : depotBddList) {
            DepotBean depotTmp = conversionService.map(item, DepotBean.class);
            if ((item.getEpmTEntreprise() != null) && ((item.getEpmTEntreprise().getTelephoneFixe() != null) || (item.getEpmTEntreprise().getTelephoneMobile() != null))) {

                if (depotTmp.getEntreprise() == null)
                    depotTmp.setEntreprise(new EntrepriseBean());

                if (depotTmp.getEntreprise().getAdresse() == null)
                    depotTmp.getEntreprise().setAdresse(new AdresseBean());

                if (item.getEpmTEntreprise().getTelephoneFixe() != null)
                    depotTmp.getEntreprise().getAdresse().setTelephone(item.getEpmTEntreprise().getTelephoneFixe());
                else
                    depotTmp.getEntreprise().getAdresse().setTelephone(item.getEpmTEntreprise().getTelephoneMobile());
            }
            consultation.getDepotList().add(depotTmp);
        }

        res.setValue(consultation);

        return res;
    }

    /**
     * TODO : verifier presence utilisateur externe (synchro avec MPE), ne pas
     * creer l'utilisateur ni profil, tests avec anneBesson
     */
    @PUT
    @Path("/initialisation")
    @Consumes(MediaType.APPLICATION_XML)
    @Produces(MediaType.APPLICATION_XML)
    public JAXBElement<? extends Object> initialisation(RedactionType redactionType, @QueryParam(ConstantesRestWebService.XML_QNAME_TOKEN) String token)
            throws TechnicalNoyauException, ApplicationNoyauException {
        JAXBElement<ErreurBean> errorToken = AuthentificationRestWebService.verificationToken(token);

        String message = errorToken.getValue().getMessage();
        if (message != null && !message.isEmpty())
            return errorToken;

        InitialisationType initialisationType = redactionType.getInitialisation();
        UtilisateurExterneConsultation utilExtConsult = null;
        UtilisateurType utilisateurExterne = initialisationType.getUtilisateur();

        JAXBElement<ErreurBean> resError = new JAXBElement<ErreurBean>(new QName(ConstantesRestWebService.XML_QNAME_ERREUR), ErreurBean.class, new ErreurBean());
        JAXBElement<String> res = new JAXBElement<String>(new QName(ConstantesRestWebService.XML_QNAME_IDENTIFIANT), String.class, null);

        String idUtilExtConsult = "";
        do {
            idUtilExtConsult = AuthentificationRestWebService.signature();
            utilExtConsult = tableStockageEPM.getUtilisateurExterneConsultation(idUtilExtConsult);
        } while (utilExtConsult != null);
        res.setValue(idUtilExtConsult);
        utilExtConsult = new UtilisateurExterneConsultation();

        // Creation de l'utilisateur temporaire
        EpmTUtilisateur utilisateur = rechercheUtilisateurExterne(utilisateurExterne);

        if (utilisateur == null) {
            resError.getValue().setCodeMessage(ErreurEnum.ENTITE_NON_TROUVEE, "Utilisateur " + utilisateurExterne.getNom() + " inconnu.");
            LOG.error(resError.getValue().toString());
            return resError;
        }

        //Les plateformes MPE et RSEM doivent être paramétrés de la même facon editeur/administration
        ParametrageCritere parametrageCritere = new ParametrageCritere();
        parametrageCritere.setClef("plateforme.editeur");
        EpmTRefParametrage refParametrage = generiqueDAO.findUniqueByCritere(parametrageCritere);
        String plateformeEditeur;
        if (refParametrage != null && refParametrage.getValeur().equals("1"))
            plateformeEditeur = "true";
        else if (refParametrage != null && refParametrage.getValeur().equals("0"))
            plateformeEditeur = "false";
        else
            plateformeEditeur = "";

        if (!utilisateurExterne.getConfiguration().getPlateformeEditeur().equals(plateformeEditeur)) {
            String messageErreur = "Les plateformes MPE et RSEM sont paramétrés différemments, " +
                    "elle doivent concorder sur le mode editeur (plateforme.editeur = 1), administratif (plateforme.editeur = 0) ou aucun (plateforme.editeur = 2/null) ";
            resError.getValue().setCodeMessage(ErreurEnum.TECHNIQUE_BASE_DE_DONNEES, messageErreur);
            LOG.error(resError.getValue().toString());
            return resError;
        }

        // Mise a jour ou creation de la consultation associee
        Consultation consultation = initialisationType.getConsultation();
        EpmTConsultation epmTConsultation = null;
        if (consultation != null) {
            Integer limiteObjet = getIntValueByParametrage(Constantes.PARAMETRAGE_TAILLE_OBJET_CONSULTATION);
            if (limiteObjet != null && consultation.getObjet() != null && consultation.getObjet().length() > limiteObjet) {
                String messageErreur = "Le nombre de caracteres relatif a l'objet de la consultation est superieur au limites supportees par le module de redaction (" + limiteObjet + " caracteres). Veuillez le modifier afin de creer le document.";
                resError.getValue().setCodeMessage(ErreurEnum.TECHNIQUE_BASE_DE_DONNEES, messageErreur);
                LOG.error(resError.getValue().toString());
                return resError;
            }
            try {
                epmTConsultation = initialisationConsultationWebServiceGIM.miseAJourConsultation(consultation, utilisateur);
            } catch (TechnicalNoyauException e) {
                resError.getValue().setCodeMessage(ErreurEnum.TECHNIQUE_BASE_DE_DONNEES,
                        "Probleme lors de la creation ou mise a jour de la consultation (Reference externe : "
                                + consultation.getReferenceExterne()
                                + " / numero de consultation "
                                + consultation.getNumeroConsultation()
                                + "). " + e.getMessage());
                LOG.error(resError.getValue().toString(), e);
                return resError;
            } catch (ApplicationNoyauException e) {
                resError.getValue().setCodeMessage(ErreurEnum.AUTRE,
                        "Probleme lors de la creation ou mise a jour de la consultation (Reference externe : "
                                + consultation.getReferenceExterne()
                                + " / numero de consultation "
                                + consultation.getNumeroConsultation()
                                + "). " + e.getMessage());
                LOG.error(resError.getValue().toString(), e);
                return resError;
            }
        }
        utilExtConsult.setConsultation(epmTConsultation);

        // Ajout des habilitations au profil de l'utilisateur
        // on efface les profils de l'utilisateurs et on lui affecte un profil
        // temporaire utilisé uniquement dans le cadre de l'accés externe
        // cette modification n'est pas sauvegardée. Elle sera conservée en
        // session.
        try {
            utilisateur.getProfil().clear();

            Collection<EpmTRefTypeMarche> listeEpmTRefTypeMarche = referentielsServiceLocal.getAllReferentiels().getRefTypeMarche();
            Set<EpmTTypeMarcheProfil> listeTypeMarcheProfil = new HashSet<EpmTTypeMarcheProfil>();
            for (EpmTRefTypeMarche epmTRefTypeMarche : listeEpmTRefTypeMarche) {
                EpmTTypeMarcheProfil typeMarcheProfileTemporaire = new EpmTTypeMarcheProfil();
                typeMarcheProfileTemporaire.setTypeMarche(epmTRefTypeMarche);
                listeTypeMarcheProfil.add(typeMarcheProfileTemporaire);
            }

            // creation du profil
            EpmTProfil profileTemporaire = new EpmTProfil();
            profileTemporaire.setNom("ProfilTemporaireAccesExterneRedaction");
            Set<EpmTHabilitation> habilitationAssocies = new HashSet<EpmTHabilitation>();
            if (utilisateurExterne.getHabilitations() != null) {
                Collection<EpmTHabilitation> habilitations = generiqueDAO.findAll(EpmTHabilitation.class);

                for (String habilitationInitialisation : utilisateurExterne.getHabilitations().getHabilitation()) {
                    for (EpmTHabilitation habilitation : habilitations) {
                        if (habilitation.getRole().contains(habilitationInitialisation)) {
                            habilitationAssocies.add(habilitation);
                            break;
                        }
                    }
                }
                profileTemporaire.setHabilitationAssocies(habilitationAssocies);
            }

            EpmTProfilUtilisateur profilUtilisateur = new EpmTProfilUtilisateur();
            profilUtilisateur.setProfil(profileTemporaire);
            profilUtilisateur.setTypeMarcheProfilSet(listeTypeMarcheProfil);

            Map<EpmTProfil, EpmTProfilUtilisateur> map = new HashMap<EpmTProfil, EpmTProfilUtilisateur>();
            map.put(profileTemporaire, profilUtilisateur);
            utilisateur.setProfilUtilisateurMap(map);
        } catch (TechnicalNoyauException | NonTrouveNoyauException e) {
            LOG.error(e.getMessage(), e);
        }

        utilExtConsult.setUtilisateur(utilisateur);

        // Association identifiant externe au couple utilisateur externe /
        // consultation et sauvegarde en memoire
        tableStockageEPM.putUtilisateurExterneConsultation(idUtilExtConsult, utilExtConsult);

        return res;
    }

    /**
     * Retourne l'utilisateur externe correspondant a celui indique dans le flux
     * XML en parametre, null si utilisateur inexistant en base.
     */
    private EpmTUtilisateur rechercheUtilisateurExterne(final UtilisateurType utilisateurExterne) {

        Integer idOrganisme = rechercheIdOrganisme(utilisateurExterne.getAcronymeOrganisme());
        UtilisateurCritere utilisateurCritere = new UtilisateurCritere();
        utilisateurCritere.setGuidSso(utilisateurExterne.getIdentifiantExterne());
        utilisateurCritere.setIdOrganisme(idOrganisme);

        try {
            List<EpmTUtilisateur> epmTUtilisateurs = generiqueDAO.findByCritere(utilisateurCritere);
            if (epmTUtilisateurs == null || epmTUtilisateurs.isEmpty() || epmTUtilisateurs.size() > 1)
                throw new TechnicalNoyauException("EpmTUtilisateur " + utilisateurExterne.getNom() + " n'est pas unique");
            return epmTUtilisateurs.get(0);
        } catch (TechnicalNoyauException | ApplicationNoyauException e) {
            LOG.error(e.getMessage(), e.fillInStackTrace());
        }
        return null;
    }

    /**
     * Recherche de l'idOrganisme correspondant au acronyme envoyé par MPE
     * @param acronyme
     * @return l'identifiant de l'organisme
     */
    private Integer rechercheIdOrganisme(String acronyme) {
        // Recherche du idOrganisme
        Integer idOrganisme = null;

        if (acronyme != null && !acronyme.isEmpty()) {
            try {
                OrganismeCritere orgCritere = new OrganismeCritere();
                orgCritere.setAcronyme(acronyme);
                List<EpmTRefOrganisme> listOrganisme = generiqueDAO.findByCritere(orgCritere);
                if (listOrganisme != null && !listOrganisme.isEmpty()) {
                    idOrganisme = listOrganisme.get(0).getId();
                }
            } catch (TechnicalNoyauException e) {
                LOG.error(e.getMessage(), e);
            }
        }
        return idOrganisme;
    }

    public final void setConversionService(final DozerBeanMapper valeur) {
        ConsultationRestWebService.conversionService = valeur;
    }

    public final void setAttributionMarcheService(AttributionMarcheService valeur) {
        ConsultationRestWebService.attributionMarcheService = valeur;
    }

    public final void setInitialisationConsultationWebServiceGIM(final InitialisationConsultationWebServiceGIM valeur) {
        ConsultationRestWebService.initialisationConsultationWebServiceGIM = valeur;
    }

    public final void setGeneriqueDAO(GeneriqueDAO generiqueDAO) {
        ConsultationRestWebService.generiqueDAO = generiqueDAO;
    }

    public final void setReferentielsServiceLocal(ReferentielsServiceLocal referentielsServiceLocal) {
        ConsultationRestWebService.referentielsServiceLocal = referentielsServiceLocal;
    }

    public final void setTableStockageEPM(TableStockageEPM valeur) {
        ConsultationRestWebService.tableStockageEPM = valeur;
    }

    private Integer getIntValueByParametrage(String clef) throws TechnicalNoyauException, ApplicationNoyauException {

        ParametrageCritere paramCritere = new ParametrageCritere();
        paramCritere.setClef(clef);
        EpmTRefParametrage parametrage = generiqueDAO.findUniqueByCritere(paramCritere);

        try {
            return Integer.parseInt(parametrage.getValeur());
        } catch (Exception ex) {
            LOG.error("Impossible de parser la valeur int du parametrage : " + clef);
        }

        return null;
    }

}
