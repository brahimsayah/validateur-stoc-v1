package fr.atexo.rsem.noyau.ws.beans;

import java.util.Date;
import java.util.List;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElementWrapper;

public class ContratSimpleBean {

    /**
     * Le numéro du contrat = reference du marché
     */
    private String numeroContrat;

    private Date dateNotificationMarche;

    /**
     * L'objet du contrat : composé par l'intitulé de la consultation, en cas
     * d'une consultation non alloti. Sinon, dans le cas d'une consultation
     * alloti, ce champ sera composé de l'intitulé de la consultation + intitulé
     * du lot
     */
    private String objetContrat;

    /**
     * Type de contrat : DSP, Accord cadre, Marché
     */
    private String typeContrat;

    /**
     * Le prix consolidé est associé au marché lors de l'attribution
     */
    private ConsolidePrixBean consolidePrix;

    private String intituleLot;

    private List<AttributaireBean> attributaires;

    /**
     * @return the numeroContrat
     */
    public final String getNumeroContrat() {
        return numeroContrat;
    }

    /**
     * @param numeroContrat the numeroContrat to set
     */
    public final void setNumeroContrat(String valeur) {
        this.numeroContrat = valeur;
    }

    /**
     * @return the objetContrat
     */
    public final String getObjetContrat() {
        return objetContrat;
    }

    /**
     * @param objetContrat the objetContrat to set
     */
    public final void setObjetContrat(String valeur) {
        this.objetContrat = valeur;
    }

    /**
     * @return the typeContrat
     */
    public final String getTypeContrat() {
        return typeContrat;
    }

    /**
     * @param typeContrat the typeContrat to set
     */
    public final void setTypeContrat(String valeur) {
        this.typeContrat = valeur;
    }

    /**
     * @return the consolidePrix
     */
    public final ConsolidePrixBean getConsolidePrix() {
        return consolidePrix;
    }

    /**
     * @param consolidePrix the consolidePrix to set
     */
    public final void setConsolidePrix(ConsolidePrixBean valeur) {
        this.consolidePrix = valeur;
    }

    /**
     * @return the intituleLot
     */
    public final String getIntituleLot() {
        return intituleLot;
    }

    /**
     * @param intituleLot the intituleLot to set
     */
    public final void setIntituleLot(String valeur) {
        this.intituleLot = valeur;
    }

    /**
     * @return the attributaire
     */
    @XmlElementWrapper(name = "attributaires")
    @XmlElement(name = "attributaire")
    public final List<AttributaireBean> getAttributaires() {
        return attributaires;
    }

    /**
     * @param attributaire the attributaire to set
     */
    public final void setAttributaires(List<AttributaireBean> valeur) {
        this.attributaires = valeur;
    }

    /**
     * @return the dateNotificationMarche
     */
    public final Date getDateNotificationMarche() {
        return dateNotificationMarche;
    }
    /**
     * @param dateNotificationMarche the dateNotificationMarche to set
     */
    public final void setDateNotificationMarche(Date valeur) {
        this.dateNotificationMarche = valeur;
    }

}
