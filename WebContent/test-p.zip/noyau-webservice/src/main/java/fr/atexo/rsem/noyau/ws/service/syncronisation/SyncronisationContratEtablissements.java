package fr.atexo.rsem.noyau.ws.service.syncronisation;

import com.atexo.execution.common.dto.*;
import fr.paris.epm.noyau.metier.ConsultationCritere;
import fr.paris.epm.noyau.metier.DirectionServiceCritere;
import fr.paris.epm.noyau.metier.EpmTContratCritere;
import fr.paris.epm.noyau.persistance.EpmTAttributaire;
import fr.paris.epm.noyau.persistance.EpmTConsultation;
import fr.paris.epm.noyau.persistance.EpmTContrat;
import fr.paris.epm.noyau.persistance.referentiel.EpmTRefDirectionService;
import fr.paris.epm.noyau.persistance.referentiel.EpmTRefTypeAttributaire;
import fr.paris.epm.noyau.service.AdministrationServiceSecurise;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * Created by dcs on 08/12/16.
 * for Atexo
 */
@Service
public class SyncronisationContratEtablissements {

    /**
     * Loger.
     */
    private static final Logger LOG = LoggerFactory.getLogger(SyncronisationContratEtablissements.class);

    @Autowired
    AdministrationServiceSecurise administrationService;

    public List<ContratEtablissementDTO> getContratJoinAttributaireWithSiretAndAfterDate(long date) {
        List<ContratEtablissementDTO> listEtablissementDTO = new ArrayList<>();

        EpmTContratCritere contratCritere = new EpmTContratCritere();
        contratCritere.setJoinAttributaire(true);
        contratCritere.setDateValidationAPartirDe(new Date(date));

        List<EpmTContrat> listEpmTContrats = administrationService.chercherEpmTObject(0, contratCritere);

        for (EpmTContrat epmTContrat : listEpmTContrats) {

            ConsultationCritere consultationCritere = new ConsultationCritere();
            consultationCritere.setReference(epmTContrat.getNumeroConsultation());
            EpmTConsultation epmTConsultation = (EpmTConsultation) administrationService.chercherUniqueEpmTObject(0, consultationCritere);

            DirectionServiceCritere critere = new DirectionServiceCritere();
            critere.setIdDirectionsService(epmTConsultation.getDirServiceVision());
            EpmTRefDirectionService epmTRefDirectionService = (EpmTRefDirectionService) administrationService.chercherUniqueEpmTObject(0, critere);

            List<EpmTAttributaire> listEpmTAttributaires = new ArrayList<>(epmTContrat.getAttributaires());
            for (EpmTAttributaire epmTAttributaire : listEpmTAttributaires) {
                ContratEtablissementDTO contratEtablissementDTO = new ContratEtablissementDTO();

                contratEtablissementDTO.setMontant(BigDecimal.valueOf(epmTContrat.getMontantAttribueHT()));
                contratEtablissementDTO.setDateModificationExterne(epmTContrat.getDateValidation());

                ContratDTO contratDTO = epmTContratToContratDTO(epmTContrat);
                contratEtablissementDTO.setId(Long.valueOf(epmTAttributaire.getId()));

                Date dateNotification = epmTAttributaire.getDateAR() != null ? epmTAttributaire.getDateAR() : epmTAttributaire.getDateEnvoiRemise();
                contratEtablissementDTO.setDateNotification(dateNotification);
                contratDTO.setDateNotification(dateNotification);
                contratDTO.setDateDemaragePrestation(dateNotification);

                EtablissementDTO etablissementDTO = new EtablissementDTO();
                etablissementDTO.setSiret(epmTAttributaire.getSiret());

                EpmTRefTypeAttributaire epmTRefTypeAttributaire = epmTAttributaire.getTypeAttributaire();
                if (epmTRefTypeAttributaire != null && (epmTRefTypeAttributaire.getId() == 2 || epmTRefTypeAttributaire.getId() == 3))
                    contratEtablissementDTO.setMandataire(true);

                contratDTO.setService(SyncronisationStaticClass.epmTRefDirectionServiceToServiceDto(epmTRefDirectionService));

                ConsultationDTO consultationDTO = epmTConsultationToConsultationDTO(epmTConsultation);
                if (consultationDTO.getNumero() == null)
                    consultationDTO.setNumero(contratDTO.getNumero());

                contratDTO.setCreateur(SyncronisationStaticClass.epmTUtilisateurToUtilisateurDTO(epmTConsultation.getEpmTUtilisateur()));
                contratDTO.setConsultation(consultationDTO);

                contratDTO.setCodeAchat(SyncronisationStaticClass.referentielToValueLabelDTO(epmTConsultation.getEpmTRefCodeAchat()));
                contratDTO.setUniteFonctionnelleOperation(SyncronisationStaticClass.operationUniteToValueLabelDTO(epmTConsultation.getEpmTOperationUniteFonctionnelle()));

                contratEtablissementDTO.setCategorieConsultation(SyncronisationStaticClass.referentielToValueLabelDTO(epmTConsultation.getEpmTRefNature()));

                contratEtablissementDTO.setContrat(contratDTO);
                contratEtablissementDTO.setEtablissement(etablissementDTO);

                listEtablissementDTO.add(contratEtablissementDTO);
            }
        }
        return listEtablissementDTO;
    }

    private ContratDTO epmTContratToContratDTO(EpmTContrat epmTContrat) {
        ContratDTO contratDTO = new ContratDTO();

        contratDTO.setNumero(epmTContrat.getNumeroContrat());
        contratDTO.setReferenceLibre(epmTContrat.getNumeroContrat());
        contratDTO.setObjet(epmTContrat.getObjetContrat());
        contratDTO.setMontant(BigDecimal.valueOf(epmTContrat.getMontantAttribueHT()));
        contratDTO.setChapeau(false);
        contratDTO.setId(Long.valueOf(epmTContrat.getId()));
        contratDTO.setDateFinContrat(epmTContrat.getDateFinMarche());

        ValueLabelDTO typeContrat = new ValueLabelDTO();
        if (epmTContrat.getTypeContrat() != null) {
            typeContrat.setLabel(epmTContrat.getTypeContrat().getLibelle());
            typeContrat.setValue(epmTContrat.getTypeContrat().getCodeExterne());
        }
        contratDTO.setType(typeContrat);

        return contratDTO;
    }

    private ConsultationDTO epmTConsultationToConsultationDTO(EpmTConsultation epmTConsultation) {
        ConsultationDTO consultationDTO = new ConsultationDTO();

        consultationDTO.setIntitule(epmTConsultation.getIntituleConsultation());
        consultationDTO.setObjet(epmTConsultation.getObjet());
        consultationDTO.setNumero(epmTConsultation.getNumeroConsultation());
        consultationDTO.setCategorie(SyncronisationStaticClass.referentielToValueLabelDTO(epmTConsultation.getEpmTRefNature()));
        consultationDTO.setId((long) epmTConsultation.getId());

        return consultationDTO;
    }

}
