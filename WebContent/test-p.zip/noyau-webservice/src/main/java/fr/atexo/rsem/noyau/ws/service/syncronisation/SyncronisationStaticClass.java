package fr.atexo.rsem.noyau.ws.service.syncronisation;

import com.atexo.execution.common.dto.OrganismeDTO;
import com.atexo.execution.common.dto.ServiceDTO;
import com.atexo.execution.common.dto.UtilisateurDTO;
import com.atexo.execution.common.dto.ValueLabelDTO;
import fr.paris.epm.noyau.persistance.EpmTOperationUniteFonctionnelle;
import fr.paris.epm.noyau.persistance.EpmTUtilisateur;
import fr.paris.epm.noyau.persistance.referentiel.EpmTRefDirectionService;
import fr.paris.epm.noyau.persistance.referentiel.EpmTRefOrganisme;
import fr.paris.epm.noyau.persistance.referentiel.Referentiel;

/**
 * Created by dcs on 09/12/16.
 * for Atexo
 */
public abstract class SyncronisationStaticClass {

    static ValueLabelDTO referentielToValueLabelDTO(Referentiel referentiel) {

        if (referentiel == null)
            return null;

        ValueLabelDTO valueLabelDTO = new ValueLabelDTO();

        valueLabelDTO.setLabel(referentiel.getLibelle());
        valueLabelDTO.setValue(String.valueOf(referentiel.getId()));

        return valueLabelDTO;
    }

    static ValueLabelDTO operationUniteToValueLabelDTO(EpmTOperationUniteFonctionnelle epmTOperationUnite) {

        if (epmTOperationUnite == null)
            return null;

        ValueLabelDTO valueLabelDTO = new ValueLabelDTO();

        valueLabelDTO.setLabel(epmTOperationUnite.getLibelle());
        valueLabelDTO.setValue(String.valueOf(epmTOperationUnite.getId()));

        return valueLabelDTO;
    }

    static ServiceDTO epmTRefDirectionServiceToServiceDto(EpmTRefDirectionService epmTRefDirectionService) {

        if (epmTRefDirectionService == null)
            return null;

        ServiceDTO serviceDTO = new ServiceDTO();

        serviceDTO.setNom(epmTRefDirectionService.getNom());
        serviceDTO.setId((long) epmTRefDirectionService.getId());
        serviceDTO.setActif(epmTRefDirectionService.isActifLecture());

        if (epmTRefDirectionService.getTypeEntite() != null)
            serviceDTO.setNiveau(Integer.parseInt(epmTRefDirectionService.getTypeEntite()));

        serviceDTO.setNomCourt(null);
        serviceDTO.setNomCourtArborescence(null);
        serviceDTO.setOrganisme(epmTRefOrganismeToOrganismeDTO(epmTRefDirectionService.getEpmTRefOrganisme()));

        return serviceDTO;
    }

    static OrganismeDTO epmTRefOrganismeToOrganismeDTO(EpmTRefOrganisme epmTRefOrganisme) {

        if (epmTRefOrganisme == null)
            return null;

        OrganismeDTO organismeDTO = new OrganismeDTO();

        organismeDTO.setId((long) epmTRefOrganisme.getId());
        organismeDTO.setNom(epmTRefOrganisme.getLibelle());
        organismeDTO.setAcronyme(epmTRefOrganisme.getAcronyme());

        return organismeDTO;
    }

    static UtilisateurDTO epmTUtilisateurToUtilisateurDTO(EpmTUtilisateur epmTUtilisateur) {

        if (epmTUtilisateur == null)
            return null;

        UtilisateurDTO utilisateurDTO = new UtilisateurDTO();

        utilisateurDTO.setEmail(epmTUtilisateur.getCourriel());
        utilisateurDTO.setIdentifiant(epmTUtilisateur.getIdentifiant());
        utilisateurDTO.setId((long) epmTUtilisateur.getId());
        utilisateurDTO.setNom(epmTUtilisateur.getNom());
        utilisateurDTO.setPrenom(epmTUtilisateur.getPrenom());
        utilisateurDTO.setService(epmTRefDirectionServiceToServiceDto(epmTUtilisateur.getService()));
        utilisateurDTO.setActif(epmTUtilisateur.getActif());

        return utilisateurDTO;
    }

}
