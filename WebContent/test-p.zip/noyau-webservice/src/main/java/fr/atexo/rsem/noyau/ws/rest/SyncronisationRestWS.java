package fr.atexo.rsem.noyau.ws.rest;

import com.atexo.execution.common.dto.*;
import fr.atexo.rsem.noyau.ws.beans.ErreurBean;
import fr.atexo.rsem.noyau.ws.service.syncronisation.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import javax.xml.bind.JAXBElement;
import java.util.List;

/**
 * Created by dcs on 29/11/16.
 * for Atexo
 */
@Controller
public class SyncronisationRestWS {

    private static final Logger LOG = LoggerFactory.getLogger(SyncronisationRestWS.class);

    @Autowired
    private SyncronisationUtilisateur syncronisationExecUtilisateur;

    @Autowired
    private SyncronisationServices syncronisationExecServices;

    @Autowired
    private SyncronisationFournisseurs syncronisationExecFournisseurs;

    @Autowired
    private SyncronisationEtablissements syncronisationExecEtablissements;

    @Autowired
    private SyncronisationContratEtablissements syncronisationExecContratEtablissements;

    /**
     * Syncronise les utilisateur avec execution.
     *
     * @return un Json avec l'ensemble des utilisateur.
     * @author DCS
     */
    @RequestMapping(value = {"/syncronisationExecution/utilisateur/{token}"}, method = RequestMethod.GET)
    public ResponseEntity<List<UtilisateurDTO>> syncronisationUtilisateurExecution(@PathVariable("token") String token) {
        AuthentificationRestWebService auth = new AuthentificationRestWebService();
        JAXBElement<ErreurBean> errorToken = auth.verificationToken(token);
        if (errorToken.getValue().getMessage() == null || errorToken.getValue().getMessage().isEmpty()) {
            List<UtilisateurDTO> liste = syncronisationExecUtilisateur.getAllUtilisateur();
            return new ResponseEntity<>(liste, HttpStatus.OK);
        }
        return new ResponseEntity<>(HttpStatus.FORBIDDEN);
    }

    /**
     * Syncronise les Services
     *
     * @return un Json avec l'ensemble des services.
     * @author DCS
     */
    @RequestMapping(value = {"/syncronisationExecution/service/{token}"}, method = RequestMethod.GET)
    public ResponseEntity<List<ServiceDTO>> syncronisationServiceExecution(@PathVariable("token") String token) {
        AuthentificationRestWebService auth = new AuthentificationRestWebService();
        JAXBElement<ErreurBean> errorToken = auth.verificationToken(token);
        if (errorToken.getValue().getMessage() == null || errorToken.getValue().getMessage().isEmpty()) {
            List<ServiceDTO> liste = syncronisationExecServices.getAllServices();
            return new ResponseEntity<>(liste, HttpStatus.OK);
        }
        return new ResponseEntity<>(HttpStatus.FORBIDDEN);
    }

    /**
     * Syncronise les fournisseurs
     *
     * @return un Json avec l'ensemble des fourniseurs
     * @author DCS
     */
    @RequestMapping(value = {"/syncronisationExecution/fournisseurs/{date}/{token}"}, method = RequestMethod.GET)
    public ResponseEntity<List<FournisseurDTO>> syncronisationFournisseursExecution(@PathVariable("date") long date, @PathVariable("token") String token) {
        AuthentificationRestWebService auth = new AuthentificationRestWebService();
        JAXBElement<ErreurBean> errorToken = auth.verificationToken(token);
        if (errorToken.getValue().getMessage() == null || errorToken.getValue().getMessage().isEmpty()) {
            List<FournisseurDTO> liste = syncronisationExecFournisseurs.getFournisseursAfterDate(date);
            return new ResponseEntity<>(liste, HttpStatus.OK);
        }
        return new ResponseEntity<>(HttpStatus.FORBIDDEN);
    }

    /**
     * Syncronise les etablissements
     *
     * @return un Json avec l'ensemble des etablissements
     * @author DCS
     */
    @RequestMapping(value = {"/syncronisationExecution/etablissements/{date}/{token}"}, method = RequestMethod.GET)
    public ResponseEntity<List<EtablissementDTO>> syncronisationEtablissementsExecution(@PathVariable("date") long date, @PathVariable("token") String token) {
        AuthentificationRestWebService auth = new AuthentificationRestWebService();
        JAXBElement<ErreurBean> errorToken = auth.verificationToken(token);
        if (errorToken.getValue().getMessage() == null || errorToken.getValue().getMessage().isEmpty()) {
            List<EtablissementDTO> liste = syncronisationExecEtablissements.getEtablissementWithSiretAndAfterDate(date);
            return new ResponseEntity<>(liste, HttpStatus.OK);
        }
        return new ResponseEntity<>(HttpStatus.FORBIDDEN);
    }

    /**
     * Syncronise Contrat Etablissement
     *
     * @return un Json avec l'ensemble des Contrat Etablissement
     * @author DCS
     */
    @RequestMapping(value = {"/syncronisationExecution/contrat/etablissements/{date}/{token}"}, method = RequestMethod.GET)
    public ResponseEntity<List<ContratEtablissementDTO>> syncronisationContratEtablissementsExecution(@PathVariable("date") long date, @PathVariable("token") String token) {
        AuthentificationRestWebService auth = new AuthentificationRestWebService();
        JAXBElement<ErreurBean> errorToken = auth.verificationToken(token);
        if (errorToken.getValue().getMessage() == null || errorToken.getValue().getMessage().isEmpty()) {
            List<ContratEtablissementDTO> liste = syncronisationExecContratEtablissements.getContratJoinAttributaireWithSiretAndAfterDate(date);
            return new ResponseEntity<>(liste, HttpStatus.OK);
        }
        return new ResponseEntity<>(HttpStatus.FORBIDDEN);
    }

    /*
    *//**
     * Syncronise les types de contrat
     * @author DCS
     * @return un Json avec l'ensemble des Types de contrat
     *//*
    @RequestMapping(value = {"/syncronisationExecution/reference/typeDeContrat/{token}"}, method = RequestMethod.GET)
    public ResponseEntity<List<ValueLabelDTO>> syncronisationTypeContratExecution(
            @PathVariable("token") String token) {
        AuthentificationRestWebService auth = new AuthentificationRestWebService();
        JAXBElement<ErreurBean> errorToken = auth.verificationToken(token);
        if (StringUtils.isEmpty(errorToken.getValue().getMessage())) {
            List<ValueLabelDTO> liste;
            liste = syncronisationExecTypeContrat.getTypeContratExec();
            return new ResponseEntity<>(liste, HttpStatus.OK);
        }
        return new ResponseEntity<>(HttpStatus.FORBIDDEN);
    }

    *//**
     * Syncronise les catégorie consultation
     * @author DCS
     * @return un Json avec l'ensemble des catégorie de consultation
     *//*
    @RequestMapping(value = {"/syncronisationExecution/reference/categorieConsultation/{token}"}, method = RequestMethod.GET)
    public ResponseEntity<List<ValueLabelDTO>> syncronisationCategorieConsultationExecution(
            @PathVariable("token") String token) {
        AuthentificationRestWebService auth = new AuthentificationRestWebService();
        JAXBElement<ErreurBean> errorToken = auth.verificationToken(token);
        if (StringUtils.isEmpty(errorToken.getValue().getMessage())) {
            List<ValueLabelDTO> liste;
            liste = syncronisationExecCategorieConsultation.getCategorieConsultationExec();
            return new ResponseEntity<>(liste, HttpStatus.OK);
        }
        return new ResponseEntity<>(HttpStatus.FORBIDDEN);
    }
*/

}