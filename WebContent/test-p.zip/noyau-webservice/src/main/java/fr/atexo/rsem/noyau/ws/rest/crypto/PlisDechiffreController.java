package fr.atexo.rsem.noyau.ws.rest.crypto;

import fr.atexo.rsem.noyau.ws.beans.ErreurBean;
import fr.atexo.rsem.noyau.ws.rest.AuthentificationRestWebService;
import fr.paris.epm.noyau.commun.exception.NonTrouveNoyauException;
import fr.paris.epm.noyau.commun.exception.TechnicalNoyauException;
import fr.paris.epm.noyau.metier.ConsultationGIM;
import fr.paris.epm.noyau.metier.PlisCritere;
import fr.paris.epm.noyau.metier.ServiceTechniqueGIM;
import fr.paris.epm.noyau.persistance.EpmTDocument;
import fr.paris.epm.noyau.persistance.EpmTFichierSurDisque;
import fr.paris.epm.noyau.persistance.EpmTPlisGenerique;
import fr.paris.epm.noyau.service.CryptoService;
import fr.paris.epm.noyau.service.GeneriqueServiceSecurise;
import fr.paris.epm.noyau.service.technique.ServiceTechniqueSecurise;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

import javax.xml.bind.JAXBElement;
import java.io.File;
import java.io.IOException;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

/**
 * Created by ael on 16/03/17.
 */
// The Java class will be hosted at the URI path "/blocPlis"
@Controller
//@Api(value = "plisDechiffre", description = "Ce WebService enregistre un plis déchiffré", consumes = "application/json")
public class PlisDechiffreController {

    private static final Logger LOG = LoggerFactory.getLogger(PlisDechiffreController.class);

    @Autowired
    private ConsultationGIM consultationGIM;

    @Autowired
    private ServiceTechniqueGIM serviceTechniqueGIM;

    @Autowired
    private GeneriqueServiceSecurise depotService ;

    @Autowired
    private ServiceTechniqueSecurise serviceTechnique;

    @Autowired
    private CryptoService cryptoService;

    @RequestMapping(value = "/plisDechiffre/{idPlisMpe}/{token}", method= RequestMethod.POST)
    public ResponseEntity<String> enregistrerFichier(@RequestParam("file") MultipartFile file, @PathVariable int idPlisMpe,
                                                     @PathVariable("token") String token) {

        LOG.info("/plisDechiffre/" + idPlisMpe + "/" + token);

        AuthentificationRestWebService auth = new AuthentificationRestWebService();
        JAXBElement<ErreurBean> errorToken = auth.verificationToken(token);
        if (!StringUtils.isEmpty(errorToken.getValue().getMessage()))
            return erreurAuthentification();

        try {

            //on recupére le pli concerné
            EpmTPlisGenerique plis =recupererPliGenereique(idPlisMpe);

            LOG.info("Debut de l'enregistrement du plis dechiffré {idRegistreDemat}" + idPlisMpe);

            //on construit un document en le liant avec le plis déchiffré reçu
            EpmTDocument document = construireDocument(plis.getConsultation(), multipartToFile(file));

            //on enregistre le document construit
            document = (EpmTDocument) serviceTechniqueGIM.modifier(document);

            //on valide les modification du plis sur la base de données
            plis.setPlisDechiffre(document);
            plis.setSignatureValide(cryptoService.verificationSignature(plis) && "0-0-0".equals(plis.getVerificationCertificat()));

            consultationGIM.modifier(plis);

            LOG.info("Fin de l'enregistrement du plis dechiffré {idRegistreDemat}" + idPlisMpe);

            return new ResponseEntity<String>("Enregistrement pli déchiffré bien effectué", HttpStatus.OK);

        } catch (TechnicalNoyauException e) {
            // en cas d'erreur technique
            LOG.error("Erreur lors de l'enregistreemnt du plis déchiffré", e.getMessage(), e.fillInStackTrace());
            return new ResponseEntity<String>("Erreur technique", HttpStatus.INTERNAL_SERVER_ERROR);
        } catch (NonTrouveNoyauException e) {
            // en cas de non réponse du serveur noyau
            LOG.error("Erreur lors de l'enregistreemnt du plis déchiffré", e.getMessage(), e.fillInStackTrace());
            return new ResponseEntity<String>("Erreur Noyau", HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    private ResponseEntity<String> erreurAuthentification() {
        // en cas d'un jeton authentification invalide on retourne un message d'erreur d'authentification avec le statut not accepted
        LOG.error( "Accés non autorisé : " + this.getClass().getName() + " : " + getLineNumber());
        return new ResponseEntity<String>("Accés non autorisé ", HttpStatus.UNAUTHORIZED);
    }

    private static int getLineNumber() {
        return Thread.currentThread().getStackTrace()[2].getLineNumber();
    }

    private EpmTPlisGenerique recupererPliGenereique(int idPlisMpe ) throws TechnicalNoyauException {
        EpmTPlisGenerique epmTPli = null;

        PlisCritere plisCritere = new PlisCritere();
        plisCritere.setIdRegistreDemat(idPlisMpe);
        List<EpmTPlisGenerique> plisList = depotService.chercherEpmTObject(0, plisCritere);
        if (!plisList.isEmpty())
            epmTPli = plisList.get(0);

        if (epmTPli==null)
            throw new TechnicalNoyauException(idPlisMpe + " : " + "Plis non trouvé !");

        return epmTPli;
    }


    private File multipartToFile(MultipartFile multipart) {
        File convFile = null;
        try {
            convFile = new File( multipart.getOriginalFilename());
            multipart.transferTo(convFile);
        } catch (IOException e) {
            //gérer l'exception;
            e.printStackTrace();
        }
        return convFile;
    }

    private EpmTDocument construireDocument(int idConsultation, File file) throws TechnicalNoyauException {
        String nomFichier = file.getName();

        EpmTDocument document = new EpmTDocument();

        Date d = new Date();
        document.setReference(String.valueOf(d.getTime()));
        document.setTitre(nomFichier);

        if (nomFichier.isEmpty())
            nomFichier = "FICHIER_EN_ERREUR_" + Calendar.getInstance().getTimeInMillis();

        document.setNomFichier(nomFichier);
        document.setTypeDocument(EpmTDocument.TYPE_PLI_DECHIFFRE);
        document.setStatut("");
        document.setIdConsultation(idConsultation);
        EpmTFichierSurDisque fichierSurDique = serviceTechniqueGIM.sauvegarderFichier(file.getName(), file);

        int idFichierSauvegarde = fichierSurDique.getId();

        EpmTFichierSurDisque fichierSurDisque = serviceTechnique.chercherFichierSurDisque(idFichierSauvegarde);
        if (fichierSurDisque == null)
            throw new TechnicalNoyauException(idConsultation + " : " + "pli dechiffre non enregistre. FichierSurDisque est null ");

        document.setFichierSurDisque(fichierSurDisque);

        return document;
    }

}