package fr.atexo.rsem.noyau.ws.beans;

/**
 * Bean répresentant les informations du lot technique d'une consultation. Ce
 * bean est utilisé par le Webservice REST pour échanges des données du contrat
 * d'EPM avec des applications tiers
 * 
 * @author Rebeca Dantas
 * 
 */
public class LotTechniqueBean {

	private String identifiantLot;
	
	private String intituleLot;
	
	private boolean lotPrincipal;

	/**
	 * @return the identifiantLot
	 */
	public final String getIdentifiantLot() {
		return identifiantLot;
	}

	/**
	 * @param identifiantLot the identifiantLot to set
	 */
	public final void setIdentifiantLot(String valeur) {
		this.identifiantLot = valeur;
	}

	/**
	 * @return the intituleLot
	 */
	public final String getIntituleLot() {
		return intituleLot;
	}

	/**
	 * @param intituleLot the intituleLot to set
	 */
	public final void setIntituleLot(String valeur) {
		this.intituleLot = valeur;
	}

	/**
	 * @return the lotPrincipal
	 */
	public final boolean isLotPrincipal() {
		return lotPrincipal;
	}

	/**
	 * @param lotPrincipal the lotPrincipal to set
	 */
	public final void setLotPrincipal(boolean valeur) {
		this.lotPrincipal = valeur;
	}
	
}
