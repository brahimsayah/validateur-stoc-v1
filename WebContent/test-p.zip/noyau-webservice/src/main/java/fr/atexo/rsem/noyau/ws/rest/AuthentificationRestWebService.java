package fr.atexo.rsem.noyau.ws.rest;

import fr.atexo.rsem.noyau.ws.beans.ErreurBean;
import fr.atexo.rsem.noyau.ws.rest.constantes.ConstantesRestWebService;
import fr.atexo.rsem.noyau.ws.rest.constantes.ConstantesRestWebService.ErreurEnum;
import fr.paris.epm.noyau.commun.exception.ApplicationNoyauException;
import fr.paris.epm.noyau.commun.exception.TechnicalNoyauException;
import fr.paris.epm.noyau.metier.*;
import fr.paris.epm.noyau.persistance.EpmTAuthentificationToken;
import fr.paris.epm.noyau.persistance.EpmTUtilisateur;
import fr.paris.epm.noyau.persistance.referentiel.EpmTRefParametrage;
import org.apache.commons.codec.binary.Base64;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;
import javax.xml.bind.JAXBElement;
import javax.xml.namespace.QName;
import java.util.Date;
import java.util.List;
import java.util.UUID;
import java.util.concurrent.TimeUnit;

/**
 * Web Service REST d'authentification.
 *
 * @author RVI
 * @version $Revision$, $Date$, $Author$
 */
@Path("/authentification")
public class AuthentificationRestWebService {
    /**
     * Loger.
     */
    private static final Logger LOG = LoggerFactory.getLogger(AuthentificationRestWebService.class);

    /**
     * Délai d'inactivité max, au delà un nouveau ticket est créé
     */
    private static long delaiInactiviteMax;

    /**
     * clé login technique
     */
    private static String cleLoginTechnique;

    /**
     * clé Mot de passe technique
     */
    private static String cleMotDePasseTechnique;

    /**
     * référentiel GIM
     */
    private static GeneriqueDAO generiqueDAO;

    /**
     * AuthentificationTokenProvider
     *
     * @param utilisateur correspond au parametrage login utlisateur technique
     * @param motDePasse  correspond au parametrage mot de passe utlisateur technique
     * @return un token a reutiliser en parametre des autres appels REST
     * (http://...?token=...).
     */
    @GET
    @Path("/connexion/{utilisateur}/{motDePasse}")
    @Produces(MediaType.APPLICATION_XML)
    public JAXBElement<? extends Object> connexion(@PathParam("utilisateur") String utilisateur, @PathParam("motDePasse") String motDePasse) {

        UtilisateurCritere critere = new UtilisateurCritere();
        critere.setGuidSso(utilisateur);

        JAXBElement<String> res = new JAXBElement<String>(new QName(ConstantesRestWebService.XML_QNAME_TOKEN), String.class, null);
        JAXBElement<ErreurBean> resError = new JAXBElement<ErreurBean>(new QName(ConstantesRestWebService.XML_QNAME_ERREUR), ErreurBean.class, new ErreurBean());
        EpmTRefParametrage loginTechnique = null;
        boolean utilisateurTechniqueAuthentifie = false;

        if (cleLoginTechnique!= null) {
            try {
                loginTechnique = chercherParametre(cleLoginTechnique);
            } catch (TechnicalNoyauException e1) {
                resError.getValue().setCodeMessage(ErreurEnum.TECHNIQUE_BASE_DE_DONNEES, "Probleme lors de la recherche du parametrage du login utilisateur technique");
                LOG.error(resError.getValue().toString(), e1);
                return resError;
            } catch (ApplicationNoyauException e1) {
                resError.getValue().setCodeMessage(ErreurEnum.AUTRE, "Probleme lors de la recherche du parametrage du login utilisateur technique");
                LOG.error(resError.getValue().toString(), e1);
                return resError;
            }

            EpmTRefParametrage motDePasseTechnique = null;
            try {
                motDePasseTechnique = chercherParametre(cleMotDePasseTechnique);
            } catch (TechnicalNoyauException e1) {
                resError.getValue().setCodeMessage(ErreurEnum.TECHNIQUE_BASE_DE_DONNEES, "Probleme lors de la recherche du parametrage du mot de Passe utilisateur technique :");
                LOG.error(resError.getValue().toString(), e1);
                return resError;
            } catch (ApplicationNoyauException e1) {
                resError.getValue().setCodeMessage(ErreurEnum.AUTRE, "Probleme lors de la recherche du parametrage du mot de passe utilisateur technique :");
                LOG.error(resError.getValue().toString(), e1);
                return resError;
            }
            if (motDePasseTechnique != null && motDePasseTechnique.getValeur() != null && loginTechnique != null && loginTechnique.getValeur() != null && motDePasseTechnique.getValeur().equals(motDePasse)
                    && loginTechnique.getValeur().equals(utilisateur)) {
                utilisateurTechniqueAuthentifie = true;
            }
        }

        if (!utilisateurTechniqueAuthentifie) {
            EpmTUtilisateur utilissateurBdd = null;
            List<EpmTUtilisateur> utilisateurBddList = null;
            try {
                utilisateurBddList = generiqueDAO.findByCritere(critere);
            } catch (TechnicalNoyauException e) {
                resError.getValue().setCodeMessage(ErreurEnum.TECHNIQUE_BASE_DE_DONNEES, "Probleme lors de la recherche de l'utilisateur " + utilisateur);
                LOG.error(resError.getValue().toString(), e);
                return resError;
            }
            if ((utilisateurBddList == null) || (utilisateurBddList.isEmpty())) {
                resError.getValue().setCodeMessage(ErreurEnum.ENTITE_NON_TROUVEE, "Utilisateur " + utilisateur + " inexistant.");
                LOG.error(resError.getValue().toString());
                return resError;
            }
            utilissateurBdd = utilisateurBddList.get(0);

            if (!motDePasse.equals(utilissateurBdd.getMotDePasse())) {
                resError.getValue().setCodeMessage(ErreurEnum.AUTHENTIFICATION, "Mot de passe de l'utilisateur " + utilisateur + " incorrect.");
                LOG.warn(resError.getValue().toString());
                return resError;
            }
        }

        try {
            EpmTAuthentificationToken tokenBdd = processAuthentication(utilisateur);
            res.setValue(tokenBdd.getSignature());
            return res;
        } catch (TechnicalNoyauException e) {
            resError.getValue().setCodeMessage(ErreurEnum.TECHNIQUE_BASE_DE_DONNEES, "Probleme lors de la recherche de du token de l'utilisateur " + utilisateur);
            LOG.error(resError.getValue().toString(), e);
            return resError;
        }

    }

    private EpmTAuthentificationToken processAuthentication(String utilisateur) {
        EpmTAuthentificationToken tokenBdd;
        AuthentificationTokenCritere authCritere = new AuthentificationTokenCritere();
        authCritere.setIdentifiant(utilisateur);
        List<EpmTAuthentificationToken> tokenBddList = generiqueDAO.findByCritere(authCritere);
        if ((tokenBddList != null) && (!tokenBddList.isEmpty())) {
            tokenBdd = tokenBddList.get(0);
            long dureeInactivite = new Date().getTime() - tokenBdd.getDateDerniereActivite().getTime();
            if (TimeUnit.MILLISECONDS.toMinutes(dureeInactivite) >= delaiInactiviteMax) {
                //tokenBdd.setDateDerniereActivite(new Date()); --> Mise à jour via RememberMeFilter.java
                generiqueDAO.merge(tokenBdd);
                return tokenBdd;
            }
        }
        //Création d'un nouveau ticket
        tokenBdd = new EpmTAuthentificationToken();
        tokenBdd.setDateDerniereActivite(new Date());
        tokenBdd.setIdentifiant(utilisateur);
        tokenBdd.setSignature(signature());

        return generiqueDAO.merge(tokenBdd);
    }

    /**
     * Permet la vérification du token afin de savoir si il est toujours valide
     *
     * @param token
     * @return
     */
    public static JAXBElement<ErreurBean> verificationToken(String token) {
        JAXBElement<ErreurBean> resError = new JAXBElement<ErreurBean>(new QName(ConstantesRestWebService.XML_QNAME_ERREUR), ErreurBean.class, new ErreurBean());
        if (token == null || token.isEmpty()) {
            resError.getValue().setCodeMessage(ErreurEnum.AUTHENTIFICATION, "Le token non fourni ou vide ");
            LOG.error(resError.getValue().toString());
            return resError;
        }
        AuthentificationTokenCritere tokenCritere = new AuthentificationTokenCritere();
        tokenCritere.setSignature(token);

        List<EpmTAuthentificationToken> tokenBddList = null;
        try {
            tokenBddList = generiqueDAO.findByCritere(tokenCritere);
        } catch (TechnicalNoyauException e) {
            resError.getValue().setCodeMessage(ErreurEnum.TECHNIQUE_BASE_DE_DONNEES, "Probleme lors de la recherche du token " + token);
            LOG.error(resError.getValue().toString());
            return resError;
        }
        if ((tokenBddList == null) || tokenBddList.isEmpty()) {
            resError.getValue().setCodeMessage(ErreurEnum.ENTITE_NON_TROUVEE, "Token " + token + " absent en base.");
            LOG.error(resError.getValue().toString());
            return resError;
        }
        if (tokenBddList.size() > 1) {
            LOG.warn("Plus d'un token REST present en base (suppression de tous).");
        }

        return resError;
    }

    /**
     * Supprime le token utiliser pour l'authentification Web Service.
     *
     * @param token fournit en parametre de l'url
     * @return balise deconnexion si ok, balise erreur sinon
     */
    @GET
    @Path("/deconnexion")
    @Produces(MediaType.APPLICATION_XML)
    public JAXBElement<? extends Object> deconnexion(@QueryParam(ConstantesRestWebService.XML_QNAME_TOKEN) String token) {

        JAXBElement<String> res = new JAXBElement<String>(new QName(ConstantesRestWebService.XML_QNAME_DECONNEXION), String.class, "OK");
        JAXBElement<ErreurBean> resError = new JAXBElement<ErreurBean>(new QName(ConstantesRestWebService.XML_QNAME_ERREUR), ErreurBean.class, new ErreurBean());

        AuthentificationTokenCritere tokenCritere = new AuthentificationTokenCritere();
        tokenCritere.setSignature(token);

        List<EpmTAuthentificationToken> tokenBddList = null;
        try {
            tokenBddList = generiqueDAO.findByCritere(tokenCritere);
        } catch (TechnicalNoyauException e) {
            resError.getValue().setCodeMessage(ErreurEnum.TECHNIQUE_BASE_DE_DONNEES, "Probleme lors de la recherche du token " + token);
            LOG.error(resError.getValue().toString());
            return resError;
        }
        if ((tokenBddList == null) || tokenBddList.isEmpty()) {
            resError.getValue().setCodeMessage(ErreurEnum.ENTITE_NON_TROUVEE, "Token " + token + " absent en base.");
            LOG.error(resError.getValue().toString());
            return resError;
        }
        if (tokenBddList.size() > 1) {
            LOG.warn("Plus d'un token REST present en base (suppression de tous).");
        }
        try {
            generiqueDAO.delete(tokenBddList);
        } catch (TechnicalNoyauException e) {
            resError.getValue().setCodeMessage(ErreurEnum.TECHNIQUE_BASE_DE_DONNEES, "Probleme lors de la suppression du token " + token + " en base.");
            LOG.error(resError.getValue().toString());
            return resError;
        }

        return res;
    }

    @GET
    @Path("/test")
    @Produces(MediaType.APPLICATION_XML)
    public JAXBElement<String> test() {
        return new JAXBElement<String>(new QName("test"), String.class, "OK");
    }

    /**
     * Retourne une chaine ascii aleatoire.
     */
    public static String signature() {
        String signature = UUID.randomUUID().toString();
        String signatureEncodee = new String(Base64.encodeBase64URLSafe(signature.getBytes()));
        return signatureEncodee;
    }

    /**
     * chercher un parametre depuis epmtREFParametre cette methode est utilisé
     * pour chercher le login et le mot de passe techeniques
     *
     * @param clef
     * @return
     * @throws ApplicationNoyauException
     * @throws TechnicalNoyauException
     */
    private EpmTRefParametrage chercherParametre(String clef) {
        ParametrageCritere paramCritere = new ParametrageCritere();
        paramCritere.setClef(clef);
        return (EpmTRefParametrage) generiqueDAO.findUniqueByCritere(paramCritere);
    }

    /**
     * @param delaiInactiviteMax the delaiInactiviteMax to set
     */
    public final void setDelaiInactiviteMax(final long delaiInactiviteMax) {
        AuthentificationRestWebService.delaiInactiviteMax = delaiInactiviteMax;
    }

    /**
     * @param cleLoginTechnique the cleLoginTechnique to set
     */
    public final void setCleLoginTechnique(String cleLoginTechnique) {
        AuthentificationRestWebService.cleLoginTechnique = cleLoginTechnique;
    }

    /**
     * @param cleMotDePasseTechnique the cleMotDePasseTechnique to set
     */
    public final void setCleMotDePasseTechnique(String cleMotDePasseTechnique) {
        AuthentificationRestWebService.cleMotDePasseTechnique = cleMotDePasseTechnique;
    }

    /**
     * @param generiqueDAO the generiqueDAO to set
     */
    public final void setGeneriqueDAO(GeneriqueDAO generiqueDAO) {
        AuthentificationRestWebService.generiqueDAO = generiqueDAO;
    }

}
