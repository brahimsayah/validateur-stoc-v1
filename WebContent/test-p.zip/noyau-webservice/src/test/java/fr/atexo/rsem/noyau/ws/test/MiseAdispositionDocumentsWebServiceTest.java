package fr.atexo.rsem.noyau.ws.test;

import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.URI;
import java.util.ArrayList;
import java.util.List;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

import javax.ws.rs.core.UriBuilder;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Unmarshaller;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.sun.jersey.api.client.Client;
import com.sun.jersey.api.client.ClientResponse;
import com.sun.jersey.api.client.WebResource;
import com.sun.jersey.api.client.config.ClientConfig;
import com.sun.jersey.api.client.config.DefaultClientConfig;

import fr.atexo.rsem.noyau.ws.beans.miseADisposition.DocumentMiseAdispositionBean;
import fr.atexo.rsem.noyau.ws.beans.miseADisposition.ListDocumentsMiseAdispositionBean;


public class MiseAdispositionDocumentsWebServiceTest {
    

    private static final String CLIENTID = "2013109xga";
    private static final String URL_MISE_A_DISPOSITION = "miseAdisposition/archive";
    private static final String BASEURI = "http://localhost:8080/epm.noyau";
    WebResource service =null;
    Logger logger=LoggerFactory.getLogger(MiseAdispositionDocumentsWebServiceTest.class);
    @Test
    public void testMiseAdisposition() {
      //obtenir le zipfile
        ClientResponse response= service.path("rest").path(URL_MISE_A_DISPOSITION).path(CLIENTID).get(ClientResponse.class);
        InputStream inputstream=response.getEntityInputStream();
        unzip(service);
       
        
        
       
    }

    @Test
    public void testServiceAquitementDeLaMiseAdisposition() {
       // fail("Not yet implemented");
//        List<String> listUnderTest=new ArrayList<String>();
//        listUnderTest.add("value1");
//        listUnderTest.add("value2");
//        listUnderTest.add("value3");
//        List<String> expectedList=new ArrayList<String>();
//        expectedList.add("value1");
//        expectedList.add("value3");
//        expectedList.add("value2");
//        Assert.assertThat(listUnderTest, 
//                IsIterableContainingInOrder.contains(expectedList.toArray()));
    }
    @Test
    public void testIdentifiant() {
        ClientResponse response= service.path("rest").path(URL_MISE_A_DISPOSITION).get(ClientResponse.class);
        //tester si l'identifiant est correct
        Assert.assertFalse(response==null);
    }
    
    
    
    
    @Before
    public void configureWebServices(){
        ClientConfig config = new DefaultClientConfig();
        Client client = Client.create(config);
        service = client.resource(getBaseURI());
       }

    @Ignore
    private URI getBaseURI() {
     return UriBuilder.fromUri(BASEURI).build();
    }
    
    @Ignore
    private static void unzip(WebResource service) {
        ClientResponse response= service.path("rest").path(URL_MISE_A_DISPOSITION).get(ClientResponse.class);
        InputStream inputstream=response.getEntityInputStream();
        ListDocumentsMiseAdispositionBean listDocumentForContratBean=null;
        List<String> nomFichierZipList= new  ArrayList<String>();
        try {
            
            //out = new FileOutputStream(File.createTempFile("testZip", "zip"));
            ZipInputStream zipinputStream= new ZipInputStream(inputstream);
            ZipEntry zipEntry =null;
            File xmlFile=null;
            while (( zipEntry=zipinputStream.getNextEntry())!=null){
                System.out.println(zipEntry.getName());
                nomFichierZipList.add(zipEntry.getName());
             if (zipEntry.getName().endsWith("_ListDocuments.xml"))
             {
            // byte[] xmlFilebyte= zipEntry.getExtra();
                 xmlFile=File.createTempFile("ListDocuments", ".xml");
                        OutputStream fos = new BufferedOutputStream(
                            new FileOutputStream(xmlFile));
                    try {
                        try {
                            final byte[] buf = new byte[8192];
                            int bytesRead;
                            while (-1 != (bytesRead = zipinputStream.read(buf)))
                                fos.write(buf, 0, bytesRead);
                        }
                        finally {
                            fos.close();
                        }
                    }
                    catch (final IOException ioe) {
                        //f.delete();
                        throw ioe;
                    }
             listDocumentForContratBean=parse(new FileInputStream(xmlFile),ListDocumentsMiseAdispositionBean.class);
             }
            }
           
            zipinputStream.close();
            boolean there=true;
            
            for (DocumentMiseAdispositionBean element:listDocumentForContratBean.getDocumentsList())
            {
               if (! nomFichierZipList.contains(element.getNomDeFichier())){
                   there=false;
               }
             }
             assertTrue(there);
           } catch ( Exception e) {
            fail("exception "+e.getMessage());
        }
    }
    @Ignore
    private static <T> T parse(InputStream input, Class<T> _class) throws JAXBException {
        Unmarshaller unmarshaller = JAXBContext.newInstance(_class).createUnmarshaller();
        return _class.cast(unmarshaller.unmarshal(input));
    }

}
