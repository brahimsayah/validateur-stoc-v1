package fr.atexo.rsem.noyau.ws.test;

public interface WebServiceTests {

}
