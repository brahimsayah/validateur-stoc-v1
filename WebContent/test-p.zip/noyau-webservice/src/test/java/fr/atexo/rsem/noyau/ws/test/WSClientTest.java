package fr.atexo.rsem.noyau.ws.test;

import java.io.StringWriter;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Pattern;

import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.UriBuilder;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBElement;
import javax.xml.bind.JAXBException;
import javax.xml.namespace.QName;

import junit.framework.Assert;

import org.junit.BeforeClass;
import org.junit.Ignore;
import org.junit.Test;

import com.sun.jersey.api.client.Client;
import com.sun.jersey.api.client.GenericType;
import com.sun.jersey.api.client.WebResource;
import com.sun.jersey.api.client.config.ClientConfig;
import com.sun.jersey.api.client.config.DefaultClientConfig;

import fr.atexo.rsem.noyau.ws.beans.AvenantBean;
import fr.atexo.rsem.noyau.ws.beans.ConsultationBean;
import fr.atexo.rsem.noyau.ws.beans.ResponseBean;
import fr.atexo.rsem.noyau.ws.rest.constantes.ConstantesRestWebService;


public class WSClientTest {

	private static String urlAuthentification = "http://rsem-integ/epm.noyau/rest/authentification/connexion/RDA/RDA";
	private static String urlMarches = "http://rsem-integ/epm.noyau/";
	private static Client client;
	private static String date="24102012";
	
	@BeforeClass
	public static void initialiser() {
		// Creation du client
		ClientConfig clientConfig = new DefaultClientConfig();
		client = Client.create(clientConfig);
	}
	
	@Ignore
	public void connexion() {
		WebResource resource = client.resource(UriBuilder.fromUri(urlAuthentification).build());
		Assert.assertNotNull(resource);
		
		GenericType<JAXBElement<? extends Object>> genericResponse = new GenericType<JAXBElement<? extends Object>>() {};
	    System.out.println(resource.accept(MediaType.APPLICATION_XML_TYPE).get(genericResponse).getValue());

//		JAXBElement<WSParams> jaxParams = new JAXBElement<WSParams>(new QName("ltDocumentType"), WSParams.class, generateParamsTXT());
		
//		Response response = resource.type(MediaType.APPLICATION_XML_TYPE).entity(jaxParams).accept(MediaType.APPLICATION_XML_TYPE).post(genericResponse).getValue();
//		Assert.assertNotNull(response);
//		Assert.assertEquals(response.getCode(), "0");
//		Assert.assertNotNull(response.getDocument());
//		convertByteToFile(response.getDocument(), ".txt");
	}
	
	@Ignore
	public void recupererMarches() {
		ResponseBean responseBean = new ResponseBean();

		if(Pattern.matches("(0[1-9]|[1-9]|[12][0-9]|3[01])(0[1-9]|1[012]|[1-9])(19|20|21|22)\\d{2}", date)) {
			WebResource resource = client.resource(UriBuilder.fromUri(urlMarches).build());
			GenericType<JAXBElement<ResponseBean>> genericResponse = new GenericType<JAXBElement<ResponseBean>>() {};
			responseBean = resource.path("rest").path("consultation").path("marche").path(date).accept(MediaType.APPLICATION_XML).get(genericResponse).getValue();
			
		}
		System.out.println("Nombre de consultations trouvés : "+responseBean.getConsultations().size());

	}
	
	@Ignore
	public void testJaxB() throws JAXBException {
		JAXBElement<ResponseBean> res = new JAXBElement<ResponseBean>(
				new QName(ConstantesRestWebService.XML_QNAME_CONSULTATIONS),
				ResponseBean.class, null);
		List<ConsultationBean> consultations = new ArrayList<ConsultationBean>();
		ConsultationBean cons = new ConsultationBean();
		cons.setCodeContractantPublicMarche("RDA");
		consultations.add(cons);
		List<AvenantBean> avenants = new ArrayList<AvenantBean>();
		AvenantBean avenant = new AvenantBean();
		avenant.setCodeContractantPublicMarche("RDA2");
		avenants.add(avenant);
		ResponseBean response = new ResponseBean();
		response.setConsultations(consultations);
		response.setAvenants(avenants);
		res.setValue(response);
		
        JAXBContext jaxbContext = JAXBContext.newInstance(ResponseBean.class);
        StringWriter writer = new StringWriter();
        jaxbContext.createMarshaller().marshal(response, writer);
		
	}
	
	@Test
	public void testRegexData() {
	    String regex = "(0[1-9]|[1-9]|[12][0-9]|3[01])(0[1-9]|1[012]|[1-9])(19|20|21|22)\\d{2}($|([01][0-9]|2[0123])([012345][0-9])([012345][0-9]))";
	    Assert.assertTrue(Pattern.matches(regex, "01012013"));
	    Assert.assertFalse(Pattern.matches(regex, "89012013"));
	    Assert.assertFalse(Pattern.matches(regex, "010120131"));
	    Assert.assertFalse(Pattern.matches(regex, "010120131101"));
	    Assert.assertTrue(Pattern.matches(regex, "15012013010203"));
	}
}
