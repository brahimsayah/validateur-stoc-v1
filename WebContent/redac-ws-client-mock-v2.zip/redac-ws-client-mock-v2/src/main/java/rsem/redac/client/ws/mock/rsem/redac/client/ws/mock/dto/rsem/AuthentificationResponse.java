package rsem.redac.client.ws.mock.rsem.redac.client.ws.mock.dto.rsem;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name = "AuthentificationResponse")
public class AuthentificationResponse {
   // @XmlElement(name = "ticket")
    private String ticket;
    //@XmlElement(name = "code")
    private int code;
    //@XmlElement(name = "message")
    private String message;

    public String getTicket() {
        return ticket;
    }

    public void setTicket(String ticket) {
        this.ticket = ticket;
    }

    public int getCode() {
        return code;
    }

    public void setCode(int code) {
        this.code = code;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }
}
