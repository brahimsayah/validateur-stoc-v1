//
// Ce fichier a été généré par l'implémentation de référence JavaTM Architecture for XML Binding (JAXB), v2.2.8-b130911.1802 
// Voir <a href="http://java.sun.com/xml/jaxb">http://java.sun.com/xml/jaxb</a> 
// Toute modification apportée à ce fichier sera perdue lors de la recompilation du schéma source. 
// Généré le : 2018.08.20 à 03:31:12 PM CEST 
//


package rsem.redac.client.ws.mock.dto.redaction;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Classe Java pour SousClauseSociale1Type.
 * 
 * <p>Le fragment de schéma suivant indique le contenu attendu figurant dans cette classe.
 * <p>
 * <pre>
 * &lt;simpleType name="SousClauseSociale1Type">
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}NMTOKEN">
 *     &lt;enumeration value="insertionActiviteEconomique"/>
 *     &lt;enumeration value="clauseSocialeFormationScolaire"/>
 *     &lt;enumeration value="lutteContreDiscriminations"/>
 *     &lt;enumeration value="commerceEquitable"/>
 *     &lt;enumeration value="achatsEthiquesTracabiliteSociale"/>
 *     &lt;enumeration value="autreClauseSociale"/>
 *   &lt;/restriction>
 * &lt;/simpleType>
 * </pre>
 * 
 */
@XmlType(name = "SousClauseSociale1Type")
@XmlEnum
public enum SousClauseSociale1Type {

    @XmlEnumValue("insertionActiviteEconomique")
    INSERTION_ACTIVITE_ECONOMIQUE("insertionActiviteEconomique"),
    @XmlEnumValue("clauseSocialeFormationScolaire")
    CLAUSE_SOCIALE_FORMATION_SCOLAIRE("clauseSocialeFormationScolaire"),
    @XmlEnumValue("lutteContreDiscriminations")
    LUTTE_CONTRE_DISCRIMINATIONS("lutteContreDiscriminations"),
    @XmlEnumValue("commerceEquitable")
    COMMERCE_EQUITABLE("commerceEquitable"),
    @XmlEnumValue("achatsEthiquesTracabiliteSociale")
    ACHATS_ETHIQUES_TRACABILITE_SOCIALE("achatsEthiquesTracabiliteSociale"),
    @XmlEnumValue("autreClauseSociale")
    AUTRE_CLAUSE_SOCIALE("autreClauseSociale");
    private final String value;

    SousClauseSociale1Type(String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    public static SousClauseSociale1Type fromValue(String v) {
        for (SousClauseSociale1Type c: SousClauseSociale1Type.values()) {
            if (c.value.equals(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v);
    }

}
