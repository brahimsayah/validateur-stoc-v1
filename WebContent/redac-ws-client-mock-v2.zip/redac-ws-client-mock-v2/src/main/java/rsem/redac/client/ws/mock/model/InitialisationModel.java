package rsem.redac.client.ws.mock.model;

import rsem.redac.client.ws.mock.dto.UtilisateurType;

public class InitialisationModel {
    //redactiontype
        ///InitialisationType
            ////UtilisateurType
    protected String login;
    protected String nom;
    protected String prenom;
    UtilisateurType utilisateurType;
            ////consultation

        ///ListeDocumentsType


    public String getLogin() {
        return login;
    }

    public void setLogin(String login) {
        this.login = login;
    }
}
