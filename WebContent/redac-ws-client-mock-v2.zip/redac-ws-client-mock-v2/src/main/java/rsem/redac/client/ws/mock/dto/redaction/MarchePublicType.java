//
// Ce fichier a été généré par l'implémentation de référence JavaTM Architecture for XML Binding (JAXB), v2.2.8-b130911.1802 
// Voir <a href="http://java.sun.com/xml/jaxb">http://java.sun.com/xml/jaxb</a> 
// Toute modification apportée à ce fichier sera perdue lors de la recompilation du schéma source. 
// Généré le : 2018.08.20 à 03:31:12 PM CEST 
//


package rsem.redac.client.ws.mock.dto.redaction;

import javax.xml.bind.annotation.*;
import java.util.ArrayList;
import java.util.List;


/**
 * <p>Classe Java pour MarchePublicType complex type.
 * 
 * <p>Le fragment de schéma suivant indique le contenu attendu figurant dans cette classe.
 * 
 * <pre>
 * &lt;complexType name="MarchePublicType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="value" type="{http://www.atexo.com/rsem}SousClauseSociale1Type"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "MarchePublicType", propOrder = {
    "value"
})
public class MarchePublicType {

    @XmlElement(required = true)
    @XmlSchemaType(name = "NMTOKEN")
    protected List<SousClauseSociale1Type> value;

    /**
     * Gets the value of the value property.
     *
             * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the value property.
     *
             * <p>
     * For example, to add a new item, do as follows:
            * <pre>
     *    getValue().add(newItem);
     * </pre>
            *
            *
            * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link String }
     *
             *
             */
    public List<SousClauseSociale1Type> getValue() {
        if (value == null) {
            value = new ArrayList<SousClauseSociale1Type>();
        }
        return this.value;
    }
}
