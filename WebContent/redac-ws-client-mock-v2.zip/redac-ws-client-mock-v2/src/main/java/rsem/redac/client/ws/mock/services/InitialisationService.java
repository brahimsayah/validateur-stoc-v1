package rsem.redac.client.ws.mock.services;

import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import javax.annotation.PostConstruct;
import javax.xml.bind.JAXBElement;
import javax.xml.namespace.QName;

@Service
public class InitialisationService {
    private  RestTemplate restTemplate;

    @PostConstruct
    public void init() {
        restTemplate = new RestTemplate();
    }
  public ResponseEntity<String> authentificationRest(String user, String password ){
     return  restTemplate.getForEntity("http://localhost:8080/epm.noyau/rest/authentification/connexion/"+user+"/"+password,String.class);
    }
}
