package rsem.redac.client.ws.mock.services;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import rsem.redac.client.ws.mock.dto.redaction.RedactionType;
import rsem.redac.client.ws.mock.utils.InitialisationUtils;

import javax.annotation.PostConstruct;

@Service
public class InitialisationService {
    private RestTemplate restTemplate;

    @Value("${rsem.redac.rest.ws.basUrl}")
    private String baseUrl;

    @PostConstruct
    public void init() {
        restTemplate = new RestTemplate();
    }

    public ResponseEntity<String> authentificationRest(String user, String password) {
        String url = baseUrl + "authentification/connexion/" + user + "/" + password;
        try{
            return restTemplate.getForEntity(url, String.class);
        }catch (Exception e){
            e.printStackTrace();
            return new ResponseEntity<String>("Probleme de connexion au service d'authentification technique RSEM sur l'url ["+baseUrl+"] :"
                    +InitialisationUtils.getExeceptionStack(e), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    public ResponseEntity<String> intialisationAppel(String ticket, RedactionType redactionType) {
        String url = baseUrl + "consultation/initialisation?ticket=" + ticket;
        HttpEntity<RedactionType> resquetInitialisation = new HttpEntity<>(redactionType, null);
        try {
            return restTemplate.exchange(url, HttpMethod.PUT, resquetInitialisation, String.class);
        }catch (Exception e){
            e.printStackTrace();
            return new ResponseEntity<String>("Probleme de connexion au service d'initialisation RSEM sur l'url ["+baseUrl+"] :"
                    +InitialisationUtils.getExeceptionStack(e), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    public void setBaseUrl(String baseUrl) {
        this.baseUrl = baseUrl;
    }
}
