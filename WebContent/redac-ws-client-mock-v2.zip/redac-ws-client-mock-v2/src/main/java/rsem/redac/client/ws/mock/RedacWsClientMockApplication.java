package rsem.redac.client.ws.mock;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;



@SpringBootApplication
@ComponentScan("rsem.redac.client.ws.mock")
public class RedacWsClientMockApplication {

	public static void main(String[] args) {

		SpringApplication.run(RedacWsClientMockApplication.class, args);
	}

}
