package rsem.redac.client.ws.mock.controllers;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;

import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import rsem.redac.client.ws.mock.model.InitialisationModel;
import rsem.redac.client.ws.mock.model.ResponseTemplate;
import rsem.redac.client.ws.mock.rsem.redac.client.ws.mock.dto.rsem.AuthentificationResponse;
import rsem.redac.client.ws.mock.services.InitialisationService;

import javax.servlet.http.HttpServletRequest;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Unmarshaller;
import java.io.IOException;
import java.io.InputStream;
import java.io.StringReader;

@Controller
@SessionAttributes({"initialisationModel"})
public class InitialisationConsultController {
    @Autowired
     private InitialisationService initialisationService;


    @RequestMapping("/")
    public String index(final Model uiModel) {
        uiModel.addAttribute("initialisationModel", new InitialisationModel());


        return "initialisation";
    }

//    @RequestMapping(value="login", method = RequestMethod.GET)
//    public String login(@RequestParam("username") String username, @RequestParam("password") String password, Model model) {
//
//        return "login";
//    }

    @RequestMapping(value = "/startInitialisation")
    public final String searchPublicationClausier(@ModelAttribute("initialisationModel") final InitialisationModel initialisationModel, final Model uiModel) {
        System.out.println("******************"+ initialisationModel.getLogin());
        return "initialisation";
    }

//    @RequestMapping(value = "/importExecFlux")
//    public final String importPublicationsClausier(@RequestParam("fileImport") final MultipartFile multipartFile,@RequestParam("login") final String login, final RedirectAttributes redirectAttributes, HttpServletRequest request) {
//        System.out.println("******************"+ login);
//        try {
//            InputStream file =multipartFile.getInputStream();
//        } catch (IOException e) {
//            e.printStackTrace();
//        }
//        return "initialisation";
//    }

    @RequestMapping("/importExecFlux")
    @ResponseBody
    public ResponseTemplate<String> impotExecFlux(@RequestParam("fileImport") final MultipartFile multipartFile,@RequestParam("login") final String login,@RequestParam("password") final String password) {

        try {
            InputStream file =multipartFile.getInputStream();
        } catch (IOException e) {
            e.printStackTrace();
        }

        ResponseEntity<String> response= initialisationService.authentificationRest(login,password);
        if(!"OK".equals(response.getStatusCode().getReasonPhrase()))
            return new ResponseTemplate<String>(response.getStatusCode().getReasonPhrase(),String.valueOf(response.getStatusCodeValue()),response.getBody());
        System.out.println("******************"+ response.getBody());
        String respBody = response.getBody().replace("<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?><","<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?><AuthentificationResponse><")+"</AuthentificationResponse>";
        JAXBContext jaxbContext = null;
        try {
            jaxbContext = JAXBContext.newInstance(AuthentificationResponse.class);

        Unmarshaller unmarshaller = jaxbContext.createUnmarshaller();

        StringReader reader = new StringReader(respBody);
            AuthentificationResponse authentificationResponse = (AuthentificationResponse) unmarshaller.unmarshal(reader);
            return new ResponseTemplate<String>(authentificationResponse.getTicket());
        } catch (JAXBException e) {
            e.printStackTrace();
        }

        return new ResponseTemplate<String>("probleme");

    }

    }
