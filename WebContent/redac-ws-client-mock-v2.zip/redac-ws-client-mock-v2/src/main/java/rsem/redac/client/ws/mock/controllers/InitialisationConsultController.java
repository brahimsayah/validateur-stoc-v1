package rsem.redac.client.ws.mock.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.multipart.MultipartFile;
import rsem.redac.client.ws.mock.dto.redaction.RedactionType;
import rsem.redac.client.ws.mock.dto.redaction.marshall.Redaction;
import rsem.redac.client.ws.mock.dto.rsem.AuthentificationResponse;
import rsem.redac.client.ws.mock.model.ResponseTemplate;
import rsem.redac.client.ws.mock.services.InitialisationService;
import rsem.redac.client.ws.mock.utils.InitialisationUtils;

import javax.xml.bind.JAXBException;
import java.io.IOException;
import java.io.InputStream;
import java.io.StringReader;

@Controller
@SessionAttributes({"webserviceResponse"})
public class InitialisationConsultController {
    @Autowired
    private InitialisationService initialisationService;


    @RequestMapping("/")
    public String redirection(final Model uiModel) {
        uiModel.addAttribute("webserviceResponse",new ResponseTemplate("","",""));
        return "index";
    }
    @RequestMapping("/index")
    public String index(final Model uiModel) {
        uiModel.addAttribute("webserviceResponse",new ResponseTemplate("","",""));
        return "index";
    }
    @RequestMapping("/initialisation")
    public String initialisation(final Model uiModel) {
        uiModel.addAttribute("webserviceResponse",new ResponseTemplate("","",""));
        return "initialisation";
    }
    @RequestMapping("/importExecFlux")
    public String importExecFlux(@RequestParam("fileImport") final MultipartFile multipartFile, @RequestParam("login") final String login, @RequestParam("password") final String password, final Model uiModel) {
        uiModel.addAttribute("webserviceResponse",authentificationEtExecutionFlux(multipartFile,login,password));
        return "initialisation";
    }

    /**
     * retour json
     * @param multipartFile
     * @param login
     * @param password
     * @return
     */
    @RequestMapping("/importExecFlux2")
    @ResponseBody
    public ResponseTemplate importExecFlux(@RequestParam("fileImport") final MultipartFile multipartFile, @RequestParam("login") final String login, @RequestParam("password") final String password) {
        return authentificationEtExecutionFlux(multipartFile,login,password);
    }

    private  ResponseTemplate authentificationEtExecutionFlux( final MultipartFile multipartFile, final String login, final String password) {
        try {
            InputStream file = multipartFile.getInputStream();
            // authentification et recuperation ticket
            ResponseEntity<String> authentificationResponseEntity = initialisationService.authentificationRest(login, password);
            if (!"OK".equals(authentificationResponseEntity.getStatusCode().getReasonPhrase()))
                return new ResponseTemplate<String>(authentificationResponseEntity.getStatusCode().getReasonPhrase(), String.valueOf(authentificationResponseEntity.getStatusCodeValue()), authentificationResponseEntity.getBody());

            String AuthentificationResponseBody = authentificationResponseEntity.getBody().replace("<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?><", "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?><AuthentificationResponse><") + "</AuthentificationResponse>";

            StringReader reader = new StringReader(AuthentificationResponseBody);
            AuthentificationResponse authentificationResponse = (AuthentificationResponse) InitialisationUtils.unmarshal(reader, AuthentificationResponse.class);
            if (authentificationResponse.getErreur() != null) {
                return new ResponseTemplate<String>(AuthentificationResponseBody);
            }
            String ticket = authentificationResponse.getTicket();
            //unmarshal flux
            Redaction redaction = (Redaction) InitialisationUtils.unmarshal(file, Redaction.class);
            if (redaction == null) {
                return new ResponseTemplate<String>("KO", "204", "L'objet Redaction est vide. Verifiez le fichier flux");
            }
            RedactionType redactionType = new RedactionType();
            redactionType.setListeDocuments(redaction.getListeDocuments());
            redactionType.setInitialisation(redaction.getInitialisation());
            ResponseEntity<String> responseIntiEntity = initialisationService.intialisationAppel(ticket, redactionType);
            if (!"OK".equals(responseIntiEntity.getStatusCode().getReasonPhrase()))
                return new ResponseTemplate<String>(responseIntiEntity.getStatusCode().getReasonPhrase(), String.valueOf(responseIntiEntity.getStatusCodeValue()), responseIntiEntity.getBody());

            return new ResponseTemplate<String>(responseIntiEntity.getBody());
        } catch (JAXBException e) {
            e.printStackTrace();
            return new ResponseTemplate("KO", "9999", "Probleme de JAXB:"+InitialisationUtils.getExeceptionStack(e));
        } catch (IOException e) {
            e.printStackTrace();
            return new ResponseTemplate("KO", "9998", "Probleme de lecture de flux"+InitialisationUtils.getExeceptionStack(e));
        }
    }

}
