package rsem.redac.client.ws.mock.dto.rsem;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name = "AuthentificationResponse")
public class AuthentificationResponse {
   // @XmlElement(name = "ticket")
    private String ticket;
    private Erreur erreur;

    public String getTicket() {
        return ticket;
    }

    public void setTicket(String ticket) {
        this.ticket = ticket;
    }

    public Erreur getErreur() {
        return erreur;
    }

    public void setErreur(Erreur erreur) {
        this.erreur = erreur;
    }

}
