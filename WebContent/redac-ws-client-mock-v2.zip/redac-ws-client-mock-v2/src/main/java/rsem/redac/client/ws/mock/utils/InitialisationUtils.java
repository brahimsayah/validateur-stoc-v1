package rsem.redac.client.ws.mock.utils;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Unmarshaller;
import java.io.InputStream;
import java.io.PrintWriter;
import java.io.Reader;
import java.io.StringWriter;

public class InitialisationUtils {
    public static String getExeceptionStack(Exception e){
        StringWriter sw = new StringWriter();
        PrintWriter pw = new PrintWriter(sw);
        e.printStackTrace(pw);
        return sw.toString();
    }

    public static <T> T unmarshal(Reader reader, Class clazz) throws JAXBException {
        return (T) getUnmarsheller(clazz).unmarshal(reader);
    }

    public static <T> T unmarshal(InputStream file, Class clazz) throws JAXBException {
        return (T) getUnmarsheller(clazz).unmarshal(file);
    }

    private static Unmarshaller getUnmarsheller(Class clazz) throws JAXBException {
        JAXBContext  jaxbContext = JAXBContext.newInstance(clazz);
        return jaxbContext.createUnmarshaller();
    }
}
