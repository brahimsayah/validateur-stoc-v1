//package rsem.redac.client.ws.mock;
//
//
//import org.springframework.context.annotation.Bean;
//import org.springframework.context.annotation.Configuration;
//import org.springframework.web.servlet.ViewResolver;
//import org.springframework.web.servlet.config.annotation.ViewControllerRegistry;
//import org.springframework.web.servlet.config.annotation.WebMvcConfigurerAdapter;
//import org.springframework.web.servlet.view.InternalResourceViewResolver;
//
//@Configuration
//public class MvcConfig extends WebMvcConfigurerAdapter {
//
//    @Override
//    public void addViewControllers(ViewControllerRegistry registry) {
//        registry.addRedirectViewController("/", "/login");
////        registry.addViewController("/login").setViewName("login.html");
////        registry.addViewController("/login").setViewName("login");
////        registry.addViewController("/commande").setViewName("commande");
//    }
//
//
//
////    @Bean
////    public ViewResolver jspViewResolver() {
////        InternalResourceViewResolver bean = new InternalResourceViewResolver();
////        bean.setPrefix("/WEB-INF/classes/templates/");
////        bean.setSuffix(".jsp");
////        return bean;
////    }
//}