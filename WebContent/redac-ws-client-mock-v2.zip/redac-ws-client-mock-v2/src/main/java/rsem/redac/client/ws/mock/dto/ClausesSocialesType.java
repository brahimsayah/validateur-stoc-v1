//
// Ce fichier a été généré par l'implémentation de référence JavaTM Architecture for XML Binding (JAXB), v2.2.8-b130911.1802 
// Voir <a href="http://java.sun.com/xml/jaxb">http://java.sun.com/xml/jaxb</a> 
// Toute modification apportée à ce fichier sera perdue lors de la recompilation du schéma source. 
// Généré le : 2018.08.20 à 03:31:12 PM CEST 
//


package rsem.redac.client.ws.mock.dto;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import java.math.BigDecimal;


/**
 * <p>Classe Java pour ClausesSocialesType complex type.
 * 
 * <p>Le fragment de schéma suivant indique le contenu attendu figurant dans cette classe.
 * 
 * <pre>
 * &lt;complexType name="ClausesSocialesType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="nombreHeure" type="{http://www.w3.org/2001/XMLSchema}decimal"/>
 *         &lt;element name="pourcentage" type="{http://www.w3.org/2001/XMLSchema}short"/>
 *         &lt;element name="marcheReserve" type="{http://www.w3.org/2001/XMLSchema}boolean"/>
 *         &lt;element name="conditionExecution" type="{http://www.w3.org/2001/XMLSchema}boolean"/>
 *         &lt;element name="critereAttribution" type="{http://www.w3.org/2001/XMLSchema}boolean"/>
 *         &lt;element name="marchePublicClauseSocialeConditionExecution" type="{http://www.atexo.com/rsem}MarchePublicType"/>
 *         &lt;element name="marchPublicClauseSocialeSpecificationTechnique" type="{http://www.atexo.com/rsem}MarchePublicType"/>
 *         &lt;element name="marchePublicCritèreSocialCritereAttribution" type="{http://www.atexo.com/rsem}MarchePublicType"/>
 *         &lt;element name="marcheReserveADes" type="{http://www.atexo.com/rsem}SousClauseSociale2Type"/>
 *         &lt;element name="marchePublicObjetEstInsertion" type="{http://www.w3.org/2001/XMLSchema}boolean"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ClausesSocialesType", propOrder = {
    "nombreHeure",
    "pourcentage",
    "marcheReserve",
    "conditionExecution",
    "critereAttribution",
    "marchePublicClauseSocialeConditionExecution",
    "marchPublicClauseSocialeSpecificationTechnique",
    "marchePublicCrit\u00e8reSocialCritereAttribution",
    "marcheReserveADes",
    "marchePublicObjetEstInsertion"
})
public class ClausesSocialesType {

    @XmlElement(required = true)
    protected BigDecimal nombreHeure;
    protected short pourcentage;
    protected boolean marcheReserve;
    protected boolean conditionExecution;
    protected boolean critereAttribution;
    @XmlElement(required = true)
    protected MarchePublicType marchePublicClauseSocialeConditionExecution;
    @XmlElement(required = true)
    protected MarchePublicType marchPublicClauseSocialeSpecificationTechnique;
    @XmlElement(required = true)
    protected MarchePublicType marchePublicCritèreSocialCritereAttribution;
    @XmlElement(required = true)
    protected SousClauseSociale2Type marcheReserveADes;
    protected boolean marchePublicObjetEstInsertion;

    /**
     * Obtient la valeur de la propriété nombreHeure.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getNombreHeure() {
        return nombreHeure;
    }

    /**
     * Définit la valeur de la propriété nombreHeure.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setNombreHeure(BigDecimal value) {
        this.nombreHeure = value;
    }

    /**
     * Obtient la valeur de la propriété pourcentage.
     * 
     */
    public short getPourcentage() {
        return pourcentage;
    }

    /**
     * Définit la valeur de la propriété pourcentage.
     * 
     */
    public void setPourcentage(short value) {
        this.pourcentage = value;
    }

    /**
     * Obtient la valeur de la propriété marcheReserve.
     * 
     */
    public boolean isMarcheReserve() {
        return marcheReserve;
    }

    /**
     * Définit la valeur de la propriété marcheReserve.
     * 
     */
    public void setMarcheReserve(boolean value) {
        this.marcheReserve = value;
    }

    /**
     * Obtient la valeur de la propriété conditionExecution.
     * 
     */
    public boolean isConditionExecution() {
        return conditionExecution;
    }

    /**
     * Définit la valeur de la propriété conditionExecution.
     * 
     */
    public void setConditionExecution(boolean value) {
        this.conditionExecution = value;
    }

    /**
     * Obtient la valeur de la propriété critereAttribution.
     * 
     */
    public boolean isCritereAttribution() {
        return critereAttribution;
    }

    /**
     * Définit la valeur de la propriété critereAttribution.
     * 
     */
    public void setCritereAttribution(boolean value) {
        this.critereAttribution = value;
    }

    /**
     * Obtient la valeur de la propriété marchePublicClauseSocialeConditionExecution.
     * 
     * @return
     *     possible object is
     *     {@link MarchePublicType }
     *     
     */
    public MarchePublicType getMarchePublicClauseSocialeConditionExecution() {
        return marchePublicClauseSocialeConditionExecution;
    }

    /**
     * Définit la valeur de la propriété marchePublicClauseSocialeConditionExecution.
     * 
     * @param value
     *     allowed object is
     *     {@link MarchePublicType }
     *     
     */
    public void setMarchePublicClauseSocialeConditionExecution(MarchePublicType value) {
        this.marchePublicClauseSocialeConditionExecution = value;
    }

    /**
     * Obtient la valeur de la propriété marchPublicClauseSocialeSpecificationTechnique.
     * 
     * @return
     *     possible object is
     *     {@link MarchePublicType }
     *     
     */
    public MarchePublicType getMarchPublicClauseSocialeSpecificationTechnique() {
        return marchPublicClauseSocialeSpecificationTechnique;
    }

    /**
     * Définit la valeur de la propriété marchPublicClauseSocialeSpecificationTechnique.
     * 
     * @param value
     *     allowed object is
     *     {@link MarchePublicType }
     *     
     */
    public void setMarchPublicClauseSocialeSpecificationTechnique(MarchePublicType value) {
        this.marchPublicClauseSocialeSpecificationTechnique = value;
    }

    /**
     * Obtient la valeur de la propriété marchePublicCritèreSocialCritereAttribution.
     * 
     * @return
     *     possible object is
     *     {@link MarchePublicType }
     *     
     */
    public MarchePublicType getMarchePublicCritèreSocialCritereAttribution() {
        return marchePublicCritèreSocialCritereAttribution;
    }

    /**
     * Définit la valeur de la propriété marchePublicCritèreSocialCritereAttribution.
     * 
     * @param value
     *     allowed object is
     *     {@link MarchePublicType }
     *     
     */
    public void setMarchePublicCritèreSocialCritereAttribution(MarchePublicType value) {
        this.marchePublicCritèreSocialCritereAttribution = value;
    }

    /**
     * Obtient la valeur de la propriété marcheReserveADes.
     * 
     * @return
     *     possible object is
     *     {@link SousClauseSociale2Type }
     *     
     */
    public SousClauseSociale2Type getMarcheReserveADes() {
        return marcheReserveADes;
    }

    /**
     * Définit la valeur de la propriété marcheReserveADes.
     * 
     * @param value
     *     allowed object is
     *     {@link SousClauseSociale2Type }
     *     
     */
    public void setMarcheReserveADes(SousClauseSociale2Type value) {
        this.marcheReserveADes = value;
    }

    /**
     * Obtient la valeur de la propriété marchePublicObjetEstInsertion.
     * 
     */
    public boolean isMarchePublicObjetEstInsertion() {
        return marchePublicObjetEstInsertion;
    }

    /**
     * Définit la valeur de la propriété marchePublicObjetEstInsertion.
     * 
     */
    public void setMarchePublicObjetEstInsertion(boolean value) {
        this.marchePublicObjetEstInsertion = value;
    }

}
