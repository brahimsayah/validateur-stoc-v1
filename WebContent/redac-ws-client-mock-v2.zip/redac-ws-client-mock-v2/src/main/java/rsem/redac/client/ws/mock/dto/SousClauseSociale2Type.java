//
// Ce fichier a été généré par l'implémentation de référence JavaTM Architecture for XML Binding (JAXB), v2.2.8-b130911.1802 
// Voir <a href="http://java.sun.com/xml/jaxb">http://java.sun.com/xml/jaxb</a> 
// Toute modification apportée à ce fichier sera perdue lors de la recompilation du schéma source. 
// Généré le : 2018.08.20 à 03:31:12 PM CEST 
//


package rsem.redac.client.ws.mock.dto;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Classe Java pour SousClauseSociale2Type complex type.
 * 
 * <p>Le fragment de schéma suivant indique le contenu attendu figurant dans cette classe.
 * 
 * <pre>
 * &lt;complexType name="SousClauseSociale2Type">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;attribute name="entreprisesAdapteesEtablissementsServicesAide" type="{http://www.w3.org/2001/XMLSchema}boolean" />
 *       &lt;attribute name="StructuresInsertionActiviteEconomique" type="{http://www.w3.org/2001/XMLSchema}boolean" />
 *       &lt;attribute name="EntreprisesEconomieSocialeSolidaire" type="{http://www.w3.org/2001/XMLSchema}boolean" />
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "SousClauseSociale2Type")
public class SousClauseSociale2Type {

    @XmlAttribute(name = "entreprisesAdapteesEtablissementsServicesAide")
    protected Boolean entreprisesAdapteesEtablissementsServicesAide;
    @XmlAttribute(name = "StructuresInsertionActiviteEconomique")
    protected Boolean structuresInsertionActiviteEconomique;
    @XmlAttribute(name = "EntreprisesEconomieSocialeSolidaire")
    protected Boolean entreprisesEconomieSocialeSolidaire;

    /**
     * Obtient la valeur de la propriété entreprisesAdapteesEtablissementsServicesAide.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isEntreprisesAdapteesEtablissementsServicesAide() {
        return entreprisesAdapteesEtablissementsServicesAide;
    }

    /**
     * Définit la valeur de la propriété entreprisesAdapteesEtablissementsServicesAide.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setEntreprisesAdapteesEtablissementsServicesAide(Boolean value) {
        this.entreprisesAdapteesEtablissementsServicesAide = value;
    }

    /**
     * Obtient la valeur de la propriété structuresInsertionActiviteEconomique.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isStructuresInsertionActiviteEconomique() {
        return structuresInsertionActiviteEconomique;
    }

    /**
     * Définit la valeur de la propriété structuresInsertionActiviteEconomique.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setStructuresInsertionActiviteEconomique(Boolean value) {
        this.structuresInsertionActiviteEconomique = value;
    }

    /**
     * Obtient la valeur de la propriété entreprisesEconomieSocialeSolidaire.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isEntreprisesEconomieSocialeSolidaire() {
        return entreprisesEconomieSocialeSolidaire;
    }

    /**
     * Définit la valeur de la propriété entreprisesEconomieSocialeSolidaire.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setEntreprisesEconomieSocialeSolidaire(Boolean value) {
        this.entreprisesEconomieSocialeSolidaire = value;
    }

}
