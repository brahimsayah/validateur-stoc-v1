###########RSEM-client-ws-mock#####################
- ce un mock permettant la simulation des appels des ws exposé par RSEM
- En l'etat actuelle il n'y a que le menu de simulatin du WS d'initialisation de la consultation pour le module redac

- Il s'agit  d'une application Spring boot qui peut etre utiliser comme sui:
- modifier le parametrage dans le fichier application.properties en configurant l'url de l'environnement RSEM cible
- lancer l'application soit 
    1 - par la commande maven : mvn spring-boot:run
	2 - en generant le war par la commnde maven : mvn clean install -DskipTests=true et puis en l'executant a travers la commande JAVA :  java -jar